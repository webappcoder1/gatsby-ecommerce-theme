﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PDO.Solutions.COI.SyncProfiles
{
    public class Utility
    {

    }

    /// <summary>
    /// Entity to hold Sharepoint Users Entity.
    /// </summary>
    public class SPUsersEntity
    {
        public string SID { get; set; }
        public string DisplayName { get; set; }
        public string UserName { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string IsActive { get; set; }
        public string RefIndicator { get; set; }
        public string Email { get; set; }
    }


    /// <summary>
    /// Entity class for User Organisation Hierarchy
    /// </summary>
    public class UserOrganisationHierarchy
    {
        public int ItemID { get; set; }
        public string MUID { get; set; }
        public string Directorate { get; set; }
        public string Department { get; set; }
        public string Section { get; set; }
        public string Team { get; set; }
        public string ValueStream { get; set; }
        public string Status { get; set; }
    }
}
