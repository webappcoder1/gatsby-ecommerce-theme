﻿using Microsoft.Office.Server.UserProfiles;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration;
using System;
using System.Collections.Generic;
using System.DirectoryServices;
using System.DirectoryServices.AccountManagement;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PDO.Solutions.COI.SyncProfiles
{
    public class SyncProfilesJob : SPJobDefinition
    {
        SPWebApplication webapp = null;
        SPWeb objSPWebCOI = null;
        string coiSiteUrl = string.Empty;

        /// <summary>
        /// Default 
        /// </summary>
        public SyncProfilesJob()
            : base()
        {

        }

        /// <summary>
        /// Constructor to set the job name.
        /// </summary>
        /// <param name="jobName">Job Name</param>
        /// <param name="webapp">Web Application Name.</param>
        public SyncProfilesJob(string jobName, SPWebApplication webapp)
            : base(jobName, webapp, null, SPJobLockType.Job)
        {
            this.Title = jobName;
        }

        /// <summary>
        /// This method is used to call the appropriated notification methods.
        /// </summary>
        /// <param name="targetInstanceId">Target Instance Id.</param>
        public override void Execute(Guid targetInstanceId)
        {
            webapp = this.Parent as SPWebApplication;
            SPContentDatabase contentDb = webapp.ContentDatabases[targetInstanceId];
            objSPWebCOI = webapp.Sites["/solutions/COI"].RootWeb as SPWeb;
            objSPWebCOI.AllowUnsafeUpdates = true;
            coiSiteUrl = objSPWebCOI.Url;
            StartJob();
            objSPWebCOI.AllowUnsafeUpdates = false;
        }


        /// <summary>
        /// This method is used to refresh the COI User Active status.
        /// The active status is updated based on the Account Active flag of the Active Directory attribute.
        /// </summary>
        private int RefreshCOIUsersStatus()
        {
            SPUsersEntity objSPUserEntity;
            string companyNo = string.Empty;
            int flags;
            int logcounter = 0;
            int totalProfiles = 0;
            int processedCounter = 0;
            UserOrganisationHierarchy objUserOrganisationHierarchy = null;
            SPQuery objSPQuery = null;

            try
            {
                SPSecurity.RunWithElevatedPrivileges(delegate()
                {
                    objSPWebCOI.AllowUnsafeUpdates = true;
                    objSPQuery = new SPQuery();
                    objSPQuery.QueryThrottleMode = SPQueryThrottleOption.Override;
                    objSPQuery.Query = @"<ViewFields>
                                                  <FieldRef Name='CC' />
                                                  <FieldRef Name='COI' />
                                                  <FieldRef Name='employeeno' />
                                                  <FieldRef Name='IsActive' />
                                                  <FieldRef Name='email' />
                                                  <FieldRef Name='RefIndicator' />
                                                  <FieldRef Name='directorate' />
                                                  <FieldRef Name='Department' />
                                                  <FieldRef Name='section' />
                                                  <FieldRef Name='team' />
                                               </ViewFields>";
                    objSPQuery.ViewFieldsOnly = true;
                    string listUrl = objSPWebCOI.ServerRelativeUrl + "/Lists/COIUSERS";
                    SPList list = objSPWebCOI.GetList(listUrl);
                    //SPListItemCollection objSPListItemColl = list.Items;
                    SPListItemCollection objSPListItemColl = list.GetItems(objSPQuery);
                    totalProfiles = objSPListItemColl.Count;

                    LogProgress(totalProfiles, processedCounter);

                    foreach (SPListItem empItem in objSPListItemColl)
                    {
                        try
                        {
                            companyNo = empItem["Employee No"].ToString();
                            objSPUserEntity = GetADUserAttributes(companyNo);

                            if (objSPUserEntity.IsActive != null)
                            {
                                flags = int.Parse(objSPUserEntity.IsActive);
                                if (!Convert.ToBoolean(flags & 0x0002))
                                {
                                    //Active User
                                    empItem["IsActive"] = 1;
                                }
                                else
                                {
                                    //InActive User
                                    empItem["IsActive"] = 0;
                                }
                            }
                            else
                            {
                                empItem["IsActive"] = 0;
                            }

                            if (!String.IsNullOrEmpty(objSPUserEntity.Email))
                            {
                                empItem["email"] = objSPUserEntity.Email;
                            }

                            empItem["Ref Indicator"] = objSPUserEntity.RefIndicator;
                            objUserOrganisationHierarchy = GetParentsByDepartment(companyNo);

                            if (objUserOrganisationHierarchy.Status == "OK")
                            {
                                empItem["directorate"] = objUserOrganisationHierarchy.Directorate;
                                empItem["Department"] = objUserOrganisationHierarchy.Department;
                                empItem["section"] = objUserOrganisationHierarchy.Section;
                                empItem["team"] = objUserOrganisationHierarchy.Team;
                            }
                            else
                            {
                                empItem["directorate"] = string.Empty;
                                empItem["Department"] = string.Empty;
                                empItem["section"] = string.Empty;
                                empItem["team"] = string.Empty;
                            }
                            empItem.SystemUpdate();
                            logcounter++;
                            processedCounter++;
                            if (logcounter == 250)
                            {
                                //progress update
                                LogProgress(totalProfiles, processedCounter);
                                logcounter = 0;
                            }
                        }
                        catch (Exception objException)
                        {
                            LoggingService.LogError(LoggingService.DiagnosticCategoryJobs, objException.Message);
                        }
                    }
                });
            }
            catch (Exception objException)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryJobs, objException.Message);
            }
            return totalProfiles;
        }


        private void StartJob()
        {
            try
            {
                SPSecurity.RunWithElevatedPrivileges(delegate()
                {
                    SPList objSPListConfiguration = objSPWebCOI.Lists["DailyJobConfigurations"];
                    SPListItem refreshProfile = (from SPListItem objConfigurationListItem in objSPListConfiguration.Items
                                                 where (bool)objConfigurationListItem["To Do"] == true && objConfigurationListItem["Title"].ToString() == "RefreshUserProfiles"
                                                 select objConfigurationListItem).FirstOrDefault();
                    if (refreshProfile != null)
                    {

                        DateTime dtCurrentDateTime = DateTime.Now;
                        int totalProfiles = RefreshCOIUsersStatus();
                        string message = string.Format("PDO.Solutions.COI.SyncProfiles Job - Started On {0} has Completed Refreshing {1} profiles On: {2}. Total time consumed: {3} ", dtCurrentDateTime.ToString(), totalProfiles, DateTime.Now.ToString(), DifferenceBetweenTwoDates(dtCurrentDateTime));
                        LogFinal(message);
                    }
                });
            }
            catch (Exception objException)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryJobs, objException.Message);
            }
        }


        private string DifferenceBetweenTwoDates(DateTime startDate)
        {
            string difference = string.Empty;
            try
            {
                TimeSpan span = DateTime.Now.Subtract(startDate);
                int Minutesdiff = span.Minutes;
                int Hoursdiff = span.Hours;
                int Daysdiff = span.Days;
                difference = string.Format(" {0} Days, {1} Hours, {2} Minutes ", Daysdiff.ToString(), Hoursdiff.ToString(), Minutesdiff.ToString());
            }
            catch (Exception objException)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryJobs, objException.Message);
            }
            return difference;
        }

        /// <summary>
        /// Log Running Progress
        /// </summary>
        /// <param name="total"></param>
        /// <param name="processed"></param>
        private void LogProgress(int total, int processed)
        {
            try
            {
                SPSecurity.RunWithElevatedPrivileges(delegate()
                {
                    SPList objSPListConfiguration = objSPWebCOI.Lists["DailyJobConfigurations"];
                    SPListItem refreshProfile = (from SPListItem objConfigurationListItem in objSPListConfiguration.Items
                                                 where (bool)objConfigurationListItem["To Do"] == true && objConfigurationListItem["Title"].ToString() == "RefreshUserProfiles"
                                                 select objConfigurationListItem).FirstOrDefault();
                    if (refreshProfile != null)
                    {
                        objSPWebCOI.AllowUnsafeUpdates = true;
                        refreshProfile["Log"] = string.Format("PDO.Solutions.COI.SyncProfiles Job - Processed {0} profiles out of {1}. Logs last modified at: {2} ", processed, total, DateTime.Now.ToString());
                        refreshProfile.SystemUpdate();
                    }
                });
            }
            catch (Exception objException)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryJobs, objException.Message);
            }
        }


        private void LogFinal(string message)
        {
            try
            {
                SPSecurity.RunWithElevatedPrivileges(delegate()
                {
                    SPList objSPListConfiguration = objSPWebCOI.Lists["DailyJobConfigurations"];
                    SPListItem refreshProfile = (from SPListItem objConfigurationListItem in objSPListConfiguration.Items
                                                 where (bool)objConfigurationListItem["To Do"] == true && objConfigurationListItem["Title"].ToString() == "RefreshUserProfiles"
                                                 select objConfigurationListItem).FirstOrDefault();
                    if (refreshProfile != null)
                    {
                        objSPWebCOI.AllowUnsafeUpdates = true;
                        refreshProfile["Log"] = message;
                        refreshProfile.SystemUpdate();
                    }
                });
            }
            catch (Exception objException)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryJobs, objException.Message);
            }
        }

        /// <summary>
        /// This method is used to get the AD User attributes of the passed Active Directory Id.
        /// </summary>
        /// <param name="userADId">User Active Directory Id.</param>
        /// <returns>Returns the initialized object of the SPUsersEntity containing the details of the User.</returns>
        private SPUsersEntity GetADUserAttributes(string userADId)
        {
            SPUsersEntity objSPUsersEntity = null;
            PrincipalContext objPrincipalContext = null;

            try
            {
                objSPUsersEntity = new SPUsersEntity();
                objPrincipalContext = new PrincipalContext(ContextType.Domain, "CORP");
                UserPrincipal user = UserPrincipal.FindByIdentity(objPrincipalContext, userADId);
                DirectoryEntry objDirectoryEntry = user.GetUnderlyingObject() as DirectoryEntry;

                if (user != null)
                {
                    if (objDirectoryEntry.Properties.Contains("displayName"))
                        objSPUsersEntity.DisplayName = objDirectoryEntry.Properties["displayName"].Value.ToString();

                    if (objDirectoryEntry.Properties.Contains("sAMAccountName"))
                        objSPUsersEntity.UserName = objDirectoryEntry.Properties["sAMAccountName"].Value.ToString();

                    if (objDirectoryEntry.Properties.Contains("givenName"))
                        objSPUsersEntity.FirstName = objDirectoryEntry.Properties["givenName"].Value.ToString();

                    if (objDirectoryEntry.Properties.Contains("sn"))
                        objSPUsersEntity.LastName = objDirectoryEntry.Properties["sn"].Value.ToString();

                    if (objDirectoryEntry.Properties.Contains("userAccountControl"))
                        objSPUsersEntity.IsActive = objDirectoryEntry.Properties["userAccountControl"].Value.ToString();

                    if (objDirectoryEntry.Properties.Contains("department"))
                        objSPUsersEntity.RefIndicator = objDirectoryEntry.Properties["department"].Value.ToString();

                    if (objDirectoryEntry.Properties.Contains("mail"))
                        objSPUsersEntity.Email = objDirectoryEntry.Properties["mail"].Value.ToString();

                }

            }
            catch (Exception objException)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryJobs, objException.Message);
            }
            finally
            {
                objPrincipalContext = null;
            }

            return objSPUsersEntity;
        }

        /// <summary>
        /// This method is used to get the GetParentsByDepartment.
        /// </summary>
        /// <param name="userADId">User Active Directory Id.</param>
        /// <returns>Returns UserOrganisationHierarchy.</returns>
        public UserOrganisationHierarchy GetParentsByDepartment(string muid)
        {
            UserOrganisationHierarchy userOrganisationHierarchy = new UserOrganisationHierarchy();
            List<string> parentDepartments = null;

            try
            {
                parentDepartments = new List<string>();

                try
                {
                    GetUserManagersDepartments(@"corp\" + muid, out parentDepartments);
                    userOrganisationHierarchy = new UserOrganisationHierarchy
                    {
                        Directorate = parentDepartments[0],
                        Department = parentDepartments[1],
                        Section = parentDepartments[2],
                        Team = parentDepartments[3],
                        Status = "OK"
                    };

                }
                catch (Exception objException)
                {
                    LoggingService.LogError(LoggingService.DiagnosticCategoryJobs, objException.Message);
                }
            }
            catch (Exception objException)
            {
                userOrganisationHierarchy = new UserOrganisationHierarchy
                {
                    Status = "Error"
                };

                LoggingService.LogError(LoggingService.DiagnosticCategoryJobs, objException.Message);
            }

            return userOrganisationHierarchy;

        }

        /// <summary>
        /// This method is used to get the GetUserManagersDepartments.
        /// </summary>
        /// <param name="userADId">User Active Directory Id.</param>
        /// <returns>Returns the initialized object of the GetUserManagersDepartments containing the details of the User.</returns>
        public void GetUserManagersDepartments(string loginName, out List<string> departments)
        {
            string excludedDirectorate = "MD;TD";
            departments = new List<string>();
            List<string> departmentsOut = new List<string>();

            try
            {
                SPServiceContext serverContext = SPServiceContext.GetContext(objSPWebCOI.Site);
                UserProfileManager profileManager = new UserProfileManager(serverContext);

                if (profileManager.UserExists(loginName))
                {
                    try
                    {
                        UserProfile profile = profileManager.GetUserProfile(loginName);

                        if (profile != null)
                        {
                            string dept = string.Empty;
                            UserProfile[] managersProfile = profile.GetManagers();
                            if (managersProfile != null && managersProfile.Length > 0)
                            {

                                managersProfile.ToList().ForEach(m =>
                                {

                                    dept = Convert.ToString(m["Department"].Value.ToString());
                                    if (!excludedDirectorate.Contains(dept) && m.GetDirectReports().Count() > 0)
                                    {
                                        departmentsOut.Add(dept);
                                    }

                                });
                            }

                            if (departmentsOut.Count < 4)
                            {
                                UserProfile[] reporteesProfile = profile.GetDirectReports();
                                if (reporteesProfile.Count() > 0)
                                {
                                    departmentsOut.Add(profile["Department"].Value.ToString());
                                }
                            }
                        }

                    }
                    catch (Exception objException)
                    {
                        LoggingService.LogError(LoggingService.DiagnosticCategoryJobs, objException.Message);
                    }

                    switch (departmentsOut.Count)
                    {
                        case 0:
                            departmentsOut.Add("Other");
                            departmentsOut.Add("Other");
                            departmentsOut.Add("Other");
                            departmentsOut.Add("Other");
                            break;

                        case 1:
                            departmentsOut.Add(departmentsOut[0]);
                            departmentsOut.Add(departmentsOut[0]);
                            departmentsOut.Add(departmentsOut[0]);
                            break;

                        case 2:
                            departmentsOut.Add(departmentsOut[1]);
                            departmentsOut.Add(departmentsOut[1]);
                            break;

                        case 3:
                            departmentsOut.Add(departmentsOut[2]);
                            break;

                        default:
                            departmentsOut.Add("Other");
                            departmentsOut.Add("Other");
                            departmentsOut.Add("Other");
                            departmentsOut.Add("Other");
                            break;
                    }

                    departments = departmentsOut;
                }

            }
            catch (Exception objException)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryJobs, objException.Message);
            }
        }

    }
}
