﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.SharePoint.Administration;
using Microsoft.SharePoint;
using System.Net.Mail;
using System.Data;

namespace PDO.Solutions.PAISAT.Utilities
{
    public static class Utility
    {
        /// <summary>
        /// This method is used to get the mail notification template by notification template name.
        /// </summary>
        /// <param name="notificationTemplateName">Notification template name.</param>
        /// <returns>Returns datatable containing the mail template.</returns>
        public static DataTable GetMailTemplateByTemplateName(string notificationTemplateName)
        {
            DataTable dtMailTemplate = null;           
            SPQuery objSPQuery = null;

            try
            {
                SPSecurity.RunWithElevatedPrivileges(delegate
                {
                    using (SPSite objSPSite = new SPSite(SPContext.Current.Web.Site.Url))
                    {
                        using (SPWeb objSPWebISAT = objSPSite.AllWebs["PAISAT"])
                        {
                            using (dtMailTemplate = new DataTable())
                            {
                                objSPQuery = new SPQuery();
                                objSPQuery.QueryThrottleMode = SPQueryThrottleOption.Override;
                                objSPQuery.Query = @"<Where>
                                     <Eq>
                                        <FieldRef Name='Title' />
                                        <Value Type='Text'>" + notificationTemplateName + @"</Value>
                                     </Eq>
                                   </Where>";
                                objSPQuery.ViewFields = "<FieldRef Name='Title' /><FieldRef Name='Subject' /><FieldRef Name='Body' /><FieldRef Name='Body_AR' />";
                                objSPQuery.ViewFieldsOnly = true;
                                string listUrl = objSPWebISAT.ServerRelativeUrl + "/Lists/Notifications";
                                SPList list = objSPWebISAT.GetList(listUrl);
                                dtMailTemplate = list.GetItems(objSPQuery).GetDataTable();
                            }
                        }
                    }
                });
                
            }
            catch (Exception objException)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryWebParts, objException.Message);
            }

            return dtMailTemplate;
        }      
      
        /// <summary>
        /// Method to send email.
        /// </summary>
        /// <param name="objMailEntity">Initialized object of Mail Entity</param>
        /// <returns>Returns true if the </returns>
        public static bool SendMail(MailEntity objMailEntity)
        {
            //objMailEntity.To = "Suresh.Mara@pdo.co.om";
            //objMailEntity.CC = objMailEntity.BCC = "";

            bool mailSent = false;
            SmtpClient smtpClient = null;

            try
            {
                // Assign SMTP address   
                smtpClient = new SmtpClient();
                smtpClient.Host = objMailEntity.SMTPAddress;

                //Create an email message   
                MailMessage mailMessage = new MailMessage("iSecure@pdo.co.om", objMailEntity.To, objMailEntity.Subject, objMailEntity.Body);                
                if (!String.IsNullOrEmpty(objMailEntity.CC))
                {
                    MailAddress CCAddress = new MailAddress(objMailEntity.CC);
                    mailMessage.CC.Add(objMailEntity.CC);
                }

                if (!String.IsNullOrEmpty(objMailEntity.BCC))
                {
                    MailAddress BCCAddress = new MailAddress(objMailEntity.BCC);
                    mailMessage.Bcc.Add(objMailEntity.BCC);
                }
                mailMessage.IsBodyHtml = objMailEntity.IsBodyHTML;                
                // Send the email   
                smtpClient.Send(mailMessage);
                mailSent = true;
            }
            catch (Exception objException)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryWebParts, objException.Message);
                mailSent = false;
            }

            return mailSent;
        }

        /// <summary>
        /// This method is used to get the values from the property bag.
        /// </summary>
        /// <param name="propertyKey">Property Key</param>
        /// <returns>Returns value of the corresponding property key.</returns>
        public static string GetPropertyBagValueByKey(string propertyKey, string siteUrl)
        {
            String propertyValue = String.Empty;

            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
                try
                {
                    using (SPSite objSPSite = new SPSite(siteUrl))
                    {
                        using (SPWeb objSPWeb = objSPSite.AllWebs["PAISAT"] as SPWeb)
                        {
                            if (objSPWeb.AllProperties.ContainsKey(propertyKey))
                            {
                                propertyValue = objSPWeb.AllProperties[propertyKey].ToString();
                            }
                        }
                    }
                }
                catch (Exception objException)
                {
                    LoggingService.LogError(LoggingService.DiagnosticCategoryWebParts, objException.Message);
                }
            });

            return propertyValue;
        }
    }
}
