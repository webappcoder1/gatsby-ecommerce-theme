﻿using System;
using System.Security.Permissions;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using Microsoft.SharePoint.Workflow;
using System.Data;
using System.Collections.Specialized;
using PDO.Solutions.PAISAT.Utilities;

namespace PDO.Solutions.PAISAT.EventReceivers.EmailEvntRcvr
{
    /// <summary>
    /// List Item Events
    /// </summary>
    public class EmailEvntRcvr : SPItemEventReceiver
    {
        /// <summary>
        /// An item was added.
        /// </summary>
        public override void ItemAdded(SPItemEventProperties properties)
        {
            base.ItemAdded(properties);
        }

        /// <summary>
        /// An item was updated.
        /// </summary>
        public override void ItemUpdated(SPItemEventProperties properties)
        {
            base.ItemUpdated(properties);

            SPListItem oitem = properties.ListItem;

            if (Convert.ToBoolean(oitem["IsBulkUpload"]) == false && Convert.ToBoolean(oitem["TriggerEmail"]) == true)
            {
                SendWelcomeEmail(properties.Web);
            }
        }

        private void SendWelcomeEmail(SPWeb oweb)
        {
            string mailBody = string.Empty,
                    mailSubject = string.Empty,
                    userEmail = string.Empty,
                    uerName = string.Empty,
                    siteURL = oweb.Url;
            try
            {
                StringDictionary headers = new StringDictionary();

                SPList olist = oweb.Lists["Employees"];

                SPQuery oquery = new SPQuery();
                oquery.Query = "<Where><Eq><FieldRef Name='IsEmailSent' /><Value Type='Boolean'>0</Value></Eq></Where>";
                SPListItemCollection oitemCol = olist.GetItems(oquery);

                if (oitemCol != null)
                {
                    foreach (SPItem oitem in oitemCol)
                    {
                        if (Convert.ToBoolean(oitem["IsEmailSent"]) == false)
                        {
                            SPFieldUser spFieldUser = (SPFieldUser)oitem.Fields["EmployeeName"];
                            SPFieldUserValue spFieldUserValue = (SPFieldUserValue)spFieldUser.GetFieldValue(oitem["EmployeeName"].ToString());

                            SPUser ouser = spFieldUserValue.User;

                            userEmail = ouser.Email;
                            uerName = ouser.Name;

                            if (!String.IsNullOrEmpty(userEmail))
                            {
                                DataTable dtMailTemplate = GetMailTemplate("PAISAT-Welcome", siteURL);

                                if (dtMailTemplate != null && dtMailTemplate.Rows.Count > 0)
                                {
                                    mailBody = string.Empty;
                                    mailBody = dtMailTemplate.Rows[0]["Body"].ToString();
                                    mailBody = mailBody.Replace("imgEmailHeader", string.Format("<img src={0} alt=''/>", GetEmailImage(siteURL, true)));
                                    mailBody = mailBody.Replace("emailUser", uerName);
                                    mailBody = mailBody.Replace("PAISATLinkURL", string.Format("<a href={0}>here</a>", siteURL));
                                    mailBody = mailBody.Replace("imgEmailFooter", string.Format("<img src={0} alt=''/>", GetEmailImage(siteURL, false)));

                                    mailSubject = dtMailTemplate.Rows[0]["Subject"].ToString();
                                    headers.Clear();
                                    headers.Add("from", "iSecure@pdo.co.om");
                                    headers.Add("to", userEmail);
                                    headers.Add("subject", mailSubject);
                                    headers.Add("content-type", "text/html");

                                    SPUtility.SendEmail(oweb, headers, mailBody);

                                    oitem["IsEmailSent"] = 1;

                                    oitem.Update();
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryRecievers, ex.Message);
            }
        }

        private string GetEmailImage(string siteURL, bool flag)
        {
            string imgURL = string.Empty;

            if (flag)
            {
                imgURL = siteURL + "/PublishingImages/PAISATImages/EmailHeader.jpg";
            }
            else
            {
                imgURL = siteURL + "/PublishingImages/PAISATImages/EmailFooter.jpg";
            }

            return imgURL;
        }

        private DataTable GetMailTemplate(string notificationTemplateName, string siteURL)
        {
            DataTable dtMailTemplate = null;
            SPQuery objSPQuery = null;

            try
            {
                SPSecurity.RunWithElevatedPrivileges(delegate
                {
                    using (SPSite objSPSite = new SPSite(siteURL))
                    {
                        using (SPWeb objSPWebISAT = objSPSite.AllWebs["PAISAT"])
                        {
                            using (dtMailTemplate = new DataTable())
                            {
                                objSPQuery = new SPQuery();
                                objSPQuery.QueryThrottleMode = SPQueryThrottleOption.Override;
                                objSPQuery.Query = @"<Where>
                                     <Eq>
                                        <FieldRef Name='Title' />
                                        <Value Type='Text'>" + notificationTemplateName + @"</Value>
                                     </Eq>
                                   </Where>";
                                objSPQuery.ViewFields = "<FieldRef Name='Title' /><FieldRef Name='Subject' /><FieldRef Name='Body' />";
                                objSPQuery.ViewFieldsOnly = true;
                                string listUrl = objSPWebISAT.ServerRelativeUrl + "/Lists/Notifications";
                                SPList list = objSPWebISAT.GetList(listUrl);
                                dtMailTemplate = list.GetItems(objSPQuery).GetDataTable();
                            }
                        }
                    }
                });

            }
            catch (Exception objException)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryWebParts, objException.Message);
            }

            return dtMailTemplate;
        }


    }
}