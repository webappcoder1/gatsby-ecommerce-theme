﻿using System;
using System.Security.Permissions;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using Microsoft.SharePoint.Workflow;
using PDO.Solutions.PAISAT.Utilities;

namespace PDO.Solutions.PAISAT.EventReceivers.SlidesEvntRcvr
{
    /// <summary>
    /// List Item Events
    /// </summary>
    public class SlidesEvntRcvr : SPItemEventReceiver
    {
        /// <summary>
        /// An item was updated.
        /// </summary>
        public override void ItemUpdated(SPItemEventProperties properties)
        {
            base.ItemUpdated(properties);
            try
            {
                if (properties != null)
                {
                    this.EventFiringEnabled = false;

                    if (properties.List.Title == "Slides")
                    {
                        SPSecurity.RunWithElevatedPrivileges(delegate()
                        {
                            using (SPSite objSPSite = new SPSite(properties.Site.Url))
                            {
                                using (SPWeb objSPWeb = objSPSite.AllWebs[Constants.SITENAME])
                                {
                                    SPList objSPList = objSPWeb.Lists["Slides"];
                                    SPListItem listItem = objSPList.GetItemById(properties.ListItem.ID);

                                    if (listItem["WFStatus"].ToString() == "APP")
                                    {
                                        if (listItem.ModerationInformation != null)
                                        {
                                            if (listItem.ModerationInformation.Status != SPModerationStatusType.Approved)
                                            {
                                                listItem.ModerationInformation.Status = SPModerationStatusType.Approved;
                                                listItem.SystemUpdate();
                                            }
                                        }
                                    }
                                }
                            }
                        });
                    }
                }
            }
            catch (Exception objException)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryRecievers, objException.Message);
            }
            finally
            {
                this.EventFiringEnabled = true;
            }

        }


    }
}