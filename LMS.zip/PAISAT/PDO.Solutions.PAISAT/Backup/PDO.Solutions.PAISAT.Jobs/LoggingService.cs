﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SharePoint.Administration;

namespace PDO.Solutions.PAISAT.Jobs
{
    class LoggingService : SPDiagnosticsServiceBase
    {
        public static string DiagnosticAreaName = "PDO.Solutions.LMS";
        public static string DiagnosticCategoryJobs = "PDO.Solutions.LMS.Jobs";
        private static LoggingService _Current;

        /// <summary>
        /// Returns the current logging service object.
        /// </summary>
        public static LoggingService Current
        {
            get
            {
                if (_Current == null)
                {
                    _Current = new LoggingService();
                }

                return _Current;
            }
        }

        /// <summary>
        /// Set the default Diagnostic area name
        /// </summary>
        private LoggingService()
            : base(DiagnosticAreaName, SPFarm.Local)
        {

        }

        /// <summary>
        /// Initialize Diagnostics areas with category.
        /// </summary>
        /// <returns>IEnumerable collection of Diagnostics Area.</returns>
        protected override IEnumerable<SPDiagnosticsArea> ProvideAreas()
        {
            List<SPDiagnosticsArea> areas = new List<SPDiagnosticsArea>
            {
                new SPDiagnosticsArea(DiagnosticAreaName, new List<SPDiagnosticsCategory>
                {
                    new SPDiagnosticsCategory(DiagnosticCategoryJobs, TraceSeverity.Unexpected, EventSeverity.Error)
                })
            };

            return areas;
        }

        /// <summary>
        /// This method is used to log the errors.
        /// </summary>
        /// <param name="categoryName">Category Name</param>
        /// <param name="errorMessage">Error Message</param>
        public static void LogError(string categoryName, string errorMessage)
        {
            try
            {
                SPDiagnosticsCategory category = LoggingService.Current
                .Areas[DiagnosticAreaName]
                .Categories[categoryName];
                LoggingService.Current.WriteTrace(0, category, TraceSeverity.Unexpected, errorMessage);
            }
            catch(Exception)
            {
               
            }            
        }
    }
}
