﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration;
using System.Net.Mail;
using Microsoft.SharePoint.Administration.DatabaseProvider;
using Microsoft.Office.Server.UserProfiles;
using Microsoft.SharePoint.Linq;
using System.DirectoryServices.ActiveDirectory;
using System.DirectoryServices.AccountManagement;
using System.DirectoryServices;
using System.Web;
using PDO.Solutions.PAISAT.Utilities;
using System.Collections.Specialized;
using Microsoft.SharePoint.Utilities;
using System.Data.SqlClient;

namespace PDO.Solutions.PAISAT.Jobs
{
    /// <summary>
    /// Class for ISAT timer job.
    /// </summary>
    public class ISATJobs : SPJobDefinition
    {
        SPWebApplication webapp = null;
        SPWeb objSPWebISAT = null;
        String smtpAddress = string.Empty, from = "iSecure@pdo.co.om";
        DataTable dtUserData = null;

        /// <summary>
        /// Default 
        /// </summary>
        public ISATJobs()
            : base()
        {

        }

        /// <summary>
        /// Constructor to set the job name.
        /// </summary>
        /// <param name="jobName">Job Name</param>
        /// <param name="webapp">Web Application Name.</param>
        public ISATJobs(string jobName, SPWebApplication webapp)
            : base(jobName, webapp, null, SPJobLockType.Job)
        {
            this.Title = jobName;
        }

        /// <summary>
        /// This method is used to call the appropriated notification methods.
        /// </summary>
        /// <param name="targetInstanceId">Target Instance Id.</param>
        public override void Execute(Guid targetInstanceId)
        {
            webapp = this.Parent as SPWebApplication;
            objSPWebISAT = webapp.Sites["/solutions/LMS"].AllWebs[Constants.SITENAME] as SPWeb;
            //dtUserData = GetUserData();
            AddPrivilgeUsers();
            SendDailyNotification(objSPWebISAT);
        }

        private void AddPrivilgeUsers()
        {
            List<SPUsersEntity> objListUserEntity = null;

            try
            {
                objListUserEntity = new List<SPUsersEntity>();
                objListUserEntity = GetUserProfiles(objSPWebISAT.Site);

                if (objListUserEntity != null)
                {
                    foreach (SPUsersEntity objSPUsersEntity in objListUserEntity)
                    {
                        if (IsCompanyNumberExist(objSPUsersEntity.UserName) == false)
                        {
                            InsertEmployees(objSPUsersEntity);
                        }
                        else
                        {
                            UpdateEmployees(objSPUsersEntity);
                        }
                    }

                    // for disable / removed accounts in AD
                    UpdateDisableAccounts(objListUserEntity);

                }
            }
            catch (Exception objException)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryJobs, objException.Message);
            }
        }

        private void UpdateDisableAccounts(List<SPUsersEntity> objListUserEntity)
        {
            int adProfilesCount = 0, listItemsCount = 0;

            try
            {
                adProfilesCount = objListUserEntity.Count;

                SPSecurity.RunWithElevatedPrivileges(delegate
                {
                    SPList olist = objSPWebISAT.Lists["Employees"];

                    listItemsCount = olist.ItemCount;

                    if (adProfilesCount < listItemsCount)
                    {
                        var camlQuery = new SPQuery()
                        {
                            Query = @"<Where><Lt><FieldRef Name='Modified' /><Value IncludeTimeValue='TRUE' Type='DateTime'>" + DateTime.Today.ToString("yyyy-MM-ddTHH:mm:ssZ") + "</Value></Lt></Where>"
                        };

                        camlQuery.ViewFields = @"<FieldRef Name='Title' />";

                        var olistItems = olist.GetItems(camlQuery);

                        foreach (SPListItem oitem in olistItems)
                        {
                            SPUsersEntity objSPUsersEntity = objListUserEntity.Find(x => x.UserName.Equals(oitem.Title));

                            if (objSPUsersEntity == null)
                            {
                                var updateQuery = new SPQuery()
                                {
                                    Query = @"<Where><Eq><FieldRef Name='Title' /><Value Type='Text'>" + oitem.Title + "</Value></Eq></Where>"
                                };

                                SPListItemCollection oitemsCol = olist.GetItems(updateQuery);

                                if (oitemsCol != null)
                                {
                                    if (oitemsCol.Count > 0)
                                    {
                                        SPListItem item = oitemsCol[0];

                                        item["IsActive"] = 0;

                                        item.Update();
                                    }
                                }
                            }
                        }
                    }
                });
            }
            catch (Exception objException)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryJobs, objException.Message);
            }
        }

        private DataTable GetUserData()
        {
            DataTable dtTable = new DataTable();

            try
            {
                using (SqlConnection sqlCon = new SqlConnection())
                {
                    sqlCon.ConnectionString = "Data Source=MUS-VSQL-002\\SQLINST2;Initial Catalog=LeanReporting;database=LeanReporting;User ID=leanrep;Password=leanpdorep18 ";
                    sqlCon.Open();

                    SqlDataAdapter sqlDa = new SqlDataAdapter("select * from ALL_Members_PAISAT_View", sqlCon);

                    DataSet ds = new DataSet();

                    sqlDa.Fill(ds, "User Data");

                    if (ds.Tables.Count > 0)
                    {
                        dtTable = ds.Tables[0];
                    }
                }
            }
            catch (Exception objException)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryJobs, objException.Message);
            }

            return dtTable;
        }

        //**PROCEDURE  NAME :sp_PAiSATUser_Her
        //@department nvarchar(255), 
        //@Exclude varchar(255),
        //@muid varchar(255) = null
        private DataTable GetUserData(string muID, string department, string exclude)
        {
            DataTable dtTable = new DataTable();

            try
            {
                using (SqlConnection sqlCon = new SqlConnection())
                {
                    sqlCon.ConnectionString = "Data Source=MUS-VSQL-002\\SQLINST2;Initial Catalog=LeanReporting;database=LeanReporting;User ID=leanrep;Password=leanpdorep18 ";
                    sqlCon.Open();

                    DataSet ds = new DataSet();
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = sqlCon;
                    cmd.CommandText = "sp_PAiSATUser_Her"; //  Stored procedure name
                    cmd.CommandType = CommandType.StoredProcedure; // set it to stored proc
                    cmd.Parameters.Add("@department", SqlDbType.VarChar).Value = department;
                    cmd.Parameters.Add("@Exclude", SqlDbType.VarChar).Value = exclude;
                    cmd.Parameters.Add("@muid", SqlDbType.VarChar).Value = muID;

                    SqlDataAdapter sqlDa = new SqlDataAdapter(cmd);
                    sqlDa.Fill(ds, "User Data");

                    if (ds.Tables.Count > 0)
                    {
                        dtTable = ds.Tables[0];
                    }
                }
            }
            catch (Exception objException)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryJobs, objException.Message);
            }

            return dtTable;
        }

        private void InsertEmployees(SPUsersEntity objSPUsersEntity)
        {
            SPUser objSPUserEmployee = null;
            String userGroups = String.Empty, directorate = String.Empty, section = string.Empty, userMUID = string.Empty;

            try
            {
                bool isInGroup = IsUserInGroup(objSPUsersEntity.UserName);

                SPSecurity.RunWithElevatedPrivileges(delegate
                {
                    if (isInGroup)
                    {
                        SPList objSPListEmployees = objSPWebISAT.Lists["Employees"];
                        SPList olistBulkModification = objSPWebISAT.Lists["BulkUploadNotifications"];

                        SPListItem newItem = objSPListEmployees.AddItem();
                        newItem["Title"] = objSPUsersEntity.UserName;
                        newItem["CurrentModuleId"] = 28;
                        newItem["StartDate"] = DateTime.Now;
                        newItem["DisplayName"] = objSPUsersEntity.FirstName + " " + objSPUsersEntity.LastName;
                        newItem["Status"] = "P";

                        //if (objSPUsersEntity.IsActive.Equals("512")) newItem["IsActive"] = 1;
                        //else newItem["IsActive"] = 0;

                        newItem["IsActive"] = 1;
                        newItem["IsEmailSent"] = 0;
                        newItem["NoOfAttempts"] = 0;
                        userGroups = objSPUsersEntity.UserGroups;
                        newItem["MemberOfGroups"] = userGroups;

                        // user data
                        userMUID = "'CORP\\" + objSPUsersEntity.UserName + "'";
                        string refIndicator = objSPUsersEntity.RefIndicator;
                        string muIDOnly = objSPUsersEntity.UserName;

                        DataTable dt = GetUserData(muIDOnly, refIndicator, "MD");
                        string Directorate = string.Empty, Department = string.Empty, Section = string.Empty;

                        //As per Khurram if department is not there then use diretorate ||ly section is not there then use department.
                        //if (muIDOnly.ToUpper().Trim() == "MU57293")

                        if (dt != null && dt.Rows.Count > 0)
                        {
                            //var dd = string.IsNullOrEmpty(dt.Rows[0]["Parents"].ToString());
                            Directorate = dt.Rows[0]["Parents"].ToString() != null && dt.Rows[0]["Parents"].ToString() != "" ? dt.Rows[0]["Parents"].ToString() : string.Empty;
                            Department = dt.Rows.Count > 1 && dt.Rows[1]["Parents"].ToString() != "" ? dt.Rows[1]["Parents"].ToString() : dt.Rows[0]["Parents"].ToString();
                            Section = dt.Rows.Count > 2 && dt.Rows[2]["Parents"].ToString() != "" ? dt.Rows[2]["Parents"].ToString() : dt.Rows[1]["Parents"].ToString();
                        }

                        newItem["Directorate"] = Directorate;
                        newItem["Department"] = Department;
                        newItem["section"] = Section;

                        //** by Pandiyarajan
                        //DataRow[] result = dtUserData.Select("MUID=" + userMUID);

                        //if (result != null)
                        //{
                        //    DataRow dr = result[0];

                        //    if (dr != null)
                        //    {
                        //        newItem["Directorate"] = dr["Directorate"] != null ? dr["Directorate"].ToString() : string.Empty;
                        //        newItem["Department"] = dr["Department"] != null ? dr["Department"].ToString() : string.Empty;
                        //        newItem["section"] = dr["Section"] != null ? dr["Section"].ToString() : string.Empty;
                        //        newItem["ValueStream"] = dr["ValueStream"] != null ? dr["ValueStream"].ToString() : string.Empty;
                        //    }
                        //}


                        try
                        {
                            objSPUserEmployee = objSPWebISAT.EnsureUser(objSPUsersEntity.UserName);
                        }
                        catch (SPException objException)
                        {
                            LoggingService.LogError(LoggingService.DiagnosticCategoryJobs, objException.Message);
                        }

                        if (objSPUserEmployee != null)
                        {
                            newItem["EmployeeName"] = objSPUserEmployee;
                        }

                        newItem.Update();

                        // send welcome email

                        SPListItem oitem = olistBulkModification.Items[0];

                        if (Convert.ToBoolean(oitem["IsBulkUpload"]) == false && Convert.ToBoolean(oitem["TriggerEmail"]) == true)
                        {
                            SendWelcomeEmail(objSPWebISAT, newItem);
                        }
                    }
                });
            }
            catch (Exception objException)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryJobs, objException.Message);
            }
            finally
            {
                objSPUserEmployee = null;
            }
        }

        private void UpdateEmployees(SPUsersEntity objSPUsersEntity)
        {
            String userGroups = String.Empty, userMUID = string.Empty;

            try
            {
                
                SPSecurity.RunWithElevatedPrivileges(delegate
                {
                    SPList objSPListEmployees = objSPWebISAT.Lists["Employees"];

                    SPQuery oquery = new SPQuery();
                    oquery.Query = "<Where><Eq><FieldRef Name='Title' /><Value Type='Text'>" + objSPUsersEntity.UserName + "</Value></Eq></Where>";

                    SPListItemCollection oitemsCol = objSPListEmployees.GetItems(oquery);

                    if (oitemsCol != null)
                    {
                        if (oitemsCol.Count > 0)
                        {
                            SPListItem oitem = oitemsCol[0];

                            oitem["Title"] = objSPUsersEntity.UserName;

                            //commented by Pandiyarajan ** discussed with Audesh and updated this logic. ** 131584 
                            //if (objSPUsersEntity.IsActive.Equals("512")) oitem["IsActive"] = 1;
                            //else oitem["IsActive"] = 0;

                            int flags = int.Parse(objSPUsersEntity.IsActive);
                            if (!Convert.ToBoolean(flags & 0x0002))
                            {
                                //Active User
                                oitem["IsActive"] = 1;
                            }
                            else
                            {
                                //InActive User
                                oitem["IsActive"] = 0;
                            }
                            

                            oitem["DisplayName"] = objSPUsersEntity.FirstName + " " + objSPUsersEntity.LastName;

                            userGroups = objSPUsersEntity.UserGroups;
                            oitem["MemberOfGroups"] = userGroups;

                            // user data
                            userMUID = "'CORP\\" + objSPUsersEntity.UserName + "'";
                            string refIndicator = objSPUsersEntity.RefIndicator;
                            string muIDOnly = objSPUsersEntity.UserName;

                            DataTable dt = GetUserData(muIDOnly, refIndicator, "MD");
                            string Directorate = string.Empty, Department = string.Empty, Section = string.Empty;

                            if (dt != null && dt.Rows.Count > 0)
                            {
                                Directorate = dt.Rows[0]["Parents"].ToString() != null && dt.Rows[0]["Parents"].ToString() != "" ? dt.Rows[0]["Parents"].ToString() : string.Empty;
                                Department = dt.Rows.Count > 1 && dt.Rows[1]["Parents"].ToString() != "" ? dt.Rows[1]["Parents"].ToString() : dt.Rows[0]["Parents"].ToString();
                                Section = dt.Rows.Count > 2 && dt.Rows[2]["Parents"].ToString() != "" ? dt.Rows[2]["Parents"].ToString() : dt.Rows[1]["Parents"].ToString();
                            }

                            oitem["Directorate"] = Directorate;
                            oitem["Department"] = Department;
                            oitem["section"] = Section;


                            //DataRow[] result = dtUserData.Select("MUID=" + userMUID);

                            //if (result != null)
                            //{
                            //    DataRow dr = result[0];

                            //    if (dr != null)
                            //    {
                            //        oitem["Directorate"] = dr["Directorate"] != null ? dr["Directorate"].ToString() : string.Empty;
                            //        oitem["Department"] = dr["Department"] != null ? dr["Department"].ToString() : string.Empty;
                            //        oitem["section"] = dr["Section"] != null ? dr["Section"].ToString() : string.Empty;
                            //        oitem["ValueStream"] = dr["ValueStream"] != null ? dr["ValueStream"].ToString() : string.Empty;
                            //    }
                            //}

                            oitem.Update();
                        }
                    }
                });

            }
            catch (Exception objException)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryJobs, objException.Message);
            }
        }

        private void SendWelcomeEmail(SPWeb oweb, SPListItem newItem)
        {
            string mailBody = string.Empty,
                    mailSubject = string.Empty,
                    userEmail = string.Empty,
                    uerName = string.Empty,
                    siteURL = oweb.Url;
            try
            {
                StringDictionary headers = new StringDictionary();

                if (newItem != null)
                {
                    SPFieldUser spFieldUser = (SPFieldUser)newItem.Fields["EmployeeName"];
                    SPFieldUserValue spFieldUserValue = (SPFieldUserValue)spFieldUser.GetFieldValue(newItem["EmployeeName"].ToString());

                    SPUser ouser = spFieldUserValue.User;

                    userEmail = ouser.Email;
                    uerName = ouser.Name;

                    if (!String.IsNullOrEmpty(userEmail))
                    {
                        DataTable dtMailTemplate = GetMailTemplate("PAISAT-Welcome", siteURL);

                        if (dtMailTemplate != null && dtMailTemplate.Rows.Count > 0)
                        {
                            mailBody = string.Empty;
                            mailBody = dtMailTemplate.Rows[0]["Body"].ToString();
                            mailBody = mailBody.Replace("imgEmailHeader", string.Format("<img src={0} alt=''/>", GetEmailImage(siteURL, true)));
                            mailBody = mailBody.Replace("emailUser", uerName);
                            mailBody = mailBody.Replace("PAISATLinkURL", string.Format("<a href={0}>here</a>", siteURL));
                            mailBody = mailBody.Replace("imgEmailFooter", string.Format("<img src={0} alt=''/>", GetEmailImage(siteURL, false)));

                            mailSubject = dtMailTemplate.Rows[0]["Subject"].ToString();
                            headers.Clear();
                            headers.Add("from", "iSecure@pdo.co.om");
                            headers.Add("to", userEmail);
                            headers.Add("subject", mailSubject);
                            headers.Add("content-type", "text/html");

                            SPUtility.SendEmail(oweb, headers, mailBody);

                            newItem["IsEmailSent"] = 1;

                            newItem.Update();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryJobs, ex.Message);
            }
        }

        private DataTable GetMailTemplate(string notificationTemplateName, string siteURL)
        {
            DataTable dtMailTemplate = null;
            SPQuery objSPQuery = null;

            try
            {
                SPSecurity.RunWithElevatedPrivileges(delegate
                {
                    using (SPSite objSPSite = new SPSite(siteURL))
                    {
                        using (SPWeb objSPWebISAT = objSPSite.AllWebs["PAISAT"])
                        {
                            using (dtMailTemplate = new DataTable())
                            {
                                objSPQuery = new SPQuery();
                                objSPQuery.QueryThrottleMode = SPQueryThrottleOption.Override;
                                objSPQuery.Query = @"<Where>
                                     <Eq>
                                        <FieldRef Name='Title' />
                                        <Value Type='Text'>" + notificationTemplateName + @"</Value>
                                     </Eq>
                                   </Where>";
                                objSPQuery.ViewFields = "<FieldRef Name='Title' /><FieldRef Name='Subject' /><FieldRef Name='Body' />";
                                objSPQuery.ViewFieldsOnly = true;
                                string listUrl = objSPWebISAT.ServerRelativeUrl + "/Lists/Notifications";
                                SPList list = objSPWebISAT.GetList(listUrl);
                                dtMailTemplate = list.GetItems(objSPQuery).GetDataTable();
                            }
                        }
                    }
                });

            }
            catch (Exception objException)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryJobs, objException.Message);
            }

            return dtMailTemplate;
        }

        private bool IsUserInGroup(string companyNumber)
        {
            bool isUserInGroup = false;

            try
            {
                PrincipalContext ctx = new PrincipalContext(ContextType.Domain, Constants.DOMAIN);
                UserPrincipal user = UserPrincipal.FindByIdentity(ctx, companyNumber);
                GroupPrincipal mdGroup = GroupPrincipal.FindByIdentity(ctx, Constants.MD_AD_GROUPNAME);

                if (user != null)
                {
                    if (user.IsMemberOf(mdGroup))
                    {
                        isUserInGroup = true;
                    }
                }
            }
            catch (Exception objException)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryJobs, objException.Message);
            }

            return isUserInGroup;
        }

        private bool IsCompanyNumberExist(string companyNumber)
        {
            bool isExist = false;
            DataTable dtEmployees = null;

            try
            {
                using (dtEmployees = new DataTable())
                {
                    SPQuery query = new SPQuery();

                    query.Query = @"<Where>
                              <Eq>
                                 <FieldRef Name='Title' />
                                 <Value Type='Text'>" + companyNumber.Replace("CORP\\", "") + @"</Value>
                              </Eq>
                           </Where>";

                    query.QueryThrottleMode = SPQueryThrottleOption.Override;
                    query.ViewFields = @"<FieldRef Name='Title' />";
                    query.ViewFieldsOnly = true;
                    string listUrl = objSPWebISAT.ServerRelativeUrl + "/Lists/Employees";
                    SPList list = objSPWebISAT.GetList(listUrl);
                    dtEmployees = list.GetItems(query).GetDataTable();
                    if (dtEmployees != null && dtEmployees.Rows.Count > 0)
                    {
                        isExist = true;
                    }
                }
            }
            catch (Exception objException)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryJobs, objException.Message);
            }
            finally
            {
                dtEmployees = null;
            }

            return isExist;
        }

        private List<SPUsersEntity> GetUserProfiles(SPSite site)
        {
            List<SPUsersEntity> objLstSPUsersEntity = null;
            SPUsersEntity objSPUsersEntity = null;

            try
            {
                objLstSPUsersEntity = new List<SPUsersEntity>();
                PrincipalContext ctx = new PrincipalContext(ContextType.Domain, Constants.DOMAIN);
                GroupPrincipal grpPrincipal = GroupPrincipal.FindByIdentity(ctx, System.DirectoryServices.AccountManagement.IdentityType.Name, Constants.PAISAT_AD_GROUPNAME);

                if (grpPrincipal != null)
                {
                    foreach (Principal prn in grpPrincipal.GetMembers(true))
                    {
                        DirectoryEntry objDirectoryEntry = prn.GetUnderlyingObject() as DirectoryEntry;
                        objSPUsersEntity = new SPUsersEntity();

                        if (objDirectoryEntry.Properties.Contains("displayName"))
                            objSPUsersEntity.DisplayName = objDirectoryEntry.Properties["displayName"].Value.ToString();

                        if (objDirectoryEntry.Properties.Contains("sAMAccountName"))
                            objSPUsersEntity.UserName = objDirectoryEntry.Properties["sAMAccountName"].Value.ToString();

                        if (objDirectoryEntry.Properties.Contains("givenName"))
                            objSPUsersEntity.FirstName = objDirectoryEntry.Properties["givenName"].Value.ToString();

                        if (objDirectoryEntry.Properties.Contains("sn"))
                            objSPUsersEntity.LastName = objDirectoryEntry.Properties["sn"].Value.ToString();

                        if (objDirectoryEntry.Properties.Contains("userAccountControl"))
                            objSPUsersEntity.IsActive = objDirectoryEntry.Properties["userAccountControl"].Value.ToString();

                        if (objDirectoryEntry.Properties.Contains("department"))
                            objSPUsersEntity.RefIndicator = objDirectoryEntry.Properties["department"].Value.ToString();


                        UserPrincipal oUserPrincipal = UserPrincipal.FindByIdentity(ctx, objSPUsersEntity.UserName);
                        objSPUsersEntity.UserGroups = GetUserGroups(oUserPrincipal);

                        objLstSPUsersEntity.Add(objSPUsersEntity);
                    }
                }
            }
            catch (Exception objException)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryJobs, objException.Message);
            }

            return objLstSPUsersEntity;
        }

        private String GetUserGroups(UserPrincipal oUserPrincipal)
        {
            List<String> lstGroups = null;
            StringBuilder sbGroups = null;

            try
            {
                lstGroups = new List<string>();
                sbGroups = new StringBuilder();
                PrincipalSearchResult<Principal> oPrincipalSearchResult = oUserPrincipal.GetGroups();
                lstGroups = oPrincipalSearchResult.AsEnumerable()
                    .Where(principal => principal.Name.EndsWith("-Members-GS"))
                    .Select(principal => principal.Name).ToList<string>();
                foreach (var group in lstGroups)
                {
                    sbGroups.Append(group + ";");
                }
            }
            catch (Exception objException)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryJobs, objException.Message);
            }
            finally
            {
                lstGroups = null;
            }

            return sbGroups.ToString();
        }

        /// <summary>
        /// Method to call pending and expiry notification reminder.
        /// </summary>
        private void SendDailyNotification(SPWeb objSPWebISAT)
        {
            try
            {
                PendingNotificationReminder(objSPWebISAT);
                ExpiryNotificationReminder(objSPWebISAT);
            }
            catch (Exception objException)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryJobs, objException.Message);
            }
        }

        /// <summary>
        /// This method is used to send the expiry notification to the users whose Certificate is due for expiry.
        /// </summary>
        private void ExpiryNotificationReminder(SPWeb objSPWeb)
        {
            DataTable dtAllMailTemplates = null;
            UserInfo objUserInfo = null;
            UserInfo objManagerInfo = null;
            UserInfo objSupervisorInfo = null;
            string siteURL = objSPWeb.Url;
            StringDictionary headers = new StringDictionary();
            string userName = string.Empty, userEmail = string.Empty;
            Dictionary<string, string> userDetail = new Dictionary<string, string>();

            try
            {
                DataTable dtEmployeeCertExpiry = GetEmpCertDueForExpiry();
                if (dtEmployeeCertExpiry != null && dtEmployeeCertExpiry.Rows.Count > 0)
                {
                    int dayCount = 0;

                    using (dtAllMailTemplates = new DataTable())
                    {
                        dtAllMailTemplates = GetAllMailTemplates();

                        if (dtAllMailTemplates != null && dtAllMailTemplates.Rows.Count > 0)
                        {
                            String subject = String.Empty, body = String.Empty;
                            String to = String.Empty, manager = String.Empty, cc = String.Empty;
                            objUserInfo = new UserInfo();
                            objManagerInfo = new UserInfo();
                            objSupervisorInfo = new UserInfo();
                            DataRow drNotificationTemplate = null;

                            foreach (DataRow drEmployee in dtEmployeeCertExpiry.Rows)
                            {
                                userName = userEmail = subject = body = to = manager = cc = String.Empty;

                                try
                                {
                                    DateTime dtCurrentDate = DateTime.Now.Date;
                                    DateTime dtExpiryDate = DateTime.Parse(drEmployee["ExpiryDate"].ToString()).Date;
                                    dayCount = int.Parse(((dtExpiryDate - dtCurrentDate).TotalDays).ToString());

                                    try
                                    {
                                        switch (dayCount)
                                        {
                                            case 28:
                                            case 21:
                                            case 14:
                                            case 7:
                                            case 3:
                                                drNotificationTemplate = (from DataRow drMailTemplate in dtAllMailTemplates.Rows
                                                                          where drMailTemplate["NotificationType"].ToString() == "PAISAT-Expiry-Reminder"
                                                                          select drMailTemplate).FirstOrDefault();

                                                userDetail = GetUserEmailId(drEmployee["Title"].ToString());

                                                foreach (KeyValuePair<string, string> val in userDetail)
                                                {
                                                    if (string.Equals(val.Key, "userName")) userName = val.Value;
                                                    else if (string.Equals(val.Key, "userEmail")) userEmail = val.Value;
                                                }

                                                if (!string.IsNullOrEmpty(userEmail))
                                                {
                                                    subject = drNotificationTemplate["Subject"].ToString();
                                                    body = String.Format(HttpUtility.HtmlDecode("<div style='float:left'>" + drNotificationTemplate["Body"].ToString() + "</div>"), userName, dtExpiryDate.Date.ToString());
                                                    body = body.Replace("imgEmailHeader", string.Format("<img src={0} alt=''/>", GetEmailImage(siteURL, true)));
                                                    body = body.Replace("PAISATLinkURL", string.Format("<a href={0}>here</a>", siteURL));
                                                    body = body.Replace("imgEmailFooter", string.Format("<img src={0} alt=''/>", GetEmailImage(siteURL, false)));
                                                    headers.Clear();
                                                    headers.Add("from", from);
                                                    headers.Add("to", userEmail);
                                                    headers.Add("subject", subject);
                                                    headers.Add("content-type", "text/html");

                                                    SPUtility.SendEmail(objSPWeb, headers, body);
                                                }

                                                break;

                                            case 1:

                                                SPGroup ogroup = objSPWeb.Groups.GetByName("PAISAT-Administrators");

                                                if (ogroup != null)
                                                {
                                                    foreach (SPUser ouser in ogroup.Users)
                                                    {
                                                        to += ouser.Email + ";";
                                                    }
                                                }

                                                drNotificationTemplate = (from DataRow drMailTemplate in dtAllMailTemplates.Rows
                                                                          where drMailTemplate["NotificationType"].ToString() == "PAISAT-Expiry"
                                                                          select drMailTemplate).FirstOrDefault();

                                                userDetail = GetUserEmailId(drEmployee["Title"].ToString());

                                                foreach (KeyValuePair<string, string> val in userDetail)
                                                {
                                                    if (string.Equals(val.Key, "userName")) userName = val.Value;
                                                    else if (string.Equals(val.Key, "userEmail")) userEmail = val.Value;
                                                }

                                                if (!string.IsNullOrEmpty(to))
                                                {
                                                    subject = drNotificationTemplate["Subject"].ToString();
                                                    body = String.Format(HttpUtility.HtmlDecode("<div style='float:left'>" + drNotificationTemplate["Body"].ToString() + "</div>"), userName, dtExpiryDate.Date.ToString());
                                                    body = body.Replace("imgEmailHeader", string.Format("<img src={0} alt=''/>", GetEmailImage(siteURL, true)));
                                                    body = body.Replace("PAISATLinkURL", string.Format("<a href={0}>here</a>", siteURL));
                                                    body = body.Replace("imgEmailFooter", string.Format("<img src={0} alt=''/>", GetEmailImage(siteURL, false)));
                                                    headers.Clear();
                                                    headers.Add("from", from);
                                                    headers.Add("to", userEmail);
                                                    headers.Add("cc", to);
                                                    headers.Add("subject", subject);
                                                    headers.Add("content-type", "text/html");

                                                    SPUtility.SendEmail(objSPWeb, headers, body);
                                                }
                                                break;

                                            default:
                                                break;
                                        }
                                    }
                                    catch (Exception objException)
                                    {
                                        LoggingService.LogError(LoggingService.DiagnosticCategoryJobs, objException.Message);
                                    }
                                }
                                catch (Exception objException)
                                {
                                    LoggingService.LogError(LoggingService.DiagnosticCategoryJobs, objException.Message);
                                }
                            }
                        }

                    }
                }
            }
            catch (Exception objException)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryJobs, objException.Message);
            }
            finally
            {
                dtAllMailTemplates = null;
                objUserInfo = null;
                objManagerInfo = null;
                objSupervisorInfo = null;
            }
        }

        /// <summary>
        /// This method is used to send the Notification reminder the user who has not completed the ISAT.
        /// </summary>
        private void PendingNotificationReminder(SPWeb objSPWeb)
        {
            DataTable dtEmployees = GetEmpByCompletionStatus("P");
            DataTable dtAllMailTemplates = null;
            UserInfo objUserInfo = null;
            UserInfo objManagerInfo = null;
            UserInfo objSupervisorInfo = null;
            int dayCount = 0;
            string siteURL = objSPWeb.Url;
            StringDictionary headers = new StringDictionary();
            string userName = string.Empty, userEmail = string.Empty;
            Dictionary<string, string> userDetail = new Dictionary<string, string>();

            try
            {
                if (dtEmployees != null && dtEmployees.Rows.Count > 0)
                {
                    using (dtAllMailTemplates = new DataTable())
                    {
                        dtAllMailTemplates = GetAllMailTemplates();
                        if (dtAllMailTemplates != null && dtAllMailTemplates.Rows.Count > 0)
                        {
                            String subject = String.Empty, body = String.Empty, to = String.Empty, manager = String.Empty, cc = String.Empty;
                            objUserInfo = new UserInfo();
                            objManagerInfo = new UserInfo();
                            objSupervisorInfo = new UserInfo();
                            DataRow drNotificationTemplate = null;

                            foreach (DataRow drEmployee in dtEmployees.Rows)
                            {
                                try
                                {
                                    userName = userEmail = subject = body = to = manager = cc = String.Empty;
                                    DateTime dtCurrentDate = DateTime.Now.Date;
                                    DateTime dtStartDate = DateTime.Parse(drEmployee["StartDate1"].ToString()).Date;
                                    dayCount = int.Parse(((dtCurrentDate - dtStartDate).TotalDays).ToString());

                                    switch (dayCount)
                                    {
                                        //Notification on 3rd Day
                                        case 3:
                                            drNotificationTemplate = (from DataRow drMailTemplate in dtAllMailTemplates.Rows
                                                                      where drMailTemplate["NotificationType"].ToString() == "PAISAT-Pending-First"
                                                                      select drMailTemplate).FirstOrDefault();

                                            userDetail = GetUserEmailId(drEmployee["Title"].ToString());

                                            foreach (KeyValuePair<string, string> val in userDetail)
                                            {
                                                if (string.Equals(val.Key, "userName")) userName = val.Value;
                                                else if (string.Equals(val.Key, "userEmail")) userEmail = val.Value;
                                            }

                                            if (!string.IsNullOrEmpty(userEmail))
                                            {
                                                subject = drNotificationTemplate["Subject"].ToString();
                                                body = String.Format(HttpUtility.HtmlDecode("<div style='float:left'>" + drNotificationTemplate["Body"].ToString() + "</div>"), userName);
                                                body = body.Replace("imgEmailHeader", string.Format("<img src={0} alt=''/>", GetEmailImage(siteURL, true)));
                                                body = body.Replace("PAISATLinkURL", string.Format("<a href={0}>here</a>", siteURL));
                                                body = body.Replace("imgEmailFooter", string.Format("<img src={0} alt=''/>", GetEmailImage(siteURL, false)));
                                                headers.Clear();
                                                headers.Add("from", from);
                                                headers.Add("to", userEmail);
                                                headers.Add("subject", subject);
                                                headers.Add("content-type", "text/html");

                                                SPUtility.SendEmail(objSPWeb, headers, body);
                                            }

                                            break;

                                        //Notification on 7th & 11th Day
                                        case 7:
                                        case 11:
                                            drNotificationTemplate = (from DataRow drMailTemplate in dtAllMailTemplates.Rows
                                                                      where drMailTemplate["NotificationType"].ToString() == "PAISAT-Pending-Reminder"
                                                                      select drMailTemplate).FirstOrDefault();

                                            userDetail = GetUserEmailId(drEmployee["Title"].ToString());

                                            foreach (KeyValuePair<string, string> val in userDetail)
                                            {
                                                if (string.Equals(val.Key, "userName")) userName = val.Value;
                                                else if (string.Equals(val.Key, "userEmail")) userEmail = val.Value;
                                            }

                                            if (!string.IsNullOrEmpty(userEmail))
                                            {
                                                subject = drNotificationTemplate["Subject"].ToString();
                                                body = String.Format(HttpUtility.HtmlDecode("<div style='float:left'>" + drNotificationTemplate["Body"].ToString() + "</div>"), userName);
                                                body = body.Replace("imgEmailHeader", string.Format("<img src={0} alt=''/>", GetEmailImage(siteURL, true)));
                                                body = body.Replace("PAISATLinkURL", string.Format("<a href={0}>here</a>", siteURL));
                                                body = body.Replace("imgEmailFooter", string.Format("<img src={0} alt=''/>", GetEmailImage(siteURL, false)));
                                                headers.Clear();
                                                headers.Add("from", from);
                                                headers.Add("to", userEmail);
                                                headers.Add("subject", subject);
                                                headers.Add("content-type", "text/html");

                                                SPUtility.SendEmail(objSPWeb, headers, body);
                                            }


                                            break;
                                        //Notification on 14th Day
                                        case 14:

                                            SPGroup ogroup = objSPWeb.Groups.GetByName("PAISAT-Administrators");

                                            if (ogroup != null)
                                            {
                                                foreach (SPUser ouser in ogroup.Users)
                                                {
                                                    to += ouser.Email + ";";
                                                }
                                            }

                                            drNotificationTemplate = (from DataRow drMailTemplate in dtAllMailTemplates.Rows
                                                                      where drMailTemplate["NotificationType"].ToString() == "PAISAT-Pending-Final"
                                                                      select drMailTemplate).FirstOrDefault();

                                            userDetail = GetUserEmailId(drEmployee["Title"].ToString());

                                            foreach (KeyValuePair<string, string> val in userDetail)
                                            {
                                                if (string.Equals(val.Key, "userName")) userName = val.Value;
                                                else if (string.Equals(val.Key, "userEmail")) userEmail = val.Value;
                                            }

                                            if (!string.IsNullOrEmpty(to))
                                            {
                                                subject = drNotificationTemplate["Subject"].ToString();
                                                body = String.Format(HttpUtility.HtmlDecode("<div style='float:left'>" + drNotificationTemplate["Body"].ToString() + "</div>"), userName);
                                                body = body.Replace("imgEmailHeader", string.Format("<img src={0} alt=''/>", GetEmailImage(siteURL, true)));
                                                body = body.Replace("PAISATLinkURL", string.Format("<a href={0}>here</a>", siteURL));
                                                body = body.Replace("imgEmailFooter", string.Format("<img src={0} alt=''/>", GetEmailImage(siteURL, false)));
                                                headers.Clear();
                                                headers.Add("from", from);
                                                headers.Add("to", userEmail);
                                                headers.Add("cc", to);
                                                headers.Add("subject", subject);
                                                headers.Add("content-type", "text/html");

                                                SPUtility.SendEmail(objSPWeb, headers, body);
                                            }
                                            break;

                                        default:
                                            break;
                                    }

                                }
                                catch (Exception objException)
                                {
                                    LoggingService.LogError(LoggingService.DiagnosticCategoryJobs, objException.Message);
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception objException)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryJobs, objException.Message);
            }
            finally
            {
                dtAllMailTemplates = null;
                objUserInfo = null;
                objManagerInfo = null;
                objSupervisorInfo = null;
            }
        }

        private string GetEmailImage(string siteURL, bool flag)
        {
            string imgURL = string.Empty;

            if (flag)
            {
                imgURL = siteURL + "/PublishingImages/PAISATImages/EmailHeader.jpg";
            }
            else
            {
                imgURL = siteURL + "/PublishingImages/PAISATImages/EmailFooter.jpg";
            }

            return imgURL;
        }

        /// <summary>
        /// This method is used to get all the available mail templates.
        /// </summary>
        /// <returns>Returns datatable containing all the notification templates.</returns>
        private DataTable GetAllMailTemplates()
        {
            DataTable dtMailTemplates = null;

            try
            {
                using (dtMailTemplates = new DataTable())
                {
                    objSPWebISAT = webapp.Sites["solutions/LMS"].AllWebs[Constants.SITENAME] as SPWeb;
                    string listUrl = objSPWebISAT.ServerRelativeUrl + "/Lists/Notifications";
                    SPList list = objSPWebISAT.GetList(listUrl);
                    dtMailTemplates = list.GetItems(new string[] { "Title", "Subject", "Body", "Body_AR" }).GetDataTable();
                    dtMailTemplates.Columns[0].ColumnName = "NotificationType";
                    dtMailTemplates.Columns[1].ColumnName = "Subject";
                    dtMailTemplates.Columns[2].ColumnName = "Body";
                    dtMailTemplates.Columns[3].ColumnName = "Body_AR";
                }
            }
            catch (Exception objException)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryJobs, objException.Message);
            }

            return dtMailTemplates;
        }

        private Dictionary<string, string> GetUserEmailId(string companyNumber)
        {
            Dictionary<string, string> userDetail = new Dictionary<string, string>();

            try
            {
                SPSecurity.RunWithElevatedPrivileges(delegate
                {
                    using (SPSite objSPSite = new SPSite(objSPWebISAT.Site.Url))
                    {
                        using (SPWeb objSPWeb = objSPSite.AllWebs[Constants.SITENAME] as SPWeb)
                        {
                            string listUrl = objSPWeb.ServerRelativeUrl + "/Lists/Employees";
                            SPList list = objSPWeb.GetList(listUrl);

                            SPQuery query = new SPQuery();

                            query.Query = "<Where><Eq>" +
                                             "<FieldRef Name='Title'/>" +
                                             "<Value Type='Text'>" + companyNumber + "</Value>" +
                                             "</Eq></Where>";

                            query.ViewFields = "<FieldRef Name='Title' />" +
                                                        "<FieldRef Name='EmployeeName' />";

                            query.ViewFieldsOnly = true;

                            SPListItemCollection olistCol = list.GetItems(query);


                            if (olistCol != null)
                            {
                                if (olistCol.Count > 0)
                                {
                                    SPFieldUser field = olistCol[0].Fields["EmployeeName"] as SPFieldUser;

                                    SPFieldUserValue fieldValue = field.GetFieldValue(Convert.ToString(olistCol[0]["EmployeeName"])) as SPFieldUserValue;

                                    if (fieldValue != null)
                                    {
                                        userDetail.Add("userName", fieldValue.User.Name);
                                        userDetail.Add("userEmail", fieldValue.User.Email);
                                    }
                                }
                            }
                        }
                    }
                });
            }
            catch (Exception objException)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryJobs, objException.Message);
            }


            return userDetail;
        }

        /// <summary>
        /// This method is used to get the list of all the employees whose certificate is due for expiry.
        /// </summary>
        /// <returns>Datatable containing the list of all the employees whose certificate is due for expiry.</returns>
        private DataTable GetEmpCertDueForExpiry()
        {
            DataTable dtEmployees = null;
            SPQuery query = null;

            try
            {
                using (dtEmployees = new DataTable())
                {
                    objSPWebISAT = webapp.Sites["solutions/LMS"].AllWebs[Constants.SITENAME] as SPWeb;
                    query = new SPQuery();
                    DateTime dtExpiryDate = DateTime.Now.AddDays(33);
                    query.Query = @"<Where><And>
                                <Leq>
                                    <FieldRef Name='ExpiryDate' />
                                    <Value IncludeTimeValue='FALSE' Type='DateTime'>" + dtExpiryDate.ToString("yyyy-MM-dd") + @"</Value>
                                </Leq><Eq><FieldRef Name='IsActive' /><Value Type='Boolean'>1</Value></Eq></And>
                            </Where>";

                    query.QueryThrottleMode = SPQueryThrottleOption.Override;
                    query.ViewFields = @"<FieldRef Name='Title' /><FieldRef Name='StartDate1' /><FieldRef Name='ExpiryDate' />";
                    query.ViewFieldsOnly = true;
                    string listUrl = objSPWebISAT.ServerRelativeUrl + "/Lists/Employees";
                    SPList list = objSPWebISAT.GetList(listUrl);
                    dtEmployees = list.GetItems(query).GetDataTable();
                }
            }
            catch (Exception objException)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryJobs, objException.Message);
            }

            return dtEmployees;
        }

        /// <summary>
        /// This method is used to get the list of all the employees ISAT completion status.
        /// </summary>
        /// <param name="status">Status - Possible values P, C(P-Pending & C-Completed)  </param>
        /// <returns>DataTable containing the list of all employees based on the status passed.</returns>
        private DataTable GetEmpByCompletionStatus(string status)
        {
            DataTable dtEmployees = null;
            SPQuery query = null;

            try
            {
                using (dtEmployees = new DataTable())
                {
                    SPWeb web = webapp.Sites["solutions/LMS"].AllWebs[Constants.SITENAME] as SPWeb;
                    query = new SPQuery();
                    query.Query = @"<Where><And><Eq><FieldRef Name='Status' /><Value Type='Text'>" + status + @"</Value></Eq><And><Eq><FieldRef Name='IsEmailSent' /><Value Type='Boolean'>1</Value></Eq><Eq><FieldRef Name='IsActive' /><Value Type='Boolean'>1</Value></Eq></And></And></Where><OrderBy><FieldRef Name='Order' /></OrderBy>";
                    query.QueryThrottleMode = SPQueryThrottleOption.Override;
                    query.ViewFields = @"<FieldRef Name='Title' /><FieldRef Name='StartDate1' /><FieldRef Name='ExpiryDate' /><FieldRef Name='EmployeeName' />";
                    query.ViewFieldsOnly = true;
                    string listUrl = web.ServerRelativeUrl + "/Lists/Employees";
                    SPList list = web.GetList(listUrl);
                    dtEmployees = list.GetItems(query).GetDataTable();
                }
            }
            catch (Exception objException)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryJobs, objException.Message);
            }

            return dtEmployees;
        }

    }
}
