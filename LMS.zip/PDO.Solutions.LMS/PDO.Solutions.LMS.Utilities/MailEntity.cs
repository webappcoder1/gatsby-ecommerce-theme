﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PDO.Solutions.LMS.Utilities
{
    public class MailEntity
    {
        public String SMTPAddress { get; set; }
        public String Subject { get; set; }
        public String Body { get; set; }
        public bool IsBodyHTML { get; set; }
        public String From { get; set; }
        public String To { get; set; }
        public String CC { get; set; }
        public String BCC { get; set; }
    }
}
