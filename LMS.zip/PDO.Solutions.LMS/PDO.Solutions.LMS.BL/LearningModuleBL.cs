﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PDO.Solutions.LMS.DAL;
using Microsoft.SharePoint;

namespace PDO.Solutions.LMS.BL
{
    /// <summary>
    /// BL class for the Learning Module.
    /// </summary>
    public class LearningModuleBL
    {
        SPDAL objSPDAL = new SPDAL();

        /// <summary>
        /// This method returns the slides for the passed Module Id.
        /// </summary>
        /// <param name="moduleId">Module Id</param>
        /// <param name="languageCode">Language Code</param>
        /// <returns>DataTable containing slides for the passed module Id.</returns>
        public DataTable GetSlidesByModuleId(int moduleId, string languageCode)
        {
            return objSPDAL.GetSlidesByModuleId(moduleId, languageCode);
        }

        /// <summary>
        /// This method returns all the modules of ISAT for passed language code.
        /// </summary>
        /// <param name="languageCode">Language Code</param>
        /// <returns>Data table containing all the modules based on the passed language code.</returns>
        public DataTable GetAllModules(string languageCode)
        {
            return objSPDAL.GetAllModules(languageCode);
        }

        /// <summary>
        /// This method returns the current Module Id based on the User Id.
        /// </summary>
        /// <param name="userAdId">User AD Id</param>
        /// <returns>Module Id of the passed AD User Id.</returns>
        public int GetUserCurrentModule(string userAdId)
        {
            return objSPDAL.GetUserCurrentModule(userAdId);
        }

        /// <summary>
        /// This method returns all the slides by Module Id and Language Code.
        /// </summary>
        /// <param name="currentModuleId">Current Module Id</param>
        /// <param name="language">Language Code</param>
        /// <returns>DataTable containing all the slides for the passed Module Id and language code.</returns>
        public DataTable GetAllSlidesByModuelId(int currentModuleId, string language)
        {
             return objSPDAL.GetAllSlidesByModuelId(currentModuleId, language);           
        }

        /// <summary>
        /// This method returns the Module banner image URL for the passed Module Id and Language Code.
        /// </summary>
        /// <param name="currentModuleId">Module Id</param>
        /// <param name="language">Language Code</param>
        /// <returns>Banner image URL</returns>
        public string GetModuleBannerImageUrlById(int currentModuleId, string language)
        {
            return objSPDAL.GetModuleBannerImageUrlById(currentModuleId, language);           
        }

        /// <summary>
        /// This method returns module details for the passed Module Id
        /// </summary>
        /// <param name="currentModuleId">Module Id</param>
        /// <returns>List Item containing details of the passed module Id</returns>
        public SPListItem GetModuleDetailsByModuleId(int currentModuleId)
        {
            return objSPDAL.GetModuleDetailsByModuleId(currentModuleId); 
        }

        /// <summary>
        /// This method returns the Question details based on the passed Module Id and Language code.
        /// </summary>
        /// <param name="currentModuleId">Current Module Id</param>
        /// <param name="questionIds">Question Ids that need to be skipped.</param>
        /// <param name="language">Language Code.</param>
        /// <returns>DataSet containing details about the questions for the passed Module Id.</returns>
        public DataSet GetQuestionDetailsByModuleId(int currentModuleId, string questionIds, string language)
        {
            return objSPDAL.GetQuestionDetailsByModuleId(currentModuleId, questionIds, language);
        }

        /// <summary>
        /// This method returns Template description for the passed template title.
        /// </summary>
        /// <param name="templateTitle">Template Title</param>
        /// <param name="language">Language Code</param>
        /// <returns>Returns string containing template description.</returns>
        public string GetMessageTemplateByTitle(string templateTitle, string language)
        {
            return objSPDAL.GetMessageTemplateByTitle(templateTitle, language);
        }

        /// <summary>
        /// This method returns the next module based on the passed Module Id.
        /// </summary>
        /// <param name="currentModuleId">Current Module Id</param>
        /// <returns>Returns Module Id of the next module Id.</returns>
        public int GetNextLearningModule(int currentModuleId)
        {
            return objSPDAL.GetNextLearningModule(currentModuleId);
        }

        /// <summary>
        /// Method to the set the Users current Module.
        /// </summary>
        /// <param name="userId">User Id</param>
        /// <param name="moduleId">Module Id</param>
        public void SetUsersCurrentModule(string userId, int moduleId)
        {
            objSPDAL.SetUsersCurrentModule(userId, moduleId);
        }

        /// <summary>
        /// This method returns the status of the assessment for the passed module name.
        /// </summary>
        /// <param name="getUserId">User Id</param>
        /// <param name="moduleName">Module Name</param>
        /// <returns>Returns true if the user has completed the module assesment else returns false.</returns>
        public bool IsUserCompletedModuleAssesment(string getUserId, string moduleName)
        {
            return objSPDAL.IsUserCompletedModuleAssesment(getUserId, moduleName);
        }

        /// <summary>
        /// Method to update number of attempts for the User Id.
        /// </summary>
        /// <param name="userId">User Id.</param>
        public void UpdateUserAttempts(string userId)
        {
            objSPDAL.UpdateUserAttempts(userId);
        }
        
        /// <summary>
        /// Method to update User Module assesment.
        /// </summary>
        /// <param name="userId">User Id</param>
        /// <param name="moduleName">Module Name.</param>
        /// <returns>Returns true if the update is successful else returns false.</returns>
        public bool UpdateUserModuleAssesment(string userId, string moduleName, string language)
        {
           return objSPDAL.UpdateUserModuleAssesment(userId, moduleName, language);
        }

        /// <summary>
        /// Method to mark the user assesment status as completed.
        /// </summary>
        /// <param name="userId">User Id</param>
        /// <returns>Returns true if the user assesment is marked as completed else returns false.</returns>
        public bool UpdateUserAssesmentCompleted(string userId)
        {
            return objSPDAL.UpdateUserAssesmentCompleted(userId);
        }

        /// <summary>
        /// Method to check whether the user has completed the assesment.
        /// </summary>
        /// <param name="userId">User Id</param>
        /// <returns>Returns true if the user has completed the assesment else returns false.</returns>
        public bool IsUserCompletedAssesment(string userId)
        {
            return objSPDAL.IsUserCompletedAssesment(userId);
        }

        /// <summary>
        /// This method returns the list item containing details of the user for passed User Id.
        /// </summary>
        /// <param name="userId">User Id</param>
        /// <returns>Returns list item containing details of the User Id.</returns>
        public SPListItem GetUserDetailsByUserId(string userId)
        {
            return objSPDAL.GetUserDetailsByUserId(userId);
        }

        /// <summary>
        /// Method to copy the user result to the history list.
        /// </summary>
        /// <param name="userId">User Id</param>
        public void CopyToHistoryList(string userId)
        {
            objSPDAL.CopyToHistoryList(userId);
        }
    }
}
