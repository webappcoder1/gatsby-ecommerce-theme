﻿using Microsoft.SharePoint;
using System;
using System.Collections;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//using Microsoft.SharePoint.Administration;
using System.Net.Mail;
//using Microsoft.SharePoint.Administration.DatabaseProvider;
//using Microsoft.Office.Server.UserProfiles;
using System.DirectoryServices.AccountManagement;
using System.Data.OleDb;
using System.Data.OracleClient;
using System.Web;
using System.DirectoryServices;
using System.IO;
using Microsoft.SharePoint.Client;
using Microsoft.SharePoint.Utilities;


namespace TestLMSConsoleApp
{
    class Program
    {
        public static string groupName = string.Empty;
        public static string domainName = string.Empty;
        //public static string stgDraftUrl = "http://portal-test.corp.pdo.om/solutions/LMS/ISAT";
        //public static string stgUrl = "http://portal.corp.pdo.om/solutions/LMS/ISAT";



        public static void Main(string[] args)
        {
            //DateTime dt =DateTime.Now;
            //Console.WriteLine(dt.Date.ToString("dd-MMM-yyyy"));

            //int days = int.Parse(((DateTime.Parse("06/07/2021") - DateTime.Parse("5/17/2021")).TotalDays).ToString());
            //Console.Read();

            //UpsertCompletionStatus("", "Housing", "C");
        }


        public static void UpdateHousing()
        {
            String[] housing = getPendingHousing();

            for (int housingCounter = 0; housingCounter < housing.Length; housingCounter++)
            {
                UpsertCompletionStatus(housing[housingCounter].Trim(), "Housing", "P");

            }
            Console.Read();
        }

        public static void UpdateScholars(string siteUrl)
        {
            String[] scholars = getScholars();

            for (int scholarCounter = 0; scholarCounter < scholars.Length; scholarCounter++)
            {


            }
            Console.Read();
        }

        public static string[] getScholars()
        {

            string[] scholars = null;
            return scholars;
        }

        public static string[] getPendingHousing()
        {


            string[] housingUsers = @"MU41110,
MU41717,
MU42234,
MU42236,
MU58409,
MU42418,
MU42574,
MU58364,
MU51685,
MU57665,
MU55755,
MU55647,
MU52538".Split(',');

            return housingUsers;
        }


        private static string[] AllHousingUsers()
        {
            string[] housingUsers = @"MU55755,
MU42234,
MU57665,
MU60086,
MU58409,
MU53845,
MU51685,
MU94628,
MU58364,
MU41110,
MU42236,
MU42418,
MU41717,
MU42574,
MU61528,
MU55446,
MU61169,
MU57828,
MU55590,
MU52538,
MU50090,
MU55647,
MU95188,
MU54698,
MU53700,
MU55434,
MU52397".Split(',');
            return housingUsers;


        }



        #region Migration

        //public static void CopyNotification()
        //{
        //    ListItemCollection allNotification = GetAllItemsISATDraft("Notifications");
        //    ClientContext clientContext = new ClientContext(stgUrl);
        //    var moduleList = clientContext.Web.Lists.GetByTitle("Notifications");
        //    ListItem lstitmNotification = null;

        //    foreach (ListItem sourceNotificationItem in allNotification)
        //    {
        //        if (sourceNotificationItem["ID"].ToString() == "6")
        //        {
        //            lstitmNotification = moduleList.GetItemById(sourceNotificationItem["ID"].ToString());

        //            if (lstitmNotification != null)
        //            {
        //                try
        //                {
        //                    //lstitmNotification["Title"] = sourceNotificationItem["Title"];
        //                    //lstitmNotification["Subject"] = sourceNotificationItem["Subject"];
        //                    //lstitmNotification["Body"] = sourceNotificationItem["Body"];
        //                    //lstitmNotification["Body_AR"] = sourceNotificationItem["Body_AR"];


        //                }
        //                catch (Exception ex)
        //                {
        //                    Console.WriteLine("Error");
        //                }
        //            }
        //        }
        //    }
        //    Console.WriteLine("Done");
        //    Console.Read();
        //}

        //public static void CopyModules()
        //{
        //    ListItemCollection allModules = GetAllDraftModules();
        //    ClientContext clientContext = new ClientContext(stgUrl);
        //    var moduleList = clientContext.Web.Lists.GetByTitle("Modules");
        //    ListItem lstitmModule = null;
        //    foreach (ListItem sourceModuleItem in allModules)
        //    {               

        //        lstitmModule = moduleList.GetItemById(sourceModuleItem["ID"].ToString());
        //        if (lstitmModule != null)
        //        {
        //            try
        //            {
        //                lstitmModule["Title"] = sourceModuleItem["Title"];
        //                lstitmModule["Description"] = sourceModuleItem["Description"];
        //                lstitmModule["BannerImageUrl"] = sourceModuleItem["BannerImageUrl"];
        //                lstitmModule["ModuleTitle_AR"] = sourceModuleItem["ModuleTitle_AR"];
        //                lstitmModule["Description_AR"] = sourceModuleItem["Description_AR"];
        //                lstitmModule["BannerImageUrl_AR"] = sourceModuleItem["BannerImageUrl_AR"];
        //                lstitmModule["PageURL"] = sourceModuleItem["PageURL"];
        //                lstitmModule["Order1"] = sourceModuleItem["Order1"];
        //                lstitmModule["IsActive1"] = sourceModuleItem["IsActive1"];
        //                lstitmModule["NoOfQuestions"] = sourceModuleItem["NoOfQuestions"];
        //                lstitmModule["NoOfQuestionsToPass"] = sourceModuleItem["NoOfQuestionsToPass"];
        //                lstitmModule["RelModuleColumn"] = sourceModuleItem["RelModuleColumn"];
        //                lstitmModule.Update();
        //                clientContext.ExecuteQuery();
        //            }
        //            catch (Exception ex)
        //            {
        //                Console.WriteLine("Error");
        //            }
        //        }
        //    }
        //}

        //public static void CopySlides()
        //{
        //    ListItemCollection allSlides = GetAllItemsISATDraft("Slides");
        //    ClientContext clientContext = new ClientContext(stgUrl);
        //    var slideList = clientContext.Web.Lists.GetByTitle("Slides");
        //    ListItem lstitmSlides = null;

        //    foreach (ListItem sourceSlideItem in allSlides)
        //    {
        //        if (sourceSlideItem["ID"].ToString() == "104")
        //        {
        //            lstitmSlides = slideList.GetItemById(sourceSlideItem["ID"].ToString());
        //            if (lstitmSlides != null)
        //            {
        //                try
        //                {
        //                    //lstitmSlides["Module"] = sourceSlideItem["Module"];
        //                    //lstitmSlides["Title"] = sourceSlideItem["Title"];
        //                    //lstitmSlides["SlideTitle_AR"] = sourceSlideItem["SlideTitle_AR"];
        //                    //lstitmSlides["Order1"] = sourceSlideItem["Order1"];
        //                    //lstitmSlides["IsActive1"] = sourceSlideItem["IsActive1"];
        //                    //lstitmSlides["WFStatus"] = sourceSlideItem["WFStatus"];
        //                    //lstitmSlides["SlideTitleMultiLng"] = sourceSlideItem["SlideTitleMultiLng"];
        //                    //lstitmSlides["Content_AR"] = sourceSlideItem["Content_AR"];
        //                    lstitmSlides["Content1"] = sourceSlideItem["Content1"];

        //                    //lstitmSlides["SlideTitle_AR"] = sourceSlideItem["SlideTitle_AR"];
        //                    //lstitmSlides["SlideTitleMultiLng"] = sourceSlideItem["SlideTitleMultiLng"];
        //                    //lstitmSlides["Content_AR"] = sourceSlideItem["Content_AR"];
        //                    lstitmSlides.Update();
        //                    clientContext.ExecuteQuery();
        //                }
        //                catch (Exception ex)
        //                {
        //                    Console.WriteLine("Error");
        //                }
        //            }
        //        }
        //    }
        //    Console.WriteLine("Done");
        //    Console.Read();
        //}

        //public static void CopyQuestions()
        //{
        //    ListItemCollection allQuestions = GetAllItemsISATDraft("Questions");
        //    ClientContext clientContext = new ClientContext(stgUrl);
        //    var questionList = clientContext.Web.Lists.GetByTitle("Questions");
        //    ListItem lstitmQuestion = null;

        //    foreach (ListItem sourceQuestionItem in allQuestions)
        //    {
        //        lstitmQuestion = questionList.GetItemById(sourceQuestionItem["ID"].ToString());
        //        if (lstitmQuestion != null)
        //        {
        //            try
        //            {
        //                lstitmQuestion["Module"] = sourceQuestionItem["Module"];
        //                lstitmQuestion["QuestionTitle"] = sourceQuestionItem["QuestionTitle"];
        //                lstitmQuestion["QuestionTitle_AR"] = sourceQuestionItem["QuestionTitle_AR"];
        //                lstitmQuestion["Order1"] = sourceQuestionItem["Order1"];
        //                lstitmQuestion["IsActive1"] = sourceQuestionItem["IsActive1"];
        //                lstitmQuestion["IsApproved"] = sourceQuestionItem["IsApproved"];
        //                lstitmQuestion["Title"] = sourceQuestionItem["Title"];                       
        //                lstitmQuestion.Update();
        //                clientContext.ExecuteQuery();
        //            }
        //            catch (Exception ex)
        //            {
        //                Console.WriteLine("Error");
        //            }
        //        }
        //    }
        //    Console.WriteLine("Done");
        //    Console.Read();
        //}

        //public static void CopyAnswers()
        //{
        //    ListItemCollection allAnswers = GetAllItemsISATDraft("Answers");
        //    ClientContext clientContext = new ClientContext(stgUrl);
        //    var answerList = clientContext.Web.Lists.GetByTitle("Answers");
        //    ListItem lstitmAnswer = null;

        //    foreach (ListItem sourceAnswerItem in allAnswers)
        //    {
        //        lstitmAnswer = answerList.GetItemById(sourceAnswerItem["ID"].ToString());
        //        if (lstitmAnswer != null)
        //        {
        //            try
        //            {
        //                lstitmAnswer["Module"] = sourceAnswerItem["Module"];
        //                lstitmAnswer["Title"] = sourceAnswerItem["Title"];
        //                lstitmAnswer["Description"] = sourceAnswerItem["Description"];
        //                lstitmAnswer["Title_AR"] = sourceAnswerItem["Title_AR"];
        //                lstitmAnswer["Description_AR"] = sourceAnswerItem["Description_AR"];
        //                lstitmAnswer["IsCorrect"] = sourceAnswerItem["IsCorrect"];
        //                lstitmAnswer["Question"] = sourceAnswerItem["Question"];                        
        //                lstitmAnswer.Update();
        //                clientContext.ExecuteQuery();
        //            }
        //            catch (Exception ex)
        //            {
        //                Console.WriteLine("Error");
        //            }
        //        }
        //    }
        //    Console.WriteLine("Done");
        //    Console.Read();
        //}

        //public static void CopyNotifications()
        //{
        //    ListItemCollection allNotifications = GetAllItemsISATDraft("Notifications");
        //    ClientContext clientContext = new ClientContext(stgUrl);
        //    var answerList = clientContext.Web.Lists.GetByTitle("Notifications");
        //    ListItem lstitmNotification = null;

        //    foreach (ListItem sourceAnswerItem in allNotifications)
        //    {
        //        lstitmNotification = answerList.GetItemById(sourceAnswerItem["ID"].ToString());
        //        if (lstitmNotification != null)
        //        {
        //            try
        //            {
        //                lstitmNotification["Module"] = sourceAnswerItem["Module"];
        //                lstitmNotification["Title"] = sourceAnswerItem["Title"];
        //                lstitmNotification["Description"] = sourceAnswerItem["Description"];
        //                lstitmNotification["Title_AR"] = sourceAnswerItem["Title_AR"];
        //                lstitmNotification["Description_AR"] = sourceAnswerItem["Description_AR"];
        //                lstitmNotification["IsCorrect"] = sourceAnswerItem["IsCorrect"];
        //                lstitmNotification["Question"] = sourceAnswerItem["Question"];
        //                lstitmNotification.Update();
        //                clientContext.ExecuteQuery();
        //            }
        //            catch (Exception ex)
        //            {
        //                Console.WriteLine("Error");
        //            }
        //        }
        //    }
        //    Console.WriteLine("Done");
        //    Console.Read();
        //}

        //public static void CopyFAQ()
        //{
        //    ListItemCollection allFAQ = GetAllItemsISATDraft("FAQs");
        //    ClientContext clientContext = new ClientContext(stgUrl);
        //    var faqList = clientContext.Web.Lists.GetByTitle("FAQs");
        //    ListItem lstitmFAQ = null;

        //    foreach (ListItem sourceFAQItem in allFAQ)
        //    {
        //        lstitmFAQ = faqList.GetItemById(sourceFAQItem["ID"].ToString());
        //        if (lstitmFAQ != null)
        //        {
        //            try
        //            {
        //                lstitmFAQ["Title"] = sourceFAQItem["Title"];
        //                lstitmFAQ["Category"] = sourceFAQItem["Category"];
        //                lstitmFAQ["Answer"] = sourceFAQItem["Answer"];
        //                lstitmFAQ["Question"] = sourceFAQItem["Question"];
        //                lstitmFAQ.Update();
        //                clientContext.ExecuteQuery();
        //            }
        //            catch (Exception ex)
        //            {
        //                Console.WriteLine("Error");
        //            }
        //        }
        //    }
        //    Console.WriteLine("Done");
        //    Console.Read();
        //}

        //public static ListItemCollection GetAllDraftModules()
        //{
        //    ClientContext context = new ClientContext(stgDraftUrl);
        //    List moduleList = context.Web.Lists.GetByTitle("Modules");
        //    CamlQuery query = CamlQuery.CreateAllItemsQuery(20000);
        //    ListItemCollection items = moduleList.GetItems(query);
        //    context.Load(items);
        //    context.ExecuteQuery();
        //    return items;
        //}

        //public static ListItemCollection GetAllItemsISATDraft(string listName)
        //{
        //    ClientContext context = new ClientContext(stgDraftUrl);
        //    List moduleList = context.Web.Lists.GetByTitle(listName);
        //    CamlQuery query = CamlQuery.CreateAllItemsQuery(20000);
        //    ListItemCollection items = moduleList.GetItems(query);
        //    context.Load(items);
        //    context.ExecuteQuery();
        //    return items;
        //}

        //GetLookupValue(clientContext, drEngOpsSource["Project"].ToString(), "Projects", "ProjectSource", "Text", false);

        public static FieldLookupValue GetLookupValue(ClientContext clientContext, string value, string lookupListName, string lookupFieldName, string lookupFieldType, bool onRootWeb)
        {
            List list = null;
            FieldLookupValue lookupValue = null;

            if (onRootWeb)
            {
                list = clientContext.Site.RootWeb.Lists.GetByTitle(lookupListName);
            }
            else
            {
                list = clientContext.Web.Lists.GetByTitle(lookupListName);
            }

            if (list != null)
            {
                CamlQuery camlQueryForItem = new CamlQuery();
                camlQueryForItem.ViewXml = string.Format(@"<View>
                  <Query>
                      <Where>
                         <Eq>
                             <FieldRef Name='{0}'/>
                             <Value Type='{1}'>{2}</Value>
                         </Eq>
                       </Where>
                   </Query>
            </View>", lookupFieldName, lookupFieldType, value);

                ListItemCollection listItems = list.GetItems(camlQueryForItem);
                clientContext.Load(listItems, items => items.Include
                                                  (listItem => listItem["ID"],
                                                   listItem => listItem[lookupFieldName]));
                clientContext.ExecuteQuery();

                if (listItems != null)
                {
                    ListItem item = listItems[0];
                    lookupValue = new FieldLookupValue();
                    lookupValue.LookupId = int.Parse(item["ID"].ToString());
                }
            }

            return lookupValue;
        }




        #endregion





        public static void RefreshNewMIMDB()
        {
            ListItemCollection allEmployees = GetAllISATRecords();
            foreach (ListItem modifiedItem in allEmployees)
            {
                if (!(modifiedItem["Title"].ToString().Contains("MUEX") || modifiedItem["Title"].ToString().Contains("MUWPH")))
                {
                    UpsertCompletionStatus(modifiedItem["Title"].ToString(), "ISAT", modifiedItem["Status"].ToString());
                }
            }
        }

        ////        private static void GetAllModifiedItems()
        ////        {
        ////            DateTime customDate = DateTime.Now.AddDays(-1);
        ////            string syncRecordsFrom = SPUtility.CreateISO8601DateTimeFromSystemDateTime(customDate); 

        ////            SPListItemCollection objSPListItemCollection = null;
        ////            SPQuery objSPQuery = null;

        ////            try
        ////            {
        ////                SPSecurity.RunWithElevatedPrivileges(delegate()
        ////                {
        ////                    using (SPSite objSPSite = new SPSite("http://mus-ws-546:9000/solutions/COI"))
        ////                    {
        ////                        using (SPWeb objSPWeb = objSPSite.OpenWeb())
        ////                        {
        ////                            objSPWeb.AllowUnsafeUpdates = true;
        ////                            objSPQuery = new SPQuery();
        ////                            objSPQuery.QueryThrottleMode = SPQueryThrottleOption.Override;
        ////                            objSPQuery.Query = @"<ViewFields>
        ////                                                  <FieldRef Name='CC' />
        ////                                                  <FieldRef Name='COI' />
        ////                                                  <FieldRef Name='employeeno' />
        ////                                               </ViewFields>
        ////                                               <Where>
        ////                                                    <Geq>
        ////                                                     <FieldRef Name='Modified' />
        ////                                                     <Value Type='DateTime'>"+ syncRecordsFrom +@"</Value>
        ////                                                  </Geq>
        ////                                               </Where>";

        ////                            objSPQuery.ViewFieldsOnly = true;
        ////                            string listUrl = objSPWeb.ServerRelativeUrl + "/Lists/COIUSERS";
        ////                            SPList list = objSPWeb.GetList(listUrl);
        ////                            objSPListItemCollection = list.GetItems(objSPQuery);
        ////                        }
        ////                    }
        ////                });
        ////            }
        ////            catch (Exception objException)
        ////            {

        ////            }            
        ////        }        

        public static void UpsertCompletionStatus(string companyNumber, string trainingName, string status)
        {
            OracleCommand objOracleCommand = null;
            //string mimConnectionString = Utility.GetPropertyBagValueByKey("MIMLTConnection", siteUrl).ToString();

            //string mimConnectionString = @"Password=co#19mim;User ID=mim_comp;Data Source=  (DESCRIPTION =(ADDRESS = (PROTOCOL = TCP)(HOST = mus-dbvip-202.pdo.shell.om)(PORT = 1521))(CONNECT_DATA =(SERVER = DEDICATED)(SERVICE_NAME = PDOTS202.WORLD)));Persist Security Info=False";

            //Prod:
            string mimConnectionString = @"Password=man#pdo2019;User ID=MIM;Data Source=  (DESCRIPTION =(ADDRESS = (PROTOCOL = TCP)(HOST = mus-dbvip-102.pdo.shell.om)(PORT = 1521))(CONNECT_DATA =(SERVER = DEDICATED)(SERVICE_NAME = PDOPPR01.WORLD)));Persist Security Info=False";


            using (OracleConnection objOracleConnection = new OracleConnection(mimConnectionString))
            {
                objOracleCommand = new OracleCommand();
                objOracleCommand.Connection = objOracleConnection;
                objOracleCommand.CommandText = "SP_UPSERT_MIM_USER_DECL_TRNG";
                objOracleCommand.CommandType = System.Data.CommandType.StoredProcedure;
                try
                {
                    objOracleConnection.Open();
                    objOracleCommand.Parameters.Add("P_ACCOUNTNAME", OracleType.VarChar).Value = companyNumber.Trim();
                    objOracleCommand.Parameters.Add("P_DECL_TRNG_NAME", OracleType.VarChar).Value = trainingName;
                    if (status == "C")
                    {
                        objOracleCommand.Parameters.Add("P_STATUS", OracleType.VarChar).Value = "Completed";
                    }
                    else
                    {
                        objOracleCommand.Parameters.Add("P_STATUS", OracleType.VarChar).Value = "Pending";
                    }
                    objOracleCommand.Parameters.Add("P_ActionResult", OracleType.Number).Direction = System.Data.ParameterDirection.Output;
                    objOracleCommand.ExecuteNonQuery();
                }
                catch (Exception objException)
                {
                    // LoggingService.LogError(LoggingService.DiagnosticCategoryRecievers, objException.Message);
                }
                finally
                {
                    objOracleCommand = null;
                    objOracleConnection.Close();
                }
            }
        }

        public static ListItemCollection GetAllISATRecords()
        {
            ClientContext context = new ClientContext("http://portal.corp.pdo.om/solutions/LMS/ISAT");
            List employeesList = context.Web.Lists.GetByTitle("Employees");
            CamlQuery query = CamlQuery.CreateAllItemsQuery(30000);
            ListItemCollection items = employeesList.GetItems(query);
            context.Load(items);
            context.ExecuteQuery();
            return items;
        }

        //        public static void TestQuery()
        //        {
        //            OracleCommand objOracleCommand = null;
        //            string mimConnectionString = @"Data source=(DESCRIPTION =
        //    (ADDRESS = (PROTOCOL = TCP)(HOST = mus-dbvip-102.pdo.shell.om)(PORT = 1521))
        //    (CONNECT_DATA =
        //      (SERVER = DEDICATED)
        //      (SERVICE_NAME = PFPRD.WORLD)
        //    )
        //  )
        //;User ID=HSEUTIL;Password=util2014;";

        //            using (OracleConnection objOracleConnection = new OracleConnection(mimConnectionString))
        //            {
        //                objOracleCommand = new OracleCommand();
        //                objOracleCommand.Connection = objOracleConnection;
        //                objOracleCommand.CommandText = "select YEARINFO,       FATALITIES,       LTIS,       TRCS,       LASTLTIDATE,       NAD,        to_date(sysdate, 'DD-MON-YY')-LASTLTIDATE-1 as DaysSinceLastLTI   from hserecords  where yearinfo=(select max (yearinfo) from hserecords)";
        //                objOracleCommand.CommandType = System.Data.CommandType.Text;
        //                DataSet dsresult = new DataSet();
        //                try
        //                {
        //                    objOracleConnection.Open();
        //                    OracleDataAdapter oda = new OracleDataAdapter(objOracleCommand);
        //                    oda.Fill(dsresult);
        //                    Console.WriteLine(dsresult.Tables[0].Rows.Count);
        //                }
        //                catch (Exception objException)
        //                {
        //                    Console.Write(objException.Message);
        //                    Console.Read();
        //                }
        //                finally
        //                {
        //                    objOracleCommand = null;
        //                    objOracleConnection.Close();
        //                }
        //            }
        //        }



        //        private static void Searcher()
        //        {
        //            Console.Write("Enter user: ");  
        //         String username = Console.ReadLine();  

        //         try  
        //         {  
        //            // create LDAP connection object  

        //            DirectoryEntry myLdapConnection = createDirectoryEntry();  

        //            // create search object which operates on LDAP connection object  
        //            // and set search object to only find the user specified  

        //            DirectorySearcher search = new DirectorySearcher(myLdapConnection);  
        //            search.Filter = "(cn=" + username + ")";  

        //            // create results objects from search object  

        //            SearchResult result = search.FindOne();  

        //            if (result != null)  
        //            {  
        //               // user exists, cycle through LDAP fields (cn, telephonenumber etc.)  

        //               ResultPropertyCollection fields = result.Properties;  

        //               foreach (String ldapField in fields.PropertyNames)  
        //               {  
        //                  // cycle through objects in each field e.g. group membership  
        //                  // (for many fields there will only be one object such as name)  

        //                  foreach (Object myCollection in fields[ldapField])   
        //                     Console.WriteLine(String.Format("{0,-20} : {1}",   
        //                                   ldapField, myCollection.ToString()));  
        //               }  
        //            }  

        //            else  
        //            {  
        //               // user does not exist  
        //               Console.WriteLine("User not found!");  
        //            }  
        //         }  

        //         catch (Exception e)  
        //         {  
        //            Console.WriteLine("Exception caught:\n\n" + e.ToString());  
        //         }  

        //     }


        //        public static DirectoryEntry createDirectoryEntry()  
        //      {  
        //         // create and return new LDAP connection with desired settings  

        //         DirectoryEntry ldapConnection     = new DirectoryEntry("pdo.co.om");  
        //         //ldapConnection.Path               = "LDAP://OU=staffusers,DC=leeds-art,DC=ac,DC=uk";  
        //         //ldapConnection.AuthenticationType = AuthenticationTypes.Secure;  

        //         return ldapConnection;  
        //      }  




        //        public static void GetADUsers()
        //        {
        //            // groupName = "PDO-UED-Members-GS";
        //            // groupName ="PDO-Students-Members-GS";
        //             groupName = "PDO-All-Students-GS";
        //            // groupName = "PDO-MD-Members-GS";

        //            //groupName = "PDO-TFS-Developer-GS";
        //            domainName = "CORP";

        //            PrincipalContext ctx = new PrincipalContext(ContextType.Domain, domainName);
        //            GroupPrincipal grp = GroupPrincipal.FindByIdentity(ctx, System.DirectoryServices.AccountManagement.IdentityType.Name, groupName);
        //            int icount = 0;

        //            string filecrdt = groupName + "-" + DateTime.Now.ToString("yyyyMMddHHmmssfff");
        //            //string result = "myFile_" + DateTime.Now.ToFileTime() + ".txt";
        //            TextWriter sw = new StreamWriter("E:\\" + filecrdt + "Data.csv");

        //            if (grp != null)
        //            {

        //                foreach (Principal p in grp.GetMembers(true))
        //                {

        //                    string strdepartment = string.Empty, whenModified = string.Empty, stremail = string.Empty, strtitle = string.Empty, whenCreated = string.Empty, whenChanged = string.Empty, displayname = string.Empty;
        //                    string accountstatus = string.Empty;


        //                    //var strmanager = string.Empty;

        //                    DirectoryEntry directoryEntry = p.GetUnderlyingObject() as DirectoryEntry;

        //                    if (directoryEntry.Properties.Contains("displayName"))
        //                        displayname = directoryEntry.Properties["displayName"].Value.ToString();
        //                    if (directoryEntry.Properties.Contains("whenCreated"))
        //                        whenCreated = directoryEntry.Properties["whenCreated"].Value.ToString();
        //                    if (directoryEntry.Properties.Contains("department"))
        //                        strdepartment = directoryEntry.Properties["department"].Value.ToString();
        //                    if (directoryEntry.Properties.Contains("whenChanged"))
        //                        whenChanged = directoryEntry.Properties["whenChanged"].Value.ToString();
        //                    //if (directoryEntry.Properties.Contains("manager"))
        //                    //    strmanager = directoryEntry.Properties["manager"].Value.ToString();
        //                    if (directoryEntry.Properties.Contains("mail"))
        //                        stremail = directoryEntry.Properties["mail"].Value.ToString();
        //                    if (directoryEntry.Properties.Contains("title"))
        //                        strtitle = directoryEntry.Properties["title"].Value.ToString();

        //                    if (directoryEntry.Properties.Contains("userAccountControl"))
        //                        accountstatus = directoryEntry.Properties["userAccountControl"].Value.ToString();

        //                    UserPrincipal users = UserPrincipal.FindByIdentity(ctx, p.Name.ToString());

        //                    Console.WriteLine(p.Name.ToString() + " " + p.DisplayName.ToString() + " " + whenCreated.ToString() + " " + strdepartment.ToString() + " " + stremail.ToString() + " " + strtitle.ToString());


        //                    sw.WriteLine("{0},{1},{2},{3},{4},{5},{6}", p.Name.ToString(), p.DisplayName.ToString(), whenCreated.ToString(), strdepartment.ToString(), stremail.ToString(), strtitle.ToString(), users.Enabled.ToString());
        //                    sw.WriteLine("{0},{1},{2},{3},{4}", p.Name.ToString(), whenCreated.ToString(), stremail.ToString(), users.Enabled.ToString(), whenChanged.ToString());

        //                    sw.WriteLine("{0},{1},{2},{3},{4},{5}, {6}", p.Name.ToString(), whenCreated.ToString(), stremail.ToString(), users.Enabled.ToString(), whenChanged.ToString(), accountstatus, strdepartment.ToString());

        //                    icount = icount + 1;

        //                    //if (users != null && (((UserPrincipal)users).Enabled.Value == true))
        //                    //  {
        //                    //      Console.WriteLine(p.Name.ToString() + " " + p.DisplayName.ToString() + " " + whenCreated.ToString() + " " + strdepartment.ToString() + " " + stremail.ToString() + " " + strtitle.ToString());
        //                    //      sw.WriteLine("{0},{1},{2},{3},{4},{5},{6}", p.Name.ToString(), p.DisplayName.ToString(), whenCreated.ToString(), strdepartment.ToString(), stremail.ToString(), strtitle.ToString(), users.Enabled.ToString());
        //                    //      icount = icount + 1;    
        //                    //  }



        //                }

        //                grp.Dispose();
        //                ctx.Dispose();
        //                sw.Dispose();
        //                sw.Close();

        //            }
        //            else
        //            {
        //                Console.WriteLine("Technical issue");
        //            }
        //            Console.WriteLine(icount);
        //            Console.Read();
        //        }





        //        private static void DeleteItems()
        //        {
        //            DataTable dtEmployees = ReadExcelData(@"E:\Audhesh\CMFExcelData\DeleteISATEmployees.xlsx", ".xlsx", "YES");
        //            Console.WriteLine(dtEmployees.Rows.Count);
        //            using (SPSite objSPSite = new SPSite("http://mus-ws-546:9000/solutions/LMS/ISAT"))
        //            {
        //                using (SPWeb objSPWeb = objSPSite.AllWebs["ISAT"])
        //                {
        //                    SPList oSPList = objSPWeb.Lists["Employees"];
        //                    foreach (DataRow drEmployees in dtEmployees.Rows)
        //                    {   
        //                        SPListItem oSPListItem = oSPList.GetItemById(int.Parse(drEmployees["ID"].ToString()));
        //                        oSPListItem.Delete();
        //                    }
        //                }
        //            }           
        //        }


        //        public static void ResetData()
        //        {
        //            DataTable dtEmployees = ReadExcelData(@"E:\Audhesh\CMFExcelData\UIICUIIO.xlsx", ".xlsx", "YES");
        //            SPListItem newItem = null;

        //            SPSecurity.RunWithElevatedPrivileges(delegate
        //            {
        //                using (SPSite objSPSite = new SPSite("http://mus-ws-546:9000/solutions/LMS/ISAT"))
        //                {
        //                    using (SPWeb objSPWeb = objSPSite.AllWebs["ISAT"])
        //                    {
        //                        SPQuery objSPQuery = null;

        //                        foreach (DataRow drEmployees in dtEmployees.Rows)
        //                        {
        //                            try
        //                            {
        //                                objSPQuery = new SPQuery();
        //                                objSPQuery.QueryThrottleMode = SPQueryThrottleOption.Override;
        //                                objSPQuery.Query = @"<Where>                                 
        //                                     <Eq>
        //                                        <FieldRef Name='Title' />
        //                                        <Value Type='Text'>" + drEmployees["MUID"] + @"</Value>
        //                                     </Eq>                                 
        //                               </Where>";
        //                                string listUrl = objSPWeb.ServerRelativeUrl + "/Lists/Employees";
        //                                SPList list = objSPWeb.GetList(listUrl);
        //                                newItem = list.GetItems(objSPQuery)[0];
        //                                if (newItem != null)
        //                                {
        //                                    newItem["StartDate"] = DateTime.Now;
        //                                    newItem["CompletionDate"] = null;
        //                                    newItem["CurrentModuleId"] = "";
        //                                    newItem["Status"] = "P";
        //                                    newItem["Welcome"] = "P";
        //                                    newItem["InformationClassification"] = "P";
        //                                    newItem["InformationRisk"] = "P";
        //                                    newItem["PhysicalSecurity"] = "P";
        //                                    newItem["MobileSecurity"] = "P";
        //                                    newItem["PasswordProtection"] = "P";
        //                                    newItem["IncidentReporting"] = "P";
        //                                    newItem["MyDesktopTools"] = "P";
        //                                    newItem["ISMS"] = "P";
        //                                    newItem["NoOfAttempts"] = 0;
        //                                    newItem["ExpiryDate"] = null;
        //                                    newItem.Update();
        //                                }
        //                            }
        //                            catch (Exception objException)
        //                            {
        //                                Console.WriteLine(objException.Message);
        //                            }
        //                        }
        //                    }
        //                }
        //            });

        //        }

        //        public static void TestCode()
        //        {
        //            Random objRandom = new Random();
        //            int questionNo = 0;
        //            int count = 0;

        //            while (count <= 11)
        //            {
        //                questionNo = objRandom.Next(1, 12);
        //                //drUserQuestion = dtQuestion.Rows[questionNo - 1];
        //                Console.WriteLine(questionNo.ToString());
        //                questionNo = 0;
        //                count++;
        //            }
        //            Console.Read();

        //        }

        //        public static bool IsUserCompletedAssesment(string userId)
        //        {
        //            bool isCompleted = false;
        //            SPQuery objSPQuery = null;

        //            try
        //            {
        //                SPSecurity.RunWithElevatedPrivileges(delegate()
        //                {
        //                    using (SPSite objSPSite = new SPSite("http://mus-ws-546:9000/solutions/LMS"))
        //                    {
        //                        using (SPWeb objSPWeb = objSPSite.AllWebs["ISAT"])
        //                        {
        //                            objSPQuery = new SPQuery();
        //                            objSPQuery.QueryThrottleMode = SPQueryThrottleOption.Override;

        //                            objSPQuery.Query = @"<Where>
        //                                          <And>
        //                                             <Eq>
        //                                                <FieldRef Name='Title' />
        //                                                <Value Type='Text'>" + userId + @"</Value>
        //                                             </Eq>
        //                                              <Eq>                                      
        //                                                   <FieldRef Name='IsActive' />
        //                                                   <Value Type='Boolean'>1</Value>
        //                                             </Eq>                                       
        //                                          </And>
        //                                   </Where>";
        //                            objSPQuery.ViewFields = @"<FieldRef Name='Status' />";
        //                            objSPQuery.ViewFieldsOnly = true;
        //                            string listUrl = objSPWeb.ServerRelativeUrl + "/Lists/Employees";
        //                            SPList list = objSPWeb.GetList(listUrl);
        //                            SPListItemCollection objSPListItemCollection = list.GetItems(objSPQuery);
        //                            if (objSPListItemCollection != null && objSPListItemCollection.Count > 0)
        //                            {
        //                                SPListItem objSPListItem = objSPListItemCollection[0];
        //                                if (objSPListItem["Status"].ToString() == "C")
        //                                    isCompleted = true;
        //                            }
        //                        }
        //                    }
        //                });
        //            }
        //            catch (Exception objException)
        //            {
        //                //  LoggingService.LogError(LoggingService.DiagnosticCategoryDAL, objException.Message);
        //            }
        //            finally
        //            {
        //                objSPQuery = null;
        //            }

        //            return isCompleted;
        //        }

        //        public static string GetPropertyBagValueByKey(string propertyKey)
        //        {
        //            String propertyValue = String.Empty;

        //            SPSecurity.RunWithElevatedPrivileges(delegate()
        //            {
        //                try
        //                {
        //                    using (SPSite objSPSite = new SPSite("http://mus-ws-546:9000/solutions/LMS"))
        //                    {
        //                        using (SPWeb objSPWeb = objSPSite.AllWebs["ISAT"])
        //                        {
        //                            if (objSPWeb.AllProperties.ContainsKey(propertyKey))
        //                            {
        //                                propertyValue = objSPWeb.AllProperties[propertyKey].ToString();
        //                            }
        //                        }
        //                    }
        //                }
        //                catch (Exception objException)
        //                {
        //                    // LoggingService.LogError(LoggingService., objException.Message);
        //                }
        //            });

        //            return propertyValue;
        //        }

        //        public static void ConnectionCheck()
        //        {
        //            string mimConnectionString = @"Password=pdo2013;User ID=ELIS;Data Source=  (DESCRIPTION =(ADDRESS = (PROTOCOL = TCP)(HOST = mus-n-s0213)(PORT = 1521))(CONNECT_DATA =(SERVER = DEDICATED)(SERVICE_NAME = PLTPID01.WORLD)));Persist Security Info=False";

        //            try
        //            {
        //                using (OracleConnection objOracleConnection = new OracleConnection(mimConnectionString))
        //                {
        //                    objOracleConnection.Open();
        //                }
        //            }
        //            catch(Exception ex)
        //            {
        //                Console.Write(ex.Message);
        //            }
        //            Console.Read();

        //        }

        //        public static void InsertDataToIDM(string companyNumber, DateTime dtDueDate, string status)
        //        {
        //            OracleCommand objOracleCommand = null;
        //            string mimConnectionString = GetPropertyBagValueByKey("MIMConnection").ToString();

        //            using (OracleConnection objOracleConnection = new OracleConnection(mimConnectionString))
        //            {
        //                objOracleCommand = new OracleCommand();
        //                objOracleCommand.Connection = objOracleConnection;
        //                objOracleCommand.CommandText = "SP_INSERT_UPDATE_MIM_USER";
        //                objOracleCommand.CommandType = System.Data.CommandType.StoredProcedure;
        //                try
        //                {
        //                    objOracleConnection.Open();
        //                    objOracleCommand.Parameters.Add("P_MUID", OracleType.VarChar).Value = companyNumber;
        //                    objOracleCommand.Parameters.Add("P_Due_Date", OracleType.DateTime).Value = dtDueDate;
        //                    objOracleCommand.Parameters.Add("P_STATUS", OracleType.VarChar).Value = status;
        //                    objOracleCommand.Parameters.Add("P_ActionResult", OracleType.Number).Direction = System.Data.ParameterDirection.Output;
        //                    objOracleCommand.ExecuteNonQuery();
        //                }
        //                catch (Exception objException)
        //                {
        //                    Console.Write(objException.Message);
        //                    Console.Read();
        //                }
        //                finally
        //                {
        //                    objOracleCommand = null;
        //                    objOracleConnection.Close();
        //                }
        //            }
        //        }

        //        public static void TestInsert(string companyNumber, DateTime dtDueDate, string status)
        //        {
        //            OracleCommand objOracleCommand = null;
        //            string mimConnectionString = GetPropertyBagValueByKey("MIMConnection").ToString();

        //            using (OracleConnection objOracleConnection = new OracleConnection(mimConnectionString))
        //            {
        //                objOracleCommand = new OracleCommand();
        //                objOracleCommand.Connection = objOracleConnection;
        //                objOracleCommand.CommandText = "SP_INSERT_UPDATE_MIM_USER";
        //                objOracleCommand.CommandType = System.Data.CommandType.StoredProcedure;
        //                try
        //                {
        //                    objOracleConnection.Open();
        //                    objOracleCommand.Parameters.Add("P_MUID", OracleType.VarChar).Value = companyNumber;
        //                    objOracleCommand.Parameters.Add("P_Due_Date", OracleType.DateTime).Value = dtDueDate;
        //                    objOracleCommand.Parameters.Add("P_STATUS", OracleType.VarChar).Value = status;
        //                    objOracleCommand.Parameters.Add("P_ActionResult", OracleType.Number).Direction = System.Data.ParameterDirection.Output;
        //                    objOracleCommand.ExecuteNonQuery();
        //                }
        //                catch (Exception objException)
        //                {
        //                    Console.Write(objException.Message);
        //                    Console.Read();
        //                }
        //                finally
        //                {
        //                    objOracleCommand = null;
        //                    objOracleConnection.Close();
        //                }
        //            }
        //        }



        public static void TestInsert(string companyNumber, string trainingName, string status)
        {
            OracleCommand objOracleCommand = null;
            //string mimConnectionString = GetPropertyBagValueByKey("MIMConnection").ToString();

            string mimConnectionString = @"Password=co#19mim;User ID=mim_comp;Data Source=  (DESCRIPTION =(ADDRESS = (PROTOCOL = TCP)(HOST = mus-dbvip-202.pdo.shell.om)(PORT = 1521))(CONNECT_DATA =(SERVER = DEDICATED)(SERVICE_NAME = PDOTS202.WORLD)));Persist Security Info=False";

            using (OracleConnection objOracleConnection = new OracleConnection(mimConnectionString))
            {
                objOracleCommand = new OracleCommand();
                objOracleCommand.Connection = objOracleConnection;
                objOracleCommand.CommandText = "SP_UPSERT_MIM_USER_DECL_TRNG";
                objOracleCommand.CommandType = System.Data.CommandType.StoredProcedure;
                try
                {
                    objOracleConnection.Open();
                    objOracleCommand.Parameters.Add("P_ACCOUNTNAME", OracleType.VarChar).Value = companyNumber;
                    objOracleCommand.Parameters.Add("P_DECL_TRNG_NAME", OracleType.VarChar).Value = trainingName;
                    objOracleCommand.Parameters.Add("P_STATUS", OracleType.VarChar).Value = status;
                    objOracleCommand.Parameters.Add("P_ActionResult", OracleType.Number).Direction = System.Data.ParameterDirection.Output;
                    objOracleCommand.ExecuteNonQuery();
                }
                catch (Exception objException)
                {
                    Console.Write(objException.Message);
                    Console.Read();
                }
                finally
                {
                    objOracleCommand = null;
                    objOracleConnection.Close();
                }
            }
        }



        //        private static DataTable GetAllMailTemplates()
        //        {
        //            DataTable dtMailTemplates = null;
        //            SPSite objSPSite = new SPSite("http://mus-ws-373:9000/solutions/LMS");
        //            SPWeb objSPWeb = objSPSite.AllWebs["ISAT"] as SPWeb;

        //            try
        //            {
        //                using (dtMailTemplates = new DataTable())
        //                {
        //                    string listUrl = objSPWeb.ServerRelativeUrl + "/Lists/Notifications";
        //                    SPList list = objSPWeb.GetList(listUrl);
        //                    dtMailTemplates = list.GetItems(new string[] { "Title", "Subject", "Body" }).GetDataTable();
        //                    dtMailTemplates.Columns[0].ColumnName = "NotificationType";
        //                    dtMailTemplates.Columns[1].ColumnName = "Subject";
        //                    dtMailTemplates.Columns[2].ColumnName = "Body";
        //                    string result = String.Format(HttpUtility.HtmlDecode(dtMailTemplates.Rows[0]["Body"].ToString()), "Audhesh Jaiswdzs.,");

        //                }
        //            }
        //            catch (Exception objException)
        //            {

        //            }

        //            return dtMailTemplates;
        //        }

        //        public static int GetNextLearningModule(int currentModuleId)
        //        {
        //            SPListItem objSPListItemCurrentModule = null;
        //            int nextLearningModuleId = 0;

        //            try
        //            {
        //                SPSecurity.RunWithElevatedPrivileges(delegate()
        //                {
        //                    using (SPSite objSPSite = new SPSite("http://mus-ws-546:9000/solutions/LMS"))
        //                    {
        //                        using (SPWeb objSPWeb = objSPSite.AllWebs["ISAT"])
        //                        {
        //                            objSPListItemCurrentModule = (from SPListItem module in objSPWeb.Lists["Modules"].Items
        //                                                          where module["ID"].ToString() == currentModuleId.ToString()
        //                                                          select module).FirstOrDefault();

        //                            if (objSPListItemCurrentModule != null)
        //                            {
        //                                /*SPListItem objSPListItemNextModule = (from SPListItem module in objSPWeb.Lists["Modules"].Items
        //                                                                      where int.Parse(module["Order"].ToString()) > int.Parse(objSPListItemCurrentModule["Order"].ToString())
        //                                                                      select module).FirstOrDefault();*/

        //                                SPListItem objSPListItemNextModule = (from SPListItem module in objSPWeb.Lists["Modules"].Items
        //                                                                      where int.Parse(module["Order1"].ToString()) == int.Parse(objSPListItemCurrentModule["Order1"].ToString()) + 1
        //                                                                      select module).FirstOrDefault();


        //                                if (objSPListItemNextModule != null)
        //                                {
        //                                    nextLearningModuleId = int.Parse(objSPListItemNextModule["ID"].ToString());
        //                                }
        //                            }
        //                        }
        //                    }
        //                });
        //            }
        //            catch (Exception objException)
        //            {
        //                //LoggingService.LogError(LoggingService.DiagnosticCategoryDAL, objException.Message);
        //            }

        //            return nextLearningModuleId;
        //        }

        //        private static DataTable GetEmpCertDueForExpiry()
        //        {
        //            DataTable dtEmployees = null;
        //            SPQuery query = null;
        //            SPSite objSPSite = new SPSite("http://mus-ws-373:9000/solutions/LMS");
        //            SPWeb objSPWeb = objSPSite.AllWebs["ISAT"] as SPWeb;

        //            try
        //            {
        //                using (dtEmployees = new DataTable())
        //                {
        //                    query = new SPQuery();
        //                    DateTime dtExpiryDate = DateTime.Now.AddDays(33);
        //                    query.Query = @"                               
        //                                <Where>
        //                                <Leq>
        //                                    <FieldRef Name='ExpiryDate' />
        //                                    <Value IncludeTimeValue='FALSE' Type='DateTime'>" + dtExpiryDate.ToString("yyyy-MM-dd") + @"</Value>
        //                                </Leq>
        //                            </Where>";

        //                    query.QueryThrottleMode = SPQueryThrottleOption.Override;
        //                    query.ViewFields = "<FieldRef Name='Title' /><FieldRef Name='StartDate1' /><FieldRef Name='ExpiryDate' />";
        //                    query.ViewFieldsOnly = true;
        //                    string listUrl = objSPWeb.ServerRelativeUrl + "/Lists/Employees";
        //                    SPList list = objSPWeb.GetList(listUrl);
        //                    dtEmployees = list.GetItems(query).GetDataTable();
        //                }
        //            }
        //            catch (Exception objException)
        //            {

        //            }

        //            return dtEmployees;
        //        }

        //        private static string GetUserEmailId(string companyNumber)
        //        {
        //            SPSite objSPSite = new SPSite("http://mus-ws-373:9000/solutions/LMS");
        //            SPWeb objSPWeb = objSPSite.AllWebs["ISAT"] as SPWeb;
        //            String emailId = String.Empty;
        //            SPUser objSPUser = objSPWeb.EnsureUser(companyNumber);
        //            SPServiceContext serverContext = SPServiceContext.GetContext(objSPWeb.Site);

        //            if (objSPUser != null)
        //            {
        //                emailId = objSPUser.Email;
        //            }

        //            UserProfileManager profileManager = new UserProfileManager(serverContext);
        //            UserProfile profile = profileManager.GetUserProfile(companyNumber);
        //            string managerName = (string)profile["manager"].Value;
        //            SPUser objSPUserManager = objSPWeb.EnsureUser(managerName);
        //            emailId = objSPUserManager.Email;
        //            return emailId;

        //        }


        //        //private static void GetUserEmailId(string companyNumber)
        //        //{
        //        //    SPSite objSPSite = new SPSite("http://mus-ws-373:9000/solutions/LMS");
        //        //    SPWeb objSPWeb = objSPSite.AllWebs["ISAT"] as SPWeb;

        //        //    SPUser user = objSPWeb.EnsureUser(companyNumber);
        //        //    Console.WriteLine(user.Email.ToString());
        //        //    Console.Read();
        //        //}

        //        private static DataTable GetEmpCertDueForExpirya()
        //        {
        //            String webUrl = String.Empty;
        //            DataTable dtEmployees = new DataTable();
        //            //SPWeb web = webapp.Sites["LMS"].AllWebs["ISAT"] as SPWeb;
        //            SPSite objSPSite = new SPSite("http://mus-ws-373:9000/solutions/LMS");
        //            SPWeb rootWeb = objSPSite.AllWebs["ISAT"] as SPWeb;

        //            String from = rootWeb.Site.WebApplication.OutboundMailSenderAddress;
        //            String smtpAddress = rootWeb.Site.WebApplication.OutboundMailServiceInstance.Server.Address;


        //            SendMail(smtpAddress, "Hello", "body", true, from, "Audhesh.AJ.Jaiswal@pdo.co.om", "Audhesh.AJ.Jaiswal@pdo.co.om", "Audhesh.AJ.Jaiswal@pdo.co.om");

        //            using (SPWeb web = objSPSite.AllWebs["ISAT"] as SPWeb)
        //            {
        //                SPQuery query = new SPQuery();
        //                DateTime dtExpiryDate = DateTime.Now.AddDays(-7);

        //                query.Query = @"<Where>
        //                                <Geq>
        //                                    <FieldRef Name='ExpiryDate' />
        //                                    <Value IncludeTimeValue='FALSE' Type='DateTime'>" + dtExpiryDate.ToString("yyyy-MM-dd") + @"</Value>
        //                                </Geq>
        //                               </Where>";
        //                query.QueryThrottleMode = SPQueryThrottleOption.Override;
        //                query.ViewFields = @"<FieldRef Name='CompanyNumber' /><FieldRef Name='StartDate' /><FieldRef Name='ExpiryDate' />";
        //                query.ViewFieldsOnly = true;
        //                string listUrl = web.ServerRelativeUrl + "/Lists/Employees";
        //                SPList list = web.GetList(listUrl);
        //                dtEmployees = list.GetItems(query).GetDataTable();
        //            }

        //            return dtEmployees;
        //        }

        //        public static bool SendMail(string smtpAddress, string subject, string body, bool isBodyHtml, string from, string to, string cc, string bcc)
        //        {
        //            bool mailSent = false;
        //            SmtpClient smtpClient = null;

        //            try
        //            {
        //                // Assign SMTP address   
        //                smtpClient = new SmtpClient();
        //                smtpClient.Host = smtpAddress;

        //                //Create an email message   
        //                MailMessage mailMessage = new MailMessage(from, to, subject, body);
        //                if (!String.IsNullOrEmpty(cc))
        //                {
        //                    MailAddress CCAddress = new MailAddress(cc);
        //                    mailMessage.CC.Add(CCAddress);
        //                }
        //                if (!String.IsNullOrEmpty(bcc))
        //                {
        //                    MailAddress BCCAddress = new MailAddress(bcc);
        //                    mailMessage.Bcc.Add(BCCAddress);
        //                }
        //                mailMessage.IsBodyHtml = isBodyHtml;
        //                // Send the email   
        //                smtpClient.Send(mailMessage);
        //                mailSent = true;
        //            }
        //            catch (Exception)
        //            {
        //                mailSent = false;
        //            }
        //            return mailSent;
        //        }

        //        private static DataTable GetEmpByCompletionStatus(string status)
        //        {
        //            String webUrl = String.Empty;

        //            DataTable dtEmployees = new DataTable();
        //            SPSite objSPSite = new SPSite("http://mus-ws-373:9000/solutions/LMS");

        //            using (SPWeb web = objSPSite.AllWebs["ISAT"] as SPWeb)
        //            {
        //                SPQuery query = new SPQuery();

        //                query.Query = @"<Where><Eq><FieldRef Name='Status' /><Value Type='Text'>" + status + @"</Value></Eq></Where>
        //                                <OrderBy>
        //                                  <FieldRef Name='Order' />
        //                                </OrderBy>";
        //                query.QueryThrottleMode = SPQueryThrottleOption.Override;
        //                query.ViewFields = @"<FieldRef Name='CompanyNumber' /><FieldRef Name='StartDate' /><FieldRef Name='ExpiryDate' />";
        //                query.ViewFieldsOnly = true;
        //                string listUrl = web.ServerRelativeUrl + "/Lists/Employees";
        //                SPList list = web.GetList(listUrl);
        //                dtEmployees = list.GetItems(query).GetDataTable();
        //                return dtEmployees;
        //            }
        //        }

        //        private static void Test()
        //        {
        //            SPSecurity.RunWithElevatedPrivileges(delegate()
        //            {
        //                using (SPSite objSPSite = new SPSite("http://mus-ws-546:9000/solutions/LMS"))
        //                {
        //                    objSPSite.AllowUnsafeUpdates = true;

        //                    using (SPWeb objSPWeb = objSPSite.AllWebs["ISAT"] as SPWeb)
        //                    {
        //                      //  string displayName = GetADUserDisplayName("MU58285");
        //                        Console.WriteLine(objSPWeb.SiteUsers.Count);
        //                        SPUser objSPUserEmployee = objSPWeb.EnsureUser(@"CORP\MU58285");
        //                        Console.WriteLine(objSPUserEmployee.Email);
        //                    }

        //                    objSPSite.AllowUnsafeUpdates = false;
        //                }
        //            });
        //        }

        //        private static void UpdateDirectorates()
        //        {
        //            using (SPSite objSPSite = new SPSite("http://mus-ws-546:9000/solutions/LMS"))
        //            {
        //                objSPSite.AllowUnsafeUpdates = true;
        //                using (SPWeb objSPWeb = objSPSite.AllWebs["ISAT"] as SPWeb)
        //                {
        //                    objSPWeb.AllowUnsafeUpdates = true;
        //                    SPList objSPListEmployees = objSPWeb.Lists["Employees"];
        //                    SPList objSPListDirectorates = objSPWeb.Lists["Directorates"];
        //                    String directorate = String.Empty;
        //                    foreach (SPListItem empItem in objSPListEmployees.Items)
        //                    {
        //                        directorate = GetUserDirectorate(empItem["MemberOfGroups"] != null ? empItem["MemberOfGroups"].ToString() : "Others", objSPListDirectorates);
        //                        empItem["Directorate"] = directorate;
        //                        empItem.SystemUpdate();
        //                    }
        //                    objSPWeb.AllowUnsafeUpdates = false;
        //                }
        //                objSPSite.AllowUnsafeUpdates = false;

        //            }
        //        }

        //        private static void UpdateOtherDirectorates()
        //        {
        //            using (SPSite objSPSite = new SPSite("http://mus-ws-546:9000/solutions/LMS"))
        //            {
        //                objSPSite.AllowUnsafeUpdates = true;
        //                using (SPWeb objSPWeb = objSPSite.AllWebs["ISAT"] as SPWeb)
        //                {
        //                    objSPWeb.AllowUnsafeUpdates = true;
        //                    SPList objSPListEmployees = objSPWeb.Lists["Employees"];
        //                    SPList objSPListDirectorates = objSPWeb.Lists["Directorates"];
        //                    String directorate = String.Empty;
        //                    SPListItemCollection objSPListItemColl = objSPWeb.Lists["Employees"].Items;
        //                    foreach (SPListItem empItem in objSPListItemColl)
        //                    {
        //                        if (empItem["Directorate"].ToString() == "Others")
        //                        {
        //                            directorate = GetUserDirectorate(empItem["MemberOfGroups"] != null ? empItem["MemberOfGroups"].ToString() : "Others", objSPListDirectorates);
        //                            if (directorate != "Others")
        //                            {
        //                                empItem["Directorate"] = directorate;
        //                                empItem.SystemUpdate();
        //                            }
        //                        }
        //                    }
        //                    objSPWeb.AllowUnsafeUpdates = false;
        //                }
        //                objSPSite.AllowUnsafeUpdates = false;

        //            }
        //        }

        //        public static bool ContainsGroup(this String groupNames, string adGroups)
        //        {
        //            bool isMember = false;
        //            isMember = adGroups.Split(';').Where(group => groupNames.Contains(group) && group != "").Any();

        //            return isMember;
        //        }

        //        private static String GetADUserDisplayName(string userADId)
        //        {
        //            string displayName = String.Empty;
        //            PrincipalContext objPrincipalContext = null;

        //            try
        //            {

        //                objPrincipalContext = new PrincipalContext(ContextType.Domain, "CORP");
        //                UserPrincipal user = UserPrincipal.FindByIdentity(objPrincipalContext, userADId);
        //                DirectoryEntry objDirectoryEntry = user.GetUnderlyingObject() as DirectoryEntry;

        //                if (user != null)
        //                {
        //                    if (objDirectoryEntry.Properties.Contains("displayName"))
        //                        displayName = objDirectoryEntry.Properties["displayName"].Value.ToString();
        //                }

        //            }
        //            catch (Exception objException)
        //            {
        //                // LoggingService.LogError(LoggingService.DiagnosticCategoryJobs, objException.Message);
        //            }
        //            finally
        //            {
        //                objPrincipalContext = null;
        //            }

        //            return displayName;
        //        }

        //        private static string GetUserDirectorate(String groupNames, SPList objDirectorateList)
        //        {
        //            var res = (from SPListItem objSPListItem in objDirectorateList.Items
        //                       where groupNames.ContainsGroup(objSPListItem["ADGroupName"].ToString()) &&
        //                       bool.Parse(objSPListItem["IsActive"].ToString()) == true
        //                       select objSPListItem["Directorate"].ToString()).FirstOrDefault();

        //            if (String.IsNullOrEmpty(res))
        //            {
        //                res = "Others";
        //            }

        //            return res;

        //            //string directorateName = "Others";

        //            //var resdirectorateName= from objDirectorate

        //            //return directorateName;        
        //        }


        //        private static void AssignUniquePermission()
        //        {

        //            //Connect to Sharepoint Site

        //            SPSite oSPSite = new SPSite("http://mus-ws-373:9000/solutions/LMS/ISAT");

        //            //Open Sharepoint Site

        //            SPWeb oSPWeb = oSPSite.OpenWeb();

        //            //get the Sharepoint List

        //            SPList oSPList = oSPWeb.Lists["MenuLinks"];

        //            //Get the Sharepoint list item for giving permission

        //            SPListItem oSPListItem = oSPList.GetItemById(17);
        //            Console.WriteLine(oSPListItem["Title"]);
        //            RemoveAllPermissions(oSPListItem, oSPWeb);

        //        }

        //        private static void RemoveAllPermissions(SPListItem oSPListItem, SPWeb oSPWeb)
        //        {

        //            //The below function Breaks the role assignment inheritance for the list and gives the current list its own copy of the role assignments

        //            oSPListItem.BreakRoleInheritance(true);

        //            //Get the list of Role Assignments to list item and remove one by one.

        //            SPRoleAssignmentCollection SPRoleAssColn = oSPListItem.RoleAssignments;

        //            for (int i = SPRoleAssColn.Count - 1; i >= 0; i--)
        //            {
        //                SPRoleAssColn.Remove(i);

        //            }

        //            Console.WriteLine("All Permissions Removed");

        //            //Create new user to grant access

        //            SPGroupCollection groups = oSPWeb.Groups;

        //            //SPUser CurrentUser = users["Domain\\Administrator"];
        //            SPGroup CurrentGroup = groups.GetByName("ISAT-Administrators");
        //            /*
        //                        ISAT-ContentApprovers
        //            ISAT-ContentAuthors
        //            ISAT-DashboardViewers
        //            ISAT-Visitors */


        //            //Add new permissions to List Items

        //            //If you want to give access to a Group than pass SPGroup instead of SPUser. The same function will give access.

        //            //GrantPermission(oSPListItem, oSPWeb, SPRoleType.Contributor, CurrentGroup);

        //        }

        //        private static void GrantPermission(SPListItem CurrentListItem, SPWeb oSPWeb, SPRoleType SPRoleType, SPPrincipal SPPrincipal)
        //        {

        //            //Create one Role Definition i.e Full Controls, Contribute rights or Read rights etc.

        //            SPRoleDefinition oSPRoleDefinition = oSPWeb.RoleDefinitions.GetByType(SPRoleType);

        //            //Create one Role Assignment for the specified SP user or group.
        //            SPRoleAssignment oSPRoleAssignment = new SPRoleAssignment(SPPrincipal);
        //            //Bind the role definition to the role assignment object created for the user or group.
        //            oSPRoleAssignment.RoleDefinitionBindings.Add(oSPRoleDefinition);
        //            //Add it to the specified list item.
        //            CurrentListItem.RoleAssignments.Add(oSPRoleAssignment);
        //            //update the list item so that specified user assignment will have the access.
        //            CurrentListItem.Update();
        //            Console.WriteLine("All Permissions Removed");
        //            Console.Read();

        //        }

        //        private static void UpdateEmployeesGroups()
        //        {
        //            using (SPSite objSPSite = new SPSite("http://mus-ws-373:9000/solutions/LMS"))
        //            {
        //                objSPSite.AllowUnsafeUpdates = true;
        //                using (SPWeb objSPWeb = objSPSite.AllWebs["ISAT"] as SPWeb)
        //                {
        //                    objSPWeb.AllowUnsafeUpdates = true;
        //                    SPList objSPListEmployees = objSPWeb.Lists["Employees"];
        //                    String memberofGroups = String.Empty;
        //                    foreach (SPListItem empItem in objSPListEmployees.Items)
        //                    {
        //                        memberofGroups = GetUserGroups(empItem["CompanyNumber"].ToString());
        //                        empItem["MemberOfGroups"] = memberofGroups;
        //                        empItem.SystemUpdate();
        //                    }
        //                    objSPWeb.AllowUnsafeUpdates = false;
        //                }
        //                objSPSite.AllowUnsafeUpdates = false;

        //            }
        //        }

        //        private static void UpdateEmployeeName()
        //        {
        //            DataTable dtEmployees = ReadExcelData(@"E:\Audhesh\CMFExcelData\EmployeeDispName.xlsx", ".xlsx", "YES");

        //            using (SPSite objSPSite = new SPSite("http://mus-ws-373:9000/solutions/LMS"))
        //            {
        //                objSPSite.AllowUnsafeUpdates = true;
        //                using (SPWeb objSPWeb = objSPSite.AllWebs["ISAT"] as SPWeb)
        //                {
        //                    objSPWeb.AllowUnsafeUpdates = true;
        //                    SPList objSPListEmployees = objSPWeb.Lists["Employees"];
        //                    String memberofGroups = String.Empty;

        //                    foreach (SPListItem empItem in objSPListEmployees.Items)
        //                    {
        //                        try
        //                        {
        //                            var fullName = dtEmployees.AsEnumerable()
        //                                 .Where(emp => emp["COMPANY_NUMBER"].ToString() == empItem["CompanyNumber"].ToString())
        //                                 .Select(res => res["FIRST_NAME"].ToString() + " " + res["LAST_NAME"].ToString()).FirstOrDefault();
        //                            if (fullName != null)
        //                            {
        //                                empItem["DisplayName"] = fullName.ToString();
        //                                empItem.Update();
        //                            }
        //                        }
        //                        catch (Exception objException)
        //                        {
        //                            Console.WriteLine("Not found");
        //                        }
        //                    }
        //                    objSPWeb.AllowUnsafeUpdates = false;
        //                }
        //                objSPSite.AllowUnsafeUpdates = false;
        //            }
        //        }

        //        private static void InsertAllISATData()
        //        {
        //            DataTable dtEmployees = ReadExcelData(@"E:\Audhesh\CMFExcelData\NewMissing.xlsx", ".xlsx", "YES");

        //            using (SPSite objSPSite = new SPSite("http://mus-ws-546:9000/solutions/LMS"))
        //            {
        //                objSPSite.AllowUnsafeUpdates = true;
        //                Console.WriteLine(dtEmployees.Rows.Count);
        //                using (SPWeb objSPWeb = objSPSite.AllWebs["ISAT"] as SPWeb)
        //                {
        //                    objSPWeb.AllowUnsafeUpdates = true;
        //                    SPList objSPListEmployees = objSPWeb.Lists["Employees"];
        //                    SPList objSPListDirectorates = objSPWeb.Lists["Directorates"];
        //                    SPUser objSPUserEmployee = null;
        //                    String directorate = String.Empty;

        //                    foreach (DataRow drEmployees in dtEmployees.Rows)
        //                    {
        //                        SPListItem newItem = objSPListEmployees.AddItem();
        //                        newItem["Title"] = drEmployees["COMPANYNUMBER"].ToString();
        //                        newItem["StartDate"] = DateTime.Parse(drEmployees["STARTDATE"].ToString());
        //                        if (drEmployees["COMPLETIONDATE"].ToString() != "")
        //                            newItem["CompletionDate"] = DateTime.Parse(drEmployees["COMPLETIONDATE"].ToString());
        //                        newItem["CurrentModuleId"] = drEmployees["CURRENTMODULEID"].ToString();
        //                        newItem["Status"] = drEmployees["STATUS"].ToString();
        //                        if (drEmployees["ISACTIVE"].ToString() == "Yes")
        //                            newItem["IsActive"] = 1;
        //                        else
        //                            newItem["IsActive"] = 0;
        //                        newItem["Welcome"] = drEmployees["WELCOME"].ToString();
        //                        newItem["InformationClassification"] = drEmployees["INFORMATIONCLASSIFICATION"].ToString();
        //                        newItem["InformationRisk"] = drEmployees["INFORMATIONRISK"].ToString();
        //                        newItem["PhysicalSecurity"] = drEmployees["PHYSICALSECURITY"].ToString();
        //                        newItem["MobileSecurity"] = drEmployees["MOBILESECURITY"].ToString();
        //                        newItem["PasswordProtection"] = drEmployees["PASSWORDPROTECTION"].ToString();
        //                        newItem["IncidentReporting"] = drEmployees["INCIDENTREPORTING"].ToString();
        //                        newItem["MyDesktopTools"] = drEmployees["MYDESKTOPTOOLS"].ToString();
        //                        newItem["ISMS"] = drEmployees["ISMS"].ToString();
        //                        newItem["NoOfAttempts"] = drEmployees["NOOFATTEMPTS"].ToString();
        //                        newItem["DisplayName"] = drEmployees["DISPLAYNAME"].ToString();
        //                        newItem["MemberOfGroups"] = GetUserGroups(newItem["CompanyNumber"].ToString());

        //                        if (drEmployees["EXCLUDED"].ToString() == "Yes")
        //                        {
        //                            newItem["Excluded"] = 1;
        //                            newItem["DescriptionForExclusion"] = drEmployees["EXCLUDED_REMARKS"].ToString();
        //                        }
        //                        else
        //                            newItem["Excluded"] = 0;

        //                        if (drEmployees["EXPIRYDATE"].ToString() != "")
        //                            newItem["ExpiryDate"] = DateTime.Parse(drEmployees["EXPIRYDATE"].ToString());

        //                        try
        //                        {
        //                            //string displayName = GetADUserDisplayName(drEmployees["EMPLOYEENAME"].ToString());
        //                            // objSPUserEmployee = objSPWeb.EnsureUser(displayName);
        //                            //objSPUserEmployee = objSPWeb.EnsureUser(drEmployees["EMPLOYEENAME"].ToString());
        //                            //if (objSPUserEmployee != null)
        //                            //{
        //                            //    newItem["EmployeeName"] = objSPUserEmployee;
        //                            //}
        //                            directorate = GetUserDirectorate(newItem["MemberOfGroups"] != null ? newItem["MemberOfGroups"].ToString() : "Others", objSPListDirectorates);
        //                            newItem["Directorate"] = directorate;
        //                            newItem.Update();

        //                        }
        //                        catch (Exception ex)
        //                        {
        //                            Console.WriteLine(ex.Message);
        //                            //continue;
        //                        }
        //                    }

        //                    objSPWeb.AllowUnsafeUpdates = false;
        //                }
        //            }
        //            Console.ReadKey();
        //        }

        //        public static int GetUserCurrentModule(string userAdId, SPWeb web)
        //        {
        //            SPListItem objSPListItem = null;
        //            int currentModuleId = 0;

        //            objSPListItem = (from SPListItem employee in web.Lists["Employees"].Items
        //                             where employee["MUId"].ToString() == userAdId
        //                             select employee).FirstOrDefault();


        //            if (objSPListItem != null)
        //            {
        //                int.TryParse(objSPListItem["CurrentModuleId"].ToString(), out currentModuleId);
        //            }

        //            return currentModuleId;
        //        }

        //        public static bool IsUserCompletedModuleAssesment(string userId, string moduleName)
        //        {
        //            bool isCompleted = false;
        //            // SPWeb web = SPContext.Current.Web;
        //            SPQuery query = new SPQuery();
        //            using (SPSite oSite = new SPSite("http://mus-ws-373:9000/solutions/LMS"))
        //            {
        //                using (SPWeb web = oSite.AllWebs["ISAT"])
        //                {
        //                    query.Query = @"
        //                               <Where>
        //                                  <And>
        //                                     <Eq>
        //                                        <FieldRef Name='Title' />
        //                                        <Value Type='Text'>" + userId + @"</Value>
        //                                     </Eq>
        //                                     <And>
        //                                        <Eq>
        //                                           <FieldRef Name='IsActive' />
        //                                           <Value Type='Boolean'>1</Value>
        //                                        </Eq>
        //                                        <Eq>
        //                                           <FieldRef Name='" + moduleName + @"' />
        //                                           <Value Type='Text'>C</Value>
        //                                        </Eq>
        //                                     </And>
        //                                  </And>
        //                               </Where>
        //                            ";
        //                    query.ViewFields = @"<FieldRef Name='CompanyNumber' />";
        //                    query.ViewFieldsOnly = true;
        //                    string listUrl = web.ServerRelativeUrl + "/Lists/Employees";
        //                    SPList list = web.GetList(listUrl);
        //                    SPListItemCollection objSPListItemCollection = list.GetItems(query);
        //                    if (objSPListItemCollection != null && objSPListItemCollection.Count > 0)
        //                    {
        //                        isCompleted = true;
        //                    }
        //                }
        //            }

        //            return isCompleted;
        //        }

        //        public static DataTable ReadExcelData(string FilePath, string Extension, string isHDR)
        //        {
        //            string conStr = "";

        //            switch (Extension)
        //            {
        //                case ".xls": //Excel 97-03
        //                    conStr = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source={0};Extended Properties='Excel 8.0;HDR={1}'";
        //                    break;

        //                case ".xlsx": //Excel 07
        //                    conStr = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source={0};Extended Properties='Excel 8.0;HDR={1}'";
        //                    break;
        //            }

        //            conStr = String.Format(conStr, FilePath, isHDR);
        //            OleDbConnection connExcel = new OleDbConnection(conStr);
        //            OleDbCommand cmdExcel = new OleDbCommand();
        //            OleDbDataAdapter oda = new OleDbDataAdapter();
        //            DataTable dtGetCMFData = new DataTable();
        //            cmdExcel.Connection = connExcel;
        //            //Get the name of First Sheet
        //            connExcel.Open();

        //            DataTable dtExcelSchema;
        //            dtExcelSchema = connExcel.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
        //            string SheetName = dtExcelSchema.Rows[0]["TABLE_NAME"].ToString();
        //            connExcel.Close();
        //            //Read Data from First Sheet            
        //            connExcel.Open();
        //            cmdExcel.CommandText = "SELECT * From [" + SheetName + "]";
        //            oda.SelectCommand = cmdExcel;
        //            oda.Fill(dtGetCMFData);
        //            connExcel.Close();
        //            //Bind Data to GridView
        //            return dtGetCMFData;

        //        }

        //        public static String GetUserGroups(string sUserName)
        //        {
        //            StringBuilder sbGroups = new StringBuilder("");

        //            try
        //            {
        //                List<String> groups = new List<string>();

        //                UserPrincipal oUserPrincipal = GetUser(sUserName);
        //                PrincipalSearchResult<Principal> oPrincipalSearchResult = oUserPrincipal.GetGroups();
        //                groups = oPrincipalSearchResult.AsEnumerable()
        //                    .Where(principal => principal.Name.EndsWith("-Members-GS"))
        //                    .Select(principal => principal.Name).ToList<string>();

        //                foreach (var group in groups)
        //                {
        //                    sbGroups.Append(group + " ");
        //                }
        //            }
        //            catch (Exception ex)
        //            {

        //            }

        //            return sbGroups.ToString();
        //        }

        //        public static UserPrincipal GetUser(string sUserName)
        //        {
        //            PrincipalContext oPrincipalContext = GetPrincipalContext();
        //            UserPrincipal oUserPrincipal = UserPrincipal.FindByIdentity(oPrincipalContext, sUserName);
        //            return oUserPrincipal;
        //        }

        //        public static PrincipalContext GetPrincipalContext()
        //        {
        //            PrincipalContext oPrincipalContext = new PrincipalContext(ContextType.Domain, "CORP");
        //            // PrincipalContext oPrincipalContext = new PrincipalContext(ContextType.Machine);
        //            return oPrincipalContext;
        //        }

    }
}
