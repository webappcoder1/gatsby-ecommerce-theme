﻿using System;
using System.Security.Permissions;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using Microsoft.SharePoint.Workflow;
using PDO.Solutions.LMS.Utilities;

namespace PDO.Solutions.LMS.SlidesEventReceiver
{
    /// <summary>
    /// List Item Events
    /// </summary>
    public class SlidesEventReceiver : SPItemEventReceiver
    {
       /// <summary>
       /// Slide item updated event handler to check the workflow status and change the moderation status of the item to approved
       /// if workflow status is approved.
       /// </summary>
       /// <param name="properties">Object containing details of the list item event.</param>
        public override void ItemUpdated(SPItemEventProperties properties)
        {
            try
            {
                if(properties !=null)
                {
                    this.EventFiringEnabled = false;
                    if (properties.List.Title == "Slides")
                    {
                        SPSecurity.RunWithElevatedPrivileges(delegate()
                        {
                            using (SPSite objSPSite = new SPSite(properties.Site.Url))
                            {
                                using (SPWeb objSPWeb = objSPSite.AllWebs["ISAT"])
                                {
                                    SPList objSPList = objSPWeb.Lists["Slides"];
                                    SPListItem listItem = objSPList.GetItemById(properties.ListItem.ID);

                                    if (listItem["WFStatus"].ToString() == "APP")
                                    {
                                        if (listItem.ModerationInformation != null)
                                        {
                                            if (listItem.ModerationInformation.Status != SPModerationStatusType.Approved)
                                            {
                                                listItem.ModerationInformation.Status = SPModerationStatusType.Approved;
                                                listItem.SystemUpdate();
                                            }
                                        }
                                    }
                                }
                            }
                        });
                    }
                }                
            }
            catch (Exception objException)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryRecievers, objException.Message);
            }
            finally
            {
                this.EventFiringEnabled = true;
            }
        }
    }
}