﻿using System;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using PDO.Solutions.LMS.BL;
using Microsoft.SharePoint;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Web;
using System.Net;
using PDO.Solutions.LMS.Utilities;
using System.Collections.Specialized;
using Microsoft.SharePoint.Utilities;


namespace PDO.Solutions.LMS.StartModule
{
    /// <summary>
    /// User control class for Start Module
    /// </summary>
    public partial class StartModuleUserControl : UserControl
    {
        LearningModuleBL objLearningModuleBL = new LearningModuleBL();
        protected void Page_Load(object sender, EventArgs e)
        {
            System.Web.HttpContext.Current.Response.AddHeader("Cache-Control", "no-cache");
            System.Web.HttpContext.Current.Response.Expires = 0;
            System.Web.HttpContext.Current.Response.Cache.SetNoStore();
            System.Web.HttpContext.Current.Response.AddHeader("Pragma", "no-cache");

            if (!IsPostBack)
            {
                if (!string.IsNullOrEmpty(Request.QueryString["Language"]))
                    ViewState["Language"] = Request.QueryString["Language"].ToString();
                else
                    ViewState["Language"] = "EN";                
                BindModuleNavigation();
                SetContentForSelectedLanguage();
                BindUserDetails();
            }            
        }

        /// <summary>
        /// Method to hide the page controls.
        /// </summary>
        private void HidePageControls()
        {
            dvAcknowledgement.Visible = dvSorry.Visible = dvCompletion.Visible = dvResults.Visible = dvAssessment.Visible = dvResults.Visible = imgbtnNext.Visible = imgbtnPrevious.Visible = imgbtnFirst.Visible
                   = imgbtnNextAr.Visible = imgbtnPreviousAr.Visible = imgbtnFirstAr.Visible = dvCompletionContainer.Visible = dvResultsContainer.Visible= false;
        }

        /// <summary>
        /// Method to bind the User details.
        /// </summary>
        private void BindUserDetails()
        {
            try
            {
                SPListItem objUserDetails = objLearningModuleBL.GetUserDetailsByUserId(GetUserId());
                btnDownload.Visible = false;

                if (objUserDetails != null)
                {
                    lblCompletedOn.Text = lblExpiryDate.Text = "--Not Available--";

                    if (objUserDetails["CompletionDate"] != null)
                        lblCompletedOn.Text = DateTime.Parse(objUserDetails["CompletionDate"].ToString()).ToString("dd-MMM-yyyy");

                    switch (objUserDetails["Status"].ToString())
                    {
                        case "P":
                            lblStatus.Text = "Pending";
                            break;

                        case "C":
                            lblStatus.Text = "Completed";
                            lblExpiryDate.Text = DateTime.Parse(objUserDetails["ExpiryDate"].ToString()).ToString("dd-MMM-yyyy");
                            btnDownload.Visible = true;
                            if (DateTime.Now >= DateTime.Parse(objUserDetails["ExpiryDate"].ToString()).AddDays(-33))
                            {
                                StartCertificateRenewal();
                            }
                            break;

                        default:
                            lblStatus.Text = "Pending";
                            break;
                    }
                }
            }
            catch (Exception objException)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryWebParts, objException.Message);
            }
        }

        /// <summary>
        /// Bind the server controls based on the language selection.
        /// </summary>
        private void SetContentForSelectedLanguage()
        {
            var serverRelativeUrl = SPContext.Current.Site.AllWebs["ISAT"].ServerRelativeUrl;

            if (ViewState["Language"].ToString() == "EN")
            {
                imgbtnNextQuestion.ImageUrl = serverRelativeUrl+"/PublishingImages/ISATImages/next_nav.gif";
                imgbtnSubmit.ImageUrl = serverRelativeUrl + "/PublishingImages/ISATImages/submit.jpg";
                imgbtnNextModule.ImageUrl = serverRelativeUrl + "/PublishingImages/ISATImages/nextmodule_nav.gif";
                imgbtnPrevious.ImageUrl = serverRelativeUrl + "/PublishingImages/ISATImages/back_nav.gif";
                imgbtnNext.ImageUrl = serverRelativeUrl + "/PublishingImages/ISATImages/next_nav.gif";
                imgbtnFirst.ImageUrl = serverRelativeUrl + "/PublishingImages/ISATImages/first_nav.gif";
                imgbtnNextModuleEn.ImageUrl = serverRelativeUrl + "/PublishingImages/ISATImages/nextmodule_nav.gif";
                dvSorryImage.Style.Add("background-image", "url('" + serverRelativeUrl + "/PublishingImages/ISATImages/module_fail.jpg')");
                dvSorryImage.Style.Add("min-height", "450px");
                imgbtnSorryBacktoModule.ImageUrl = serverRelativeUrl + "/PublishingImages/ISATImages/backtomodule.JPG";
                imgbtnDownloadCertificate.ImageUrl = serverRelativeUrl + "/PublishingImages/ISATImages/downloadcertificate.JPG";
                imgbtnAcknowledgement.ImageUrl = serverRelativeUrl + "/PublishingImages/ISATImages/acknowledgement.JPG";
                dvThankYou.Style.Add("background-image", "url('" + serverRelativeUrl + "/PublishingImages/ISATImages/ar_module_pass.jpg')");
                dvThankYou.Style.Add("background-image", "url('" + serverRelativeUrl + "/PublishingImages/ISATImages/en_thankyou.png')");                
                dvSlide.Style.Add("margin", "5px");
            }
            else
            {
                moduleTitle.Style.Add("float", "right");
                imgbtnNextQuestion.ImageUrl = serverRelativeUrl + "/PublishingImages/ISATImages/ar_next_nav.gif";
                imgbtnSubmit.ImageUrl = serverRelativeUrl + "/PublishingImages/ISATImages/ar_submit.jpg";
                imgbtnNextModule.ImageUrl = serverRelativeUrl + "/PublishingImages/ISATImages/ar_nextmodule_nav.gif";
                imgbtnPreviousAr.ImageUrl = serverRelativeUrl + "/PublishingImages/ISATImages/ar_back_nav.gif";
                imgbtnNextAr.ImageUrl = serverRelativeUrl + "/PublishingImages/ISATImages/ar_next_nav.gif";
                imgbtnFirstAr.ImageUrl = serverRelativeUrl + "/PublishingImages/ISATImages/ar_first_nav.gif";
                imgbtnNextModuleAr.ImageUrl = serverRelativeUrl + "/PublishingImages/ISATImages/ar_nextmodule_nav.gif";
                dvSorryImage.Style.Add("background-image", "url('" + serverRelativeUrl + "/PublishingImages/ISATImages/ar_module_fail.jpg')");
                dvSorryImage.Style.Add("min-height", "450px");
                imgbtnSorryBacktoModule.ImageUrl = serverRelativeUrl + "/PublishingImages/ISATImages/ar_backtomodule.JPG";
                imgbtnDownloadCertificate.ImageUrl = serverRelativeUrl + "/PublishingImages/ISATImages/ar_downloadcertificate.JPG";
                imgbtnAcknowledgement.ImageUrl = serverRelativeUrl + "/PublishingImages/ISATImages/ar_acknowledgement.JPG";
                dvCompletionContainer.Style.Add("background-image", "url('" + serverRelativeUrl + "/PublishingImages/ISATImages/ar_congrats_msg.png')");
                dvResultsContainer.Style.Add("background-image", "url('"+ serverRelativeUrl +"/PublishingImages/ISATImages/ar_module_pass.jpg')");
                dvThankYou.Style.Add("background-image", "url('" + serverRelativeUrl + "/PublishingImages/ISATImages/ar_thankyou.png')");
                dvSlide.Style.Add("direction", "rtl");
                dvSlide.Style.Add("margin", "5px");
                dvSlide.Style.Add("float", "right");
            }
        }

        /// <summary>
        /// Method to bind the User Module
        /// </summary>
        private void BindUserModule()
        {
            int currentModuleId = 0;
            currentModuleId = objLearningModuleBL.GetUserCurrentModule(GetUserId());
            ViewState["CurrentModuelId"] = currentModuleId;
            bool isAssesmentCompleted = objLearningModuleBL.IsUserCompletedAssesment(GetUserId());

            if (int.Parse(ViewState["CurrentModuelId"].ToString()) == 0)
            {
                ManageModuleMenu(0);
            }
            else
            {
                ManageModuleMenu(int.Parse(ViewState["CurrentModuelId"].ToString()));
            }

            if (isAssesmentCompleted)
            {
                ViewState["CurrentModuelId"] = menuModuleNavigation.Items[0].Value;
            }

            BindModuleSlides(int.Parse(ViewState["CurrentModuelId"].ToString()));
        }

        /// <summary>
        /// Method to bind the Module Slides by Module Id.
        /// </summary>
        /// <param name="moduleId">Module Id</param>
        private void BindModuleSlides(int moduleId)
        {
            DataTable dtAllSlides = null;

            try
            {
                imgModuleQuestionBanner.ImageUrl = imgModuleBanner.ImageUrl = objLearningModuleBL.GetModuleBannerImageUrlById(moduleId, ViewState["Language"].ToString());
                dvEndOfModule.Visible = dvResults.Visible = dvAssessment.Visible = dvThankYou.Visible= false;
                dvSlideContent.Visible = true;
                using (dtAllSlides = new DataTable())
                {
                    dtAllSlides = objLearningModuleBL.GetAllSlidesByModuelId(moduleId, ViewState["Language"].ToString());                    
                    SPListItem objSPListItem = objLearningModuleBL.GetModuleDetailsByModuleId(moduleId);

                    if (objSPListItem != null)
                    {
                        ViewState["CurrentModuelName"] = objSPListItem["RelModuleColumn"].ToString();
                    }

                    ViewState["AllSlides"] = dtAllSlides;
                    if (dtAllSlides != null && dtAllSlides.Rows.Count > 0)
                    {
                        ViewState["CurrentModuelId"] = moduleId;
                        ViewState["CurrentSlideId"] = 1;
                        BindModuleSlide(int.Parse(ViewState["CurrentSlideId"].ToString()));
                    }
                    BindModuleSelection();
                }
            }
            catch (Exception objException)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryWebParts, objException.Message);
            }

        }

        /// <summary>
        /// Method to bind the module selection.
        /// </summary>
        private void BindModuleSelection()
        {
            for (int moduleCounter = 0; moduleCounter < menuModuleNavigation.Items.Count; moduleCounter++)
            {
                if (menuModuleNavigation.Items[moduleCounter].Value == ViewState["CurrentModuelId"].ToString())
                {
                    menuModuleNavigation.Items[moduleCounter].Selected = true;
                }
            }
        }

        /// <summary>
        /// Method to manage the Module Menu by Module Id.
        /// </summary>
        /// <param name="moduleId">Module Id.</param>
        private void ManageModuleMenu(int moduleId)
        {
            bool enableModuleNavigation = true;
            bool isAssesmentCompleted = false;
            var serverRelativeUrl = SPContext.Current.Site.AllWebs["ISAT"].ServerRelativeUrl;

            try
            {
                if (moduleId == 0)
                {
                    ViewState["CurrentModuelId"] = menuModuleNavigation.Items[0].Value;
                    ManageModuleMenu(int.Parse(ViewState["CurrentModuelId"].ToString()));
                }
                else
                {
                    isAssesmentCompleted = objLearningModuleBL.IsUserCompletedAssesment(GetUserId());

                    for (int moduleCounter = 0; moduleCounter < menuModuleNavigation.Items.Count; moduleCounter++)
                    {
                        if (isAssesmentCompleted)
                        {   
                            menuModuleNavigation.Items[moduleCounter].ImageUrl = serverRelativeUrl+"/PublishingImages/ISATImages/ModuleCompleted.png";
                        }
                        else
                        {
                            menuModuleNavigation.Items[moduleCounter].ImageUrl = serverRelativeUrl+"/PublishingImages/ISATImages/ModuleInProgress.png";
                        }

                        if (menuModuleNavigation.Items[moduleCounter].Value == moduleId.ToString() && moduleCounter < menuModuleNavigation.Items.Count)
                        {
                            menuModuleNavigation.Items[moduleCounter].Enabled = true;
                            enableModuleNavigation = false;
                        }
                        else
                        {
                            if (enableModuleNavigation == false)
                            {
                                if (isAssesmentCompleted)
                                {
                                    menuModuleNavigation.Items[moduleCounter].ImageUrl = serverRelativeUrl + "/PublishingImages/ISATImages/ModuleCompleted.png";
                                    menuModuleNavigation.Items[moduleCounter].Enabled = true;
                                }
                                else
                                {
                                    menuModuleNavigation.Items[moduleCounter].ImageUrl = serverRelativeUrl + "/PublishingImages/ISATImages/ModulePending.png";
                                    menuModuleNavigation.Items[moduleCounter].Enabled = false;
                                }
                            }
                            else
                            {
                                menuModuleNavigation.Items[moduleCounter].ImageUrl = serverRelativeUrl + "/PublishingImages/ISATImages/ModuleCompleted.png";
                                menuModuleNavigation.Items[moduleCounter].Enabled = true;
                            }
                        }
                    }
                }
            }
            catch (Exception objException)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryWebParts, objException.Message);
            }
        }

        /// <summary>
        /// Method to bind the module navigation.
        /// </summary>
        private void BindModuleNavigation()
        {
            DataTable dtAllModules = null;

            try
            {
                HidePageControls();
                using (dtAllModules = new DataTable())
                {
                    dtAllModules = objLearningModuleBL.GetAllModules(ViewState["Language"].ToString());
                    ViewState["AllModules"] = dtAllModules;
                    if (dtAllModules.Rows.Count > 0)
                    {
                        foreach (DataRow objDataRow in dtAllModules.Rows)
                        {
                            MenuItem menuItem = new MenuItem
                            {
                                Value = objDataRow["ID"].ToString(),
                                Text = objDataRow["Title"].ToString()
                            };
                            menuModuleNavigation.Items.Add(menuItem);
                        }

                        BindUserModule();
                    }
                    if (ViewState["Language"].ToString() == "AR")
                        menuModuleNavigation.CssClass = "menuar";
                }
            }
            catch (Exception objException)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryWebParts, objException.Message);
            }

        }

        /// <summary>
        /// Method to bind the module slides
        /// </summary>
        /// <param name="slideId">Slide Id</param>
        private void BindModuleSlide(int slideId)
        {
            ViewState["CurrentSlideId"] = slideId;
            DataTable dtAllSlides = (DataTable)ViewState["AllSlides"];
            if (dtAllSlides != null && dtAllSlides.Rows.Count >= slideId)
            {
                lblModuleTitle.Text = ((DataTable)ViewState["AllSlides"]).Rows[slideId - 1]["Title"].ToString();
                ltModuleSlides.Text = ((DataTable)ViewState["AllSlides"]).Rows[slideId - 1]["Content"].ToString();
                ManageNavigationAction();
            }
        }

        /// <summary>
        /// Method to manage navigation action.
        /// </summary>
        private void ManageNavigationAction()
        {
            var serverRelativeUrl = SPContext.Current.Site.AllWebs["ISAT"].ServerRelativeUrl;

            dvActionBarEnglish.Visible = dvActionBarArabic.Visible = false;
            imgbtnNextModuleEn.Visible = imgbtnNextModuleAr.Visible = imgbtnNextAr.Visible = imgbtnPreviousAr.Visible =
                imgbtnNext.Visible = imgbtnPrevious.Visible = imgbtnFirstAr.Visible = imgbtnFirst.Visible = false;

            if (ViewState["Language"].ToString() == "EN")
                dvActionBarEnglish.Visible = true;
            else
                dvActionBarArabic.Visible = true;

            int totalSlides = ((DataTable)ViewState["AllSlides"]).Rows.Count;

            if (int.Parse(ViewState["CurrentSlideId"].ToString()) <= totalSlides)
                imgbtnNextAr.Visible = imgbtnNext.Visible = true;

            if (int.Parse(ViewState["CurrentSlideId"].ToString()) > 1)
                imgbtnPreviousAr.Visible = imgbtnPrevious.Visible = true;

            if (int.Parse(ViewState["CurrentSlideId"].ToString()) == totalSlides)
            {
                imgbtnNextModuleAr.Visible = imgbtnNextModuleEn.Visible = imgbtnFirstAr.Visible = imgbtnFirst.Visible = true;
                bool isCompleted = objLearningModuleBL.IsUserCompletedModuleAssesment(GetUserId(), ViewState["CurrentModuelName"].ToString());

                if (isCompleted)
                {
                    imgbtnNextModuleEn.Visible = imgbtnNextModuleAr.Visible = true;
                    imgbtnNext.Visible = imgbtnNextAr.Visible = false;
                }
                else
                {
                    imgbtnNextModuleEn.Visible = imgbtnNextModuleAr.Visible = false;
                    imgbtnNext.Visible = imgbtnNextAr.Visible = true;
                }
            }

            int completedModuleId = int.Parse(ViewState["CurrentModuelId"].ToString());

            int nextModuleId = objLearningModuleBL.GetNextLearningModule(completedModuleId);

            if (nextModuleId == 0)
            {
                imgbtnNextModuleEn.ImageUrl = serverRelativeUrl + "/PublishingImages/ISATImages/next_nav.gif";
            }
            else
            {
                imgbtnNextModuleEn.ImageUrl = serverRelativeUrl + "/PublishingImages/ISATImages/nextmodule_nav.gif";
            }

            lblDisplayPagerStatus.Text = "Slide " + ViewState["CurrentSlideId"].ToString() + " of " + totalSlides.ToString();
            lblDisplayPagerStatusAr.Text = ViewState["CurrentSlideId"].ToString() + "/" + totalSlides.ToString() + "<<الشرائح";
            imgbtnTakeAssesment.Visible = true;
        }

        /// <summary>
        /// Method to populate the menu items.
        /// </summary>
        /// <param name="dtAllModules">DataTable containing all the modules.</param>
        private void PopulateMenu(DataTable dtAllModules)
        {
            foreach (DataRow objDataRow in dtAllModules.Rows)
            {
                MenuItem menuItem = new MenuItem
                {
                    Value = objDataRow["MenuId"].ToString(),
                    Text = objDataRow["Title"].ToString(),
                };
                menuModuleNavigation.Items.Add(menuItem);
            }
        }

        /// <summary>
        /// Menu item click event handler to bind the module slides.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event Args.</param>
        protected void menuModuleNavigation_MenuItemClick(object sender, MenuEventArgs e)
        {
            BindModuleSlides(int.Parse(menuModuleNavigation.SelectedValue));
            dvAcknowledgement.Visible = dvSorry.Visible = dvCompletion.Visible = false;
            
        }

        /// <summary>
        /// Take Assesment button click event handler. 
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event Args</param>
        protected void imgbtnTakeAssesment_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                dvEndOfModule.Visible = dvAssessmentAction.Visible = dvSlideContent.Visible = false;
                dvAssessment.Visible = true;
                SPListItem objSPListItem = objLearningModuleBL.GetModuleDetailsByModuleId(int.Parse(ViewState["CurrentModuelId"].ToString()));
                UpdateAssessmentDetails();
                if (objSPListItem != null)
                {
                    ViewState["NoOfQuestions"] = objSPListItem["NoOfQuestions"].ToString();
                    ViewState["NoOfQuestionsToPass"] = objSPListItem["NoOfQuestionsToPass"].ToString();
                    ViewState["NoOfIncorrectAnswers"] = 0;
                    ViewState["NoOfCorrectAnswers"] = 0;
                    ViewState["NoOfQuestionsAttempted"] = 1;
                    ViewState["QuestionIds"] = "";
                    ViewState["AllowedIncorrects"] = int.Parse(objSPListItem["NoOfQuestions"].ToString()) - int.Parse(objSPListItem["NoOfQuestionsToPass"].ToString());
                    ResetControls();
                    BindModuleQuestion();
                }
            }
            catch (Exception objException)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryWebParts, objException.Message);
            }
        }

        /// <summary>
        /// Method to call the UpdateUserAttempts of BL to update the number of attempts.
        /// </summary>
        private void UpdateAssessmentDetails()
        {
            objLearningModuleBL.UpdateUserAttempts(GetUserId());
        }

        /// <summary>
        /// Method to bind the Module Questions.
        /// </summary>
        private void BindModuleQuestion()
        {
            DataSet dsQuestionDetails = new DataSet();

            try
            {
                rdobtnlstAnswers.Visible = chkbxlstAnswers.Visible = false;
                dsQuestionDetails = objLearningModuleBL.GetQuestionDetailsByModuleId(int.Parse(ViewState["CurrentModuelId"].ToString()), ViewState["QuestionIds"].ToString(), ViewState["Language"].ToString());
                ViewState["DSCurrentQuestionDetails"] = dsQuestionDetails;

                if (dsQuestionDetails.Tables.Count == 2)
                {
                    ViewState["QuestionIds"] = dsQuestionDetails.Tables[0].Rows[0]["ID"].ToString() + ";" + ViewState["QuestionIds"].ToString();

                    ltQuestion.Text = dsQuestionDetails.Tables[0].Rows[0]["QuestionTitle"].ToString();
                    int correctAnswerCount = (from DataRow drAnswers in dsQuestionDetails.Tables[1].Rows
                                              where drAnswers["IsCorrect"].ToString() == "1"
                                              select drAnswers).Count();

                    if (ViewState["Language"].ToString() == "AR")
                    {
                        dvContentDirection.Style.Add("float", "right");
                        dvContentDirection.Style.Add("text-align", "right");
                        dvCorrectAnswer.Style.Add("float", "right");
                        dvCorrectAnswer.Style.Add("text-align", "right");
                        dvCorrectAnswer.Style.Add("float", "right");
                        dvCorrectAnswer.Style.Add("text-align", "right");
                        rdobtnlstAnswers.Style.Add("float", "right");
                        rdobtnlstAnswers.Style.Add("text-align", "right");
                        chkbxlstAnswers.Style.Add("float", "right");
                        chkbxlstAnswers.Style.Add("text-align", "right");
                        rdobtnlstAnswers.TextAlign = TextAlign.Left;
                        chkbxlstAnswers.TextAlign = TextAlign.Left;
                        dvContentDirection.Attributes.Add("class", "ardvContentDirection");
                        dvCorrectAnswer.Attributes.Add("class", "ardvCorrectAnswer");
                        rdobtnlstAnswers.Attributes.Add("class", "arrdobtnlstAnswers");
                        chkbxlstAnswers.Attributes.Add("class", "archkbxlstAnswers");
                        lblModuleTitle.Attributes.Add("class", "arlblModuleTitle");
                    }

                    if (correctAnswerCount == 1)
                    {
                        rdobtnlstAnswers.Visible = true;                        
                        rdobtnlstAnswers.DataSource = dsQuestionDetails.Tables[1];
                        rdobtnlstAnswers.DataTextField = "Title";
                        rdobtnlstAnswers.DataValueField = "ID";
                        rdobtnlstAnswers.DataBind();
                    }

                    if (correctAnswerCount > 1)
                    {
                        chkbxlstAnswers.Visible = true;                        
                        chkbxlstAnswers.DataSource = dsQuestionDetails.Tables[1];
                        chkbxlstAnswers.DataTextField = "Title";
                        chkbxlstAnswers.DataValueField = "ID";
                        chkbxlstAnswers.DataBind();
                    }
                    if(rdobtnlstAnswers.Visible ==false && chkbxlstAnswers.Visible==false)
                    {
                        rdobtnlstAnswers.Visible = true;
                    }
                }
            }
            catch (Exception objException)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryWebParts, objException.Message);
            }
        }

        /// <summary>
        /// Next Question button click event handler.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">EventArgs</param>
        protected void imgbtnNextQuestion_Click(object sender, ImageClickEventArgs e)
        {
            int noOfQuestionsAttempted = 0;
            var serverRelativeUrl = SPContext.Current.Site.AllWebs["ISAT"].ServerRelativeUrl;

            try
            {
                noOfQuestionsAttempted = int.Parse(ViewState["NoOfQuestionsAttempted"].ToString()) + 1;
                ViewState["NoOfQuestionsAttempted"] = noOfQuestionsAttempted;
                if (int.Parse(ViewState["NoOfIncorrectAnswers"].ToString()) > int.Parse(ViewState["AllowedIncorrects"].ToString()))
                {
                    dvSorry.Visible = true;
                    dvAssessment.Visible = false;
                    dvResultsContainer.Visible = dvResults.Visible = false;
                }
                else
                {
                    if (noOfQuestionsAttempted <= int.Parse(ViewState["NoOfQuestions"].ToString()))
                    {
                        BindModuleQuestion();
                    }
                    else
                    {
                        objLearningModuleBL.UpdateUserModuleAssesment(GetUserId(), ViewState["CurrentModuelName"].ToString(), ViewState["Language"].ToString());
                        dvAssessment.Visible = false;
                        dvResultsContainer.Visible= dvResults.Visible = true;

                        int completedModuleId = int.Parse(ViewState["CurrentModuelId"].ToString());
                        int nextModuleId = objLearningModuleBL.GetNextLearningModule(completedModuleId);

                        if (nextModuleId == 0)
                        {
                            imgbtnNextModule.ImageUrl = serverRelativeUrl + "/PublishingImages/ISATImages/userundertaking.gif";
                        }
                        else
                        {
                            SetUsersCurrentModule(nextModuleId);
                        }
                    }
                }

                ResetControls();
            }
            catch (Exception objException)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryWebParts, objException.Message);
            }
        }

        /// <summary>
        /// Method to reset the page controls.
        /// </summary>
        private void ResetControls()
        {
            ltCorrectAnswer.Text = "";
            dvAssessmentAction.Visible = false;
            dvAssessmentSubmission.Visible = true;
            dvCorrectAnswer.Visible = false;
        }

        /// <summary>
        /// Method to validate the answer.
        /// </summary>
        private void ValidateAnswer()
        {
            var serverRelativeUrl = SPContext.Current.Site.AllWebs["ISAT"].ServerRelativeUrl;

            try
            {
                DataSet dsCurrentQuestionDetails = (DataSet)ViewState["DSCurrentQuestionDetails"];
                var answers = (from DataRow drAnswers in dsCurrentQuestionDetails.Tables[1].Rows
                               where drAnswers["IsCorrect"].ToString() == "1"
                               select drAnswers).ToList();
                bool isCorrect = true;

                if (answers.Count() == 1)
                {
                    int selectedAnswerId = int.Parse(rdobtnlstAnswers.SelectedValue);
                    for (int answerCounter = 0; answerCounter < rdobtnlstAnswers.Items.Count; answerCounter++)
                    {
                        DataRow drAnswer = (from DataRow drResult in dsCurrentQuestionDetails.Tables[1].Rows
                                            where drResult["ID"].ToString() == rdobtnlstAnswers.Items[answerCounter].Value.ToString()
                                            select drResult).FirstOrDefault();

                        if (drAnswer["IsCorrect"].ToString() == "1")
                        {
                            rdobtnlstAnswers.Items[answerCounter].Text = rdobtnlstAnswers.Items[answerCounter].Text +
                                "<img height='18px' width='18px' src='"+serverRelativeUrl+"/PublishingImages/ISATImages/CorrectAns.png'/>";
                        }
                        else
                        {
                            if (rdobtnlstAnswers.Items[answerCounter].Value == drAnswer["ID"].ToString() && rdobtnlstAnswers.Items[answerCounter].Selected == true)
                                isCorrect = false;
                            rdobtnlstAnswers.Items[answerCounter].Text = rdobtnlstAnswers.Items[answerCounter].Text +
                                "<img height='18px' width='18px' src='"+serverRelativeUrl+"/PublishingImages/ISATImages/InCorrectAns.png'/>";
                        }

                        if (drAnswer["Description"].ToString().Trim() != "")
                        {
                            ltCorrectAnswer.Text = ltCorrectAnswer.Text + drAnswer["Description"].ToString().Trim();
                        }
                    }
                }

                if (answers.Count() > 1)
                {
                    for (int answerCounter = 0; answerCounter < chkbxlstAnswers.Items.Count; answerCounter++)
                    {
                        DataRow drAnswer = (from DataRow drResult in dsCurrentQuestionDetails.Tables[1].Rows
                                            where drResult["ID"].ToString() == chkbxlstAnswers.Items[answerCounter].Value.ToString()
                                            select drResult).FirstOrDefault();

                        if (drAnswer["IsCorrect"].ToString() == "1")
                        {
                            if (chkbxlstAnswers.Items[answerCounter].Selected == false)
                                isCorrect = false;
                            chkbxlstAnswers.Items[answerCounter].Text = chkbxlstAnswers.Items[answerCounter].Text +
                                "<img height='18px' width='18px' src='" + serverRelativeUrl + "/PublishingImages/ISATImages/CorrectAns.png'/>";
                        }
                        else
                        {
                            if (chkbxlstAnswers.Items[answerCounter].Selected == true)
                                isCorrect = false;
                            chkbxlstAnswers.Items[answerCounter].Text = chkbxlstAnswers.Items[answerCounter].Text +
                                "<img height='18px' width='18px' src='" + serverRelativeUrl + "/PublishingImages/ISATImages/InCorrectAns.png'/>";
                        }

                        if (drAnswer["Description"].ToString().Trim() != "")
                        {
                            ltCorrectAnswer.Text = ltCorrectAnswer.Text + drAnswer["Description"].ToString();
                        }
                    }
                }

                if (isCorrect == true)
                {
                    ViewState["NoOfCorrectAnswers"] = int.Parse(ViewState["NoOfCorrectAnswers"].ToString()) + 1;

                    if (ViewState["Language"].ToString() == "EN")
                        imgAnswerSource.ImageUrl = serverRelativeUrl+"/PublishingImages/ISATImages/quiz_yes_img.jpg";
                    else
                        imgAnswerSource.ImageUrl = serverRelativeUrl + "/PublishingImages/ISATImages/ar-quiz_yes_img.jpg";
                }
                else
                {
                    ViewState["NoOfIncorrectAnswers"] = int.Parse(ViewState["NoOfIncorrectAnswers"].ToString()) + 1;
                    if (ViewState["Language"].ToString() == "EN")
                        imgAnswerSource.ImageUrl = serverRelativeUrl+"/PublishingImages/ISATImages/quiz_no_img.jpg";
                    else
                        imgAnswerSource.ImageUrl = serverRelativeUrl + "/PublishingImages/ISATImages/ar-quiz_no_img.jpg";
                }
            }
            catch (Exception objException)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryWebParts, objException.Message);
            }
        }

        /// <summary>
        /// Submit button click event handler.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">EventArgs</param>
        protected void imgbtnSubmit_Click(object sender, ImageClickEventArgs e)
        {
            if (ValidateControls())
            {
                ValidateAnswer();
                dvAssessmentAction.Visible = true;
                dvAssessmentSubmission.Visible = false;
                lblErrorMessage.Text = "";
                dvCorrectAnswer.Visible = true;
            }
        }

        /// <summary>
        /// Method to validate the controls for the answer section of the question.
        /// </summary>
        /// <returns>Returns true if the validation is successful else returns false.</returns>
        private bool ValidateControls()
        {
            bool isValid = true;

            try
            {
                DataSet dsCurrentQuestionDetails = (DataSet)ViewState["DSCurrentQuestionDetails"];
                var answers = (from DataRow drAnswers in dsCurrentQuestionDetails.Tables[1].Rows
                               where drAnswers["IsCorrect"].ToString() == "1"
                               select drAnswers).ToList();

                if (answers.Count() == 1)
                {
                    List<ListItem> selectedAnswers = rdobtnlstAnswers.Items.Cast<ListItem>()
                        .Where(li => li.Selected)
                        .ToList();

                    if (selectedAnswers.Count == 0)
                    {
                        lblErrorMessage.Text = "Please select answer";
                        isValid = false;
                    }
                }

                if (answers.Count() > 1)
                {
                    List<ListItem> selectedAnswers = chkbxlstAnswers.Items.Cast<ListItem>()
                        .Where(li => li.Selected)
                        .ToList();

                    if (selectedAnswers.Count == 0)
                    {
                        lblErrorMessage.Text = "Please select answer";
                        isValid = false;
                    }
                }

            }
            catch (Exception objException)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryWebParts, objException.Message);
            }

            return isValid;
        }

        /// <summary>
        /// Next module button click event handler.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">EventArgs</param>
        protected void imgbtnNextModule_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                int completedModuleId = int.Parse(ViewState["CurrentModuelId"].ToString());
                int nextModuleId = objLearningModuleBL.GetNextLearningModule(completedModuleId);
                if (nextModuleId != 0)
                {
                    ViewState["CurrentModuelId"] = nextModuleId;
                    SetUsersCurrentModule(nextModuleId);
                    dvEndOfModule.Visible = false;
                    BindUserModule();
                }
                else
                {
                    dvResults.Visible = dvEndOfModule.Visible = false;
                    bool isAssesmentCompleted = objLearningModuleBL.IsUserCompletedAssesment(GetUserId());
                    if(!isAssesmentCompleted)
                    {
                        BindAcknowledgement();
                        dvAcknowledgement.Visible = true;
                    }
                }
            }
            catch (Exception objException)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryWebParts, objException.Message);
            }
        }

        /// <summary>
        /// This method is used to get the User Id for the current context.
        /// </summary>
        /// <returns></returns>
        private String GetUserId()
        {
            String userName = String.Empty;
            SPUser objSPUser = SPContext.Current.Web.CurrentUser;
            userName = objSPUser.LoginName.ToString().Substring(Request.LogonUserIdentity.Name.LastIndexOf(@"\"));
            return userName.ToUpper();
        }

        /// <summary>
        /// Method to set the user's current module.
        /// </summary>
        /// <param name="moduleId">Module Id.</param>
        private void SetUsersCurrentModule(int moduleId)
        {
            objLearningModuleBL.SetUsersCurrentModule(GetUserId(), moduleId);
        }

        /// <summary>
        /// Previous button click event handler to navigate to the previous slide.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">EventArgs</param>
        protected void imgbtnPrevious_Click(object sender, ImageClickEventArgs e)
        {
            if (int.Parse(ViewState["CurrentSlideId"].ToString()) > 1)
            {
                ViewState["CurrentSlideId"] = int.Parse(ViewState["CurrentSlideId"].ToString()) - 1;
                BindModuleSlide(int.Parse(ViewState["CurrentSlideId"].ToString()));
            }
        }

        /// <summary>
        /// Next button click event handler to navigat to the next existing slide.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">EventArgs</param>
        protected void imgbtnNext_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                if (int.Parse(ViewState["CurrentSlideId"].ToString()) == ((DataTable)ViewState["AllSlides"]).Rows.Count)
                {
                    BindEndOfModuleDetails();
                }
                else
                {
                    if (int.Parse(ViewState["CurrentSlideId"].ToString()) < ((DataTable)ViewState["AllSlides"]).Rows.Count)
                    {
                        ViewState["CurrentSlideId"] = int.Parse(ViewState["CurrentSlideId"].ToString()) + 1;
                        BindModuleSlide(int.Parse(ViewState["CurrentSlideId"].ToString()));
                    }
                }
            }
            catch (Exception objException)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryWebParts, objException.Message);
            }
        }

        /// <summary>
        /// Methos to display the End of Module.
        /// </summary>
        private void BindEndOfModuleDetails()
        {
            String moduleName = String.Empty, messageTemplate = String.Empty;
            var serverRelativeUrl = SPContext.Current.Site.AllWebs["ISAT"].ServerRelativeUrl;

            try
            {
                dvSlideContent.Visible = false;
                dvEndOfModule.Visible = true;
                messageTemplate = objLearningModuleBL.GetMessageTemplateByTitle("EndofModule", ViewState["Language"].ToString());
                SPListItem objSPListItem = objLearningModuleBL.GetModuleDetailsByModuleId(int.Parse(ViewState["CurrentModuelId"].ToString()));
                if (ViewState["Language"].ToString() == "EN")
                {
                    moduleName = objSPListItem["ModuleTitle"].ToString();
                    imgbtnTakeAssesment.ImageUrl = serverRelativeUrl+"/PublishingImages/ISATImages/quiz_yes.JPG";
                    imgbtnBackToModule.ImageUrl = serverRelativeUrl + "/PublishingImages/ISATImages/quiz_no.JPG";
                }
                else
                {
                    moduleName = objSPListItem["ModuleTitle_AR"].ToString();
                    imgbtnTakeAssesment.ImageUrl = serverRelativeUrl + "/PublishingImages/ISATImages/ar_quiz_yes.JPG";
                    imgbtnBackToModule.ImageUrl = serverRelativeUrl + "/PublishingImages/ISATImages/ar_quiz_no.JPG";
                }

                messageTemplate = messageTemplate.Replace("&#123;", "{").Replace("&#125;", "}");
                ltEndOfModule.Text = string.Format(messageTemplate, moduleName);

            }
            catch (Exception objException)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryWebParts, objException.Message);
            }
        }

        /// <summary>
        /// Method to bind the acknowledgement.
        /// </summary>
        private void BindAcknowledgement()
        {
            String moduleName = String.Empty, messageTemplate = String.Empty;

            try
            {               
                messageTemplate = objLearningModuleBL.GetMessageTemplateByTitle("Acknowledgement", ViewState["Language"].ToString());
                SPListItem objSPListItem = objLearningModuleBL.GetModuleDetailsByModuleId(int.Parse(ViewState["CurrentModuelId"].ToString()));
                messageTemplate = messageTemplate.Replace("&#123;", "{").Replace("&#125;", "}");
                ltAcknowledgement.Text = messageTemplate;

            }
            catch (Exception objException)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryWebParts, objException.Message);
            }
        }

        /// <summary>
        /// First button to navigate to the begining of the slide.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">EventArgs</param>
        protected void imgbtnFirst_Click(object sender, ImageClickEventArgs e)
        {
            ViewState["CurrentSlideId"] = 1;
            BindModuleSlide(int.Parse(ViewState["CurrentSlideId"].ToString()));
        }

        /// <summary>
        /// Back button click event handler to go back to the module.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">EventArgs</param>
        protected void imgbtnBackToModule_Click(object sender, ImageClickEventArgs e)
        {
            dvSorry.Visible = dvEndOfModule.Visible = false;
            BindUserModule();
        }

        /// <summary>
        /// Next Module button click event handler to navigate to the next module.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">EventArgs</param>
        protected void imgbtnNextModuleEn_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                int completedModuleId = int.Parse(ViewState["CurrentModuelId"].ToString());
                int nextModuleId = objLearningModuleBL.GetNextLearningModule(completedModuleId);
                if (nextModuleId != 0)
                {
                    ViewState["CurrentModuelId"] = nextModuleId;
                    BindNextModule();
                }
                else
                {
                    bool isAssesmentCompleted = objLearningModuleBL.IsUserCompletedAssesment(GetUserId());
                    dvSlideContent.Visible = false;
                    dvThankYou.Visible=dvResults.Visible = dvEndOfModule.Visible = false;
                    if (!isAssesmentCompleted)
                    {
                        BindAcknowledgement();
                        dvAcknowledgement.Visible = true;
                    }
                    else
                    {
                        dvThankYou.Visible = true;
                    }
                }
            }
            catch (Exception objException)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryWebParts, objException.Message);
            }
        }

        /// <summary>
        /// This method is used to bind the Next available module.
        /// </summary>
        private void BindNextModule()
        {
            if (int.Parse(ViewState["CurrentModuelId"].ToString()) == 0)
            {
                ManageModuleMenu(0);
            }
            else
            {
                ManageModuleMenu(int.Parse(ViewState["CurrentModuelId"].ToString()));
            }

            BindModuleSlides(int.Parse(ViewState["CurrentModuelId"].ToString()));
        }

        /// <summary>
        /// Download button click event handler to download the certificates. 
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">EventArgs</param>
        protected void btnDownload_Click(object sender, EventArgs e)
        {
            string userId = GetUserId();
            string certificateUrl = String.Empty;
            
            if (ViewState["Language"].ToString() == "EN")
            {
                //certificateUrl = SPContext.Current.Web.Url + "/_vti_bin/reportserver?" + SPContext.Current.Web.Url + "/Reports/ISATCertificate.rdl&rs:Format=PDF&rs:Command=Render&rs:ClearSession=true&CompanyNumber=" + userId;
                certificateUrl = "http://mus-ws-131/ReportServer/Pages/ReportViewer.aspx?%2fISAT%2fISATCertificate&rs:Format=PDF&rs:Command=Render&rs:ClearSession=true&CompanyNumber=" + userId;
            }
            else
            {
                //certificateUrl = SPContext.Current.Web.Url + "/_vti_bin/reportserver?" + SPContext.Current.Web.Url + "/Reports/ISATCertificateArabic.rdl&rs:Format=PDF&rs:Command=Render&rs:ClearSession=true&CompanyNumber=" + userId;
                certificateUrl = "http://mus-ws-131/ReportServer/Pages/ReportViewer.aspx?%2fISAT%2fISATCertificateArabic&rs:Format=PDF&rs:Command=Render&rs:ClearSession=true&CompanyNumber=" + userId;
            }

            Response.Redirect(certificateUrl);
        }       

        /// <summary>
        /// This method is used to initiate the certificate renewal process.
        /// </summary>
        private void StartCertificateRenewal()
        {
            objLearningModuleBL.CopyToHistoryList(GetUserId());
            BindUserDetails();
            BindUserModule(); 
        }

        /// <summary>
        /// Acknowledge button click event handler.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">EventArgs</param>
        protected void imgbtnAcknowledgement_Click(object sender, ImageClickEventArgs e)
        {
            objLearningModuleBL.UpdateUserAssesmentCompleted(GetUserId());
            dvAcknowledgement.Visible = false;
            dvCompletion.Visible = dvCompletionContainer.Visible = true;
            ManageModuleMenu(int.Parse(ViewState["CurrentModuelId"].ToString()));
            BindUserDetails();
            SendCompletionMail();
        }

        /// <summary>
        /// Method to send the ISAT completion notification mail.
        /// </summary>
        private void SendCompletionMail()
        {
            string mailBody = string.Empty,
                    mailSubject = string.Empty,
                    mailFrom = string.Empty,
                    siteURL = SPContext.Current.Web.Url;

            StringDictionary headers = new StringDictionary();
            SPUser objCurrentUser = SPContext.Current.Web.CurrentUser;

            if(!String.IsNullOrEmpty(objCurrentUser.Email))
            {
                MailEntity objMailEntity = new MailEntity();
                DataTable dtMailTemplate = Utilities.Utility.GetMailTemplateByTemplateName("ISAT-Completed");

                if(dtMailTemplate !=null && dtMailTemplate.Rows.Count>0)
                {
                    mailBody = dtMailTemplate.Rows[0]["Body"].ToString();
                    mailBody = mailBody.Replace("imgEmailHeader", string.Format("<img src={0} alt=''/>", GetEmailImage(siteURL, true)));
                    mailBody = mailBody.Replace("emailUser", objCurrentUser.Name);
                    mailBody = mailBody.Replace("ISATLinkURL", string.Format("<a href={0}>ISAT</a>", siteURL));
                    mailBody = mailBody.Replace("ISATLinkURL", string.Format("<a href={0}>ISAT</a>", siteURL));
                    mailBody = mailBody.Replace("imgEmailFooter", string.Format("<img src={0} alt=''/>", GetEmailImage(siteURL, false)));
                    mailBody = mailBody.Replace("emailUser", objCurrentUser.Name);

                    mailSubject = dtMailTemplate.Rows[0]["Subject"].ToString();

                    headers.Add("from", "iSecure@pdo.co.om");
                    headers.Add("to", objCurrentUser.Email);
                    headers.Add("subject", mailSubject);
                    headers.Add("content-type", "text/html");

                    SPUtility.SendEmail(SPContext.Current.Web, headers, mailBody);

                }
            }
        }

        private string GetEmailImage(string siteURL, bool flag)
        {
            string imgURL = string.Empty;

            if (flag)
            {
                imgURL = siteURL + "/PublishingImages/EmailHeader.jpg";
            }
            else
            {
                imgURL = siteURL + "/PublishingImages/EmailFooter.jpg";
            }

            return imgURL;
        }

        /// <summary>
        /// Exit link click event handler to navigate back to iSecure Site.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">EventArgs</param>
        protected void lnkbtnExit_Click(object sender, EventArgs e)
        {
            var iSecureUrl=Utility.GetPropertyBagValueByKey("IsecureUrl",SPContext.Current.Site.Url);
            Response.Redirect(iSecureUrl);
        }
    }
}
