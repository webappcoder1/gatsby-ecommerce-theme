using System;
using System.Runtime.InteropServices;
using System.Security.Permissions;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration;

namespace PDO.Solutions.LMS.Jobs.Features.PDO.Solutions.LMS.Jobs
{
    /// <summary>
    /// This class handles events raised during feature activation, deactivation, installation, uninstallation, and upgrade.
    /// </summary>
    /// <remarks>
    /// The GUID attached to this class may be used during packaging and should not be modified.
    /// </remarks>

    [Guid("617cf365-56e6-4dca-85db-bb1f19448384")]
    public class PDOSolutionsLMSEventReceiver : SPFeatureReceiver
    {
        //const string JobName = "PDO.Solutions.LMS.Jobs - ISAT job to send notifications.";
        const string JobName = "PDO.Solutions.LMS.Jobs";
        SPWebApplication objWebApp = null;

        /// <summary>
        /// Feature activated event handler to initialize the persisted properties in the web application and 
        /// delete, recreate the DMS timer job.
        /// </summary>
        /// <param name="properties">Initialized object of the Feature Receiver.</param>
        public override void FeatureActivated(SPFeatureReceiverProperties properties)
        {
            SPWeb objSPWeb = properties.Feature.Parent as SPWeb;
            SPSite objSPSite = objSPWeb.Site;
            objWebApp = objSPSite.WebApplication;
            DeleteJob(objSPSite);
            CreateJob(objSPSite);
        }

        /// <summary>
        /// This method is used to delete the timer job.
        /// </summary>
        /// <param name="site">Initialized object of the site.</param>
        private static void DeleteJob(SPSite site)
        {
            foreach (SPJobDefinition job in site.WebApplication.JobDefinitions)
                if (job.Name == JobName)
                    job.Delete();
        }

        /// <summary>
        /// This method is used to create the DMS timer job.
        /// </summary>
        /// <param name="site">Initialized object of the site.</param>
        private static void CreateJob(SPSite site)
        {
            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
                try
                {
                    ISATJobs objISATJobs = new ISATJobs(JobName, site.WebApplication);
                    //SPDailySchedule schedule = new SPDailySchedule();
                    //schedule.BeginHour = 22;
                    //schedule.BeginMinute = 0;
                    //schedule.BeginSecond = 0;
                    //schedule.EndHour = 23;
                    //schedule.EndMinute = 45;
                    //schedule.EndSecond = 0;
                    //objISATJobs.Schedule = schedule;
                    //objISATJobs.Update();

                    SPHourlySchedule hourlySchedule = new SPHourlySchedule();
                    hourlySchedule.BeginMinute = 0;
                    hourlySchedule.EndMinute = 5;
                    objISATJobs.Schedule = hourlySchedule;
                    objISATJobs.Update();
                }
                catch (Exception objException)
                {
                    LoggingService.LogError(LoggingService.DiagnosticCategoryJobs, objException.Message);
                }
            });
        }
        
        /// <summary>
        /// Feature deactivating event handler to delete the job and remove the persisted properties pertaining to this job.
        /// </summary>
        /// <param name="properties">Initialized object Feature receiver. </param>
        public override void FeatureDeactivating(SPFeatureReceiverProperties properties)
        {
            SPWeb objSPWeb = properties.Feature.Parent as SPWeb;
            SPSite objSPSite = objSPWeb.Site;
            DeleteJob(objSPSite);
        }
    }
}
