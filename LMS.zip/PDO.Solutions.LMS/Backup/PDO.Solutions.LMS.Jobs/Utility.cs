﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;

namespace PDO.Solutions.LMS.Jobs
{
    /// <summary>
    /// Utility Class
    /// </summary>
    public static class Utility
    {   
        /// <summary>
        /// 
        /// </summary>
        /// <param name="smtpAddress"></param>
        /// <param name="subject"></param>
        /// <param name="body"></param>
        /// <param name="isBodyHtml"></param>
        /// <param name="from"></param>
        /// <param name="to"></param>
        /// <param name="cc"></param>
        /// <param name="bcc"></param>
        /// <returns></returns>
        public static bool SendMail(string smtpAddress, string subject, string body, bool isBodyHtml, string from, string to, string cc, string bcc)
        {
            bool mailSent = false;
            SmtpClient smtpClient = null;

            try
            {
                smtpClient = new SmtpClient();
                smtpClient.Host = smtpAddress;
                                
                MailMessage mailMessage = new MailMessage(from, to, subject, body);
                if (!String.IsNullOrEmpty(cc))
                {                    
                    string[] CCId = cc.Split(';');

                    foreach (string CCEmail in CCId)
                    {
                        if (CCEmail != "")
                        {
                            mailMessage.CC.Add(new MailAddress(CCEmail));
                        }
                    }
                }

                if (!String.IsNullOrEmpty(bcc))
                {
                    string[] bCCId = bcc.Split(';');

                    foreach (string bCCEmail in bCCId)
                    {
                        if (bCCEmail != "")
                        {
                            mailMessage.CC.Add(new MailAddress(bCCEmail));
                        }
                    }
                }
                mailMessage.IsBodyHtml = isBodyHtml;                                
                smtpClient.Send(mailMessage);
                mailSent = true;
            }
            catch (Exception)
            {
                mailSent = false;
            }
            return mailSent;
        }

        /// <summary>
        /// Method to check existence of group names in the adGroups.
        /// </summary>
        /// <param name="groupNames">Group Names</param>
        /// <param name="adGroups">AD Group Names</param>
        /// <returns>Returns true if contained in the AD Group else returns false.</returns>
        public static bool ContainsGroup(this String groupNames, string adGroups)
        {
            bool isMember = false;
            isMember = adGroups.Split(';').Where(group => groupNames.Contains(group) && group != "").Any();
            return isMember;
        }
    }
}
