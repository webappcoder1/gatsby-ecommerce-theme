﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration;
using System.Net.Mail;
using Microsoft.SharePoint.Administration.DatabaseProvider;
using Microsoft.Office.Server.UserProfiles;
using Microsoft.SharePoint.Linq;
using System.DirectoryServices.ActiveDirectory;
using System.DirectoryServices.AccountManagement;
using System.DirectoryServices;
using System.Web;
using Microsoft.SharePoint.Utilities;
using System.Collections.Specialized;

namespace PDO.Solutions.LMS.Jobs
{
    /// <summary>
    /// Class for ISAT timer job.
    /// </summary>
    public class ISATJobs : SPJobDefinition
    {
        SPWebApplication webapp = null;
        SPWeb objSPWebISAT = null;
        String smtpAddress = string.Empty, from = "iSecure@pdo.co.om";

        /// <summary>
        /// Default 
        /// </summary>
        public ISATJobs()
            : base()
        {

        }

        /// <summary>
        /// Constructor to set the job name.
        /// </summary>
        /// <param name="jobName">Job Name</param>
        /// <param name="webapp">Web Application Name.</param>
        public ISATJobs(string jobName, SPWebApplication webapp)
            : base(jobName, webapp, null, SPJobLockType.Job)
        {
            this.Title = jobName;
        }

        /// <summary>
        /// This method is used to call the appropriated notification methods.
        /// </summary>
        /// <param name="targetInstanceId">Target Instance Id.</param>
        public override void Execute(Guid targetInstanceId)
        {
            webapp = this.Parent as SPWebApplication;
            SPContentDatabase contentDb = webapp.ContentDatabases[targetInstanceId];
            objSPWebISAT = webapp.Sites["/solutions/LMS"].AllWebs["ISAT"] as SPWeb;            
            smtpAddress = objSPWebISAT.Site.WebApplication.OutboundMailServiceInstance.Server.Address;
            SendDailyNotification();
            GetNewelyAddedADUsers();
            GetNewelyAddedUsersFromLDAP();
        }

        /// <summary>
        /// This method is used to get the newely added users to the User Profile Service.
        /// </summary>
        private void GetNewelyAddedADUsers()
        {
            List<SPUsersEntity> objListUserEntity = null;

            try
            {
                objListUserEntity = new List<SPUsersEntity>();
                objListUserEntity = GetUserProfiles(objSPWebISAT.Site);
                foreach (SPUsersEntity objSPUsersEntity in objListUserEntity)
                {
                    if (IsCompanyNumberExist(objSPUsersEntity.UserName) == false)
                    {
                        InsertEmployees(objSPUsersEntity);
                    }
                }
            }
            catch (Exception objException)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryJobs, objException.Message);
            }
            finally
            {
                objListUserEntity = null;
            }
        }

        /// <summary>
        /// This method is used to add the newely created users in AD
        /// </summary>
        private void GetNewelyAddedUsersFromLDAP()
        {
            try
            {
                DirectoryEntry myLdapConnection = CreateDirectoryEntry();
                DirectorySearcher search = new DirectorySearcher(myLdapConnection);
                search.Filter = "(&(objectCategory=Person) (objectClass=User)(whenCreated>=" + System.DateTime.Now.AddDays(-4).ToString("yyyyMMddHHmmss.sZ") + "))";
                SearchResultCollection searchResults = search.FindAll();
                SPUsersEntity objSPUserEntity = null;

                foreach (SearchResult result in searchResults)
                {
                    try
                    {
                        if (result != null)
                        {
                            if (result.Properties.Contains("sAMAccountName"))
                            {
                                objSPUserEntity = new SPUsersEntity();
                                if(IsUserInGroup(Convert.ToString(result.Properties["sAMAccountName"][0]).Replace("CORP\\", "")))
                                {
                                    objSPUserEntity = GetADUserAttributes(Convert.ToString(result.Properties["sAMAccountName"][0]).Replace("CORP\\", ""));
                                    if (IsCompanyNumberExist(objSPUserEntity.UserName) == false)
                                    {
                                        InsertEmployees(objSPUserEntity);
                                    }
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        LoggingService.LogError(LoggingService.DiagnosticCategoryJobs, ex.Message);
                    }
                }
            }
            catch (Exception e)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryJobs, e.Message);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        private DirectoryEntry CreateDirectoryEntry()
        {
            DirectoryEntry ldapConnection = new DirectoryEntry("LDAP://corp.pdo.om");
            return ldapConnection;
        }

        /// <summary>
        /// This method is used to insert the New users to the Employee list.
        /// </summary>
        /// <param name="objSPUsersEntity">Initialized object of the SPUsersEntity containing details about the user to be inserted. </param>
        private void InsertEmployees(SPUsersEntity objSPUsersEntity)
        {
            SPUser objSPUserEmployee = null;
            int flags;
            String userGroups = String.Empty, directorate = String.Empty, uname = string.Empty;

            try
            {
                bool isInGroup = IsUserInGroup(objSPUsersEntity.UserName);

                SPSecurity.RunWithElevatedPrivileges(delegate
                {
                    if (isInGroup)
                    {
                        SPList objSPListEmployees = objSPWebISAT.Lists["Employees"];
                        SPList objSPListDirectorates = objSPWebISAT.Lists["Directorates"];
                        SPListItem newItem = objSPListEmployees.AddItem();
                        uname = objSPUsersEntity.UserName;
                        newItem["Title"] = objSPUsersEntity.UserName;
                        newItem["CurrentModuleId"] = 10;
                        newItem["StartDate"] = DateTime.Now;
                        newItem["DisplayName"] = objSPUsersEntity.FirstName + " " + objSPUsersEntity.LastName;
                        newItem["Status"] = "P";
                        if (objSPUsersEntity.IsActive != null)
                        {
                            flags = int.Parse(objSPUsersEntity.IsActive);
                            if (!Convert.ToBoolean(flags & 0x0002))
                            {
                                //Active User
                                newItem["IsActive"] = 1;
                            }
                            else
                            {
                                //InActive User
                                newItem["IsActive"] = 0;
                            }
                        }
                        else
                        {
                            newItem["IsActive"] = 0;
                        }                       

                        newItem["NoOfAttempts"] = 0;
                        userGroups = GetUserGroups(objSPUsersEntity.UserName);
                        newItem["MemberOfGroups"] = userGroups;
                        directorate = GetUserDirectorate(userGroups, objSPListDirectorates);
                        newItem["Directorate"] = directorate;

                        uname = uname.ToLower();
                        if (uname.StartsWith("must")) newItem["AccountType"] = "Students";
                        else if (uname.StartsWith("muex")) newItem["AccountType"] = "External Users";
                        else if (uname.StartsWith("muc")) newItem["AccountType"] = "Contractors";
                        else if (uname.StartsWith("mu")) newItem["AccountType"] = "Employees";
                        else newItem["AccountType"] = "Others";

                        try
                        {
                            objSPUserEmployee = objSPWebISAT.EnsureUser(objSPUsersEntity.UserName);
                        }
                        catch (SPException objException)
                        {
                            LoggingService.LogError(LoggingService.DiagnosticCategoryJobs, objException.Message);
                        }

                        if (objSPUserEmployee != null)
                        {
                            newItem["EmployeeName"] = objSPUserEmployee;
                        }

                        newItem.Update();
                    }
                });
            }
            catch (Exception objException)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryJobs, objException.Message);
            }
            finally
            {
                objSPUserEmployee = null;
            }
        }

        /// <summary>
        /// This method is used to check whether the new user belongs to the "PDO-MD-Members-GS" or "PDO-Students-Members-GS" AD membership groups.
        /// </summary>
        /// <param name="companyNumber">Company Number</param>
        /// <returns>Returns true if the user is in the group else returns false.</returns>
        private bool IsUserInGroup(string companyNumber)
        {
            bool isUserInGroup = false;

            try
            {
                PrincipalContext ctx = new PrincipalContext(ContextType.Domain, "CORP");
                UserPrincipal user = UserPrincipal.FindByIdentity(ctx, companyNumber);
                GroupPrincipal mdGroup = GroupPrincipal.FindByIdentity(ctx, "PDO-MD-Members-GS");
                GroupPrincipal studentGroup = GroupPrincipal.FindByIdentity(ctx, "PDO-All-Students-GS");
                GroupPrincipal empGroup = GroupPrincipal.FindByIdentity(ctx, "PDO-All-Employees-GS");
                GroupPrincipal contGroup = GroupPrincipal.FindByIdentity(ctx, "PDO-All-Contractors-GS");
                GroupPrincipal extGroup = GroupPrincipal.FindByIdentity(ctx, "PDO-All-ExternalAccounts-GS");

                if (user != null)
                {
                    if (user.IsMemberOf(mdGroup) || user.IsMemberOf(studentGroup) || user.IsMemberOf(empGroup) || user.IsMemberOf(contGroup) || user.IsMemberOf(extGroup))
                    {
                        isUserInGroup = true;
                    }
                }
            }
            catch (Exception objException)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryJobs, objException.Message);
            }

            return isUserInGroup;
        }

        /// <summary>
        /// This method is used to get the User Principal object by the User Name(AD Id).
        /// </summary>
        /// <param name="sUserName">User Name(AD Id)</param>
        /// <returns>Returns initialized object of the UserPrincipal.</returns>
        public UserPrincipal GetUser(string sUserName)
        {
            PrincipalContext oPrincipalContext = GetPrincipalContext();
            UserPrincipal oUserPrincipal = UserPrincipal.FindByIdentity(oPrincipalContext, sUserName);
            return oUserPrincipal;
        }

        /// <summary>
        /// This method is used to get the principal object of the CORP domain.
        /// </summary>
        /// <returns>Returns initialized object of the PrincipalContext</returns>
        public PrincipalContext GetPrincipalContext()
        {
            PrincipalContext oPrincipalContext = new PrincipalContext(ContextType.Domain, "CORP");
            return oPrincipalContext;
        }

        /// <summary>
        /// This method is used to get the list of all the groups that the user belongs to.
        /// </summary>
        /// <param name="sUserName">User Name(AD Id)</param>
        /// <returns>Returns the concatenated string of AD membership group names that the passed AD User belongs to.</returns>
        private String GetUserGroups(string sUserName)
        {
            List<String> lstGroups = null;
            StringBuilder sbGroups = null;

            try
            {
                lstGroups = new List<string>();
                sbGroups = new StringBuilder();
                UserPrincipal oUserPrincipal = GetUser(sUserName);
                PrincipalSearchResult<Principal> oPrincipalSearchResult = oUserPrincipal.GetGroups();
                lstGroups = oPrincipalSearchResult.AsEnumerable()
                    .Where(principal => principal.Name.EndsWith("-Members-GS") || principal.Name.EndsWith("All-Employees-GS") || principal.Name.EndsWith("All-Students-GS") || principal.Name.EndsWith("All-ExternalAccounts-GS") || principal.Name.EndsWith("All-Contractors-GS"))
                    .Select(principal => principal.Name).ToList<string>();
                foreach (var group in lstGroups)
                {
                    sbGroups.Append(group + " ");
                }
            }
            catch (Exception objException)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryJobs, objException.Message);
            }
            finally
            {
                lstGroups = null;
            }

            return sbGroups.ToString();
        }

        /// <summary>
        /// Method to grand the update access to the Timer job schedule.
        /// </summary>
        /// <returns>Always returns true to indicate the additional access given to update the Job definition.</returns>
        protected override bool HasAdditionalUpdateAccess()
        {
            return true;
        }

        /// <summary>
        /// This method is used to check whether the Company Number is already existing in the Employees List.
        /// </summary>
        /// <param name="companyNumber">Company Number</param>
        /// <returns>Returns true if the company number is existing in the Employees List else returns false.</returns>
        private bool IsCompanyNumberExist(string companyNumber)
        {
            bool isExist = false;
            DataTable dtEmployees = null;

            try
            {
                using (dtEmployees = new DataTable())
                {
                    SPQuery query = new SPQuery();
                    DateTime dtExpiryDate = DateTime.Now.AddDays(-33);
                    query.Query = @"<Where>
                              <Eq>
                                 <FieldRef Name='Title' />
                                 <Value Type='Text'>" + companyNumber.Replace("CORP\\", "") + @"</Value>
                              </Eq>
                           </Where>";

                    query.QueryThrottleMode = SPQueryThrottleOption.Override;
                    query.ViewFields = @"<FieldRef Name='Title' />";
                    query.ViewFieldsOnly = true;
                    string listUrl = objSPWebISAT.ServerRelativeUrl + "/Lists/Employees";
                    SPList list = objSPWebISAT.GetList(listUrl);
                    dtEmployees = list.GetItems(query).GetDataTable();
                    if (dtEmployees != null && dtEmployees.Rows.Count > 0)
                    {
                        isExist = true;
                    }
                }
            }
            catch (Exception objException)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryJobs, objException.Message);
            }
            finally
            {
                dtEmployees = null;
            }

            return isExist;
        }

        /// <summary>
        /// This method is used to get all the changed/added user profiles.
        /// </summary>
        /// <param name="site">Initialized object of the SPSite (Site Collection.)</param>
        /// <returns>Returns the List of Modified/Added Users.</returns>
        public List<SPUsersEntity> GetUserProfiles(SPSite site)
        {
            List<SPUsersEntity> objLstSPUsersEntity = null;
            SPUsersEntity objSPUserEntity = null;
            UserProfileChangeToken objUserProfileChangeToken = null;
            UserProfileChangeCollection objUserProfileChangeCollection = null;

            try
            {
                objSPUserEntity = new SPUsersEntity();
                var serviceContext = SPServiceContext.GetContext(site);
                objLstSPUsersEntity = new List<SPUsersEntity>();
                //changed here to get last 5 day user records
                objUserProfileChangeToken = new UserProfileChangeToken(DateTime.Now.AddDays(-1));
                var userProfileManager = new UserProfileTypedManager(serviceContext).GetChanges(objUserProfileChangeToken);
                objUserProfileChangeCollection = new UserProfileTypedManager(serviceContext).GetChanges(objUserProfileChangeToken);

                foreach (UserProfileChange objUserProfileChange in objUserProfileChangeCollection)
                {
                    String accountName = objUserProfileChange.AccountName;
                    objSPUserEntity = GetADUserAttributes(accountName.Replace("CORP\\", ""));
                    objLstSPUsersEntity.Add(objSPUserEntity);
                }
            }
            catch (Exception objException)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryJobs, objException.Message);
            }
            finally
            {
                objSPUserEntity = null;
                objUserProfileChangeToken = null;
                objUserProfileChangeCollection = null;
            }

            return objLstSPUsersEntity;
        }

        /// <summary>
        /// This method is used to get the AD User attributes of the passed Active Directory Id.
        /// </summary>
        /// <param name="userADId">User Active Directory Id.</param>
        /// <returns>Returns the initialized object of the SPUsersEntity containing the details of the User.</returns>
        private SPUsersEntity GetADUserAttributes(string userADId)
        {
            SPUsersEntity objSPUsersEntity = null;
            PrincipalContext objPrincipalContext = null;

            try
            {
                objSPUsersEntity = new SPUsersEntity();
                objPrincipalContext = new PrincipalContext(ContextType.Domain, "CORP");
                UserPrincipal user = UserPrincipal.FindByIdentity(objPrincipalContext, userADId);
                DirectoryEntry objDirectoryEntry = user.GetUnderlyingObject() as DirectoryEntry;

                if (user != null)
                {
                    if (objDirectoryEntry.Properties.Contains("displayName"))
                        objSPUsersEntity.DisplayName = objDirectoryEntry.Properties["displayName"].Value.ToString();

                    if (objDirectoryEntry.Properties.Contains("sAMAccountName"))
                        objSPUsersEntity.UserName = objDirectoryEntry.Properties["sAMAccountName"].Value.ToString();

                    if (objDirectoryEntry.Properties.Contains("givenName"))
                        objSPUsersEntity.FirstName = objDirectoryEntry.Properties["givenName"].Value.ToString();

                    if (objDirectoryEntry.Properties.Contains("sn"))
                        objSPUsersEntity.LastName = objDirectoryEntry.Properties["sn"].Value.ToString();

                    if (objDirectoryEntry.Properties.Contains("userAccountControl"))
                        objSPUsersEntity.IsActive = objDirectoryEntry.Properties["userAccountControl"].Value.ToString();

                    if (objDirectoryEntry.Properties.Contains("department"))
                        objSPUsersEntity.RefIndicator = objDirectoryEntry.Properties["department"].Value.ToString();
                }

            }
            catch (Exception objException)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryJobs, objException.Message);
            }
            finally
            {
                objPrincipalContext = null;
            }

            return objSPUsersEntity;
        }

        private string GetEmailImage(string siteURL, bool flag)
        {
            string imgURL = string.Empty;

            if (flag)
            {
                imgURL = siteURL + "/PublishingImages/EmailHeader.jpg";
            }
            else
            {
                imgURL = siteURL + "/PublishingImages/EmailFooter.jpg";
            }

            return imgURL;
        }

        /// <summary>
        /// Method to call pending and expiry notification reminder.
        /// </summary>
        private void SendDailyNotification()
        {
            try
            {
                SPSecurity.RunWithElevatedPrivileges(delegate()
                {
                    using (SPSite objSPSite = new SPSite(objSPWebISAT.Site.Url))
                    {
                        objSPSite.AllowUnsafeUpdates = true;
                        using (SPWeb objSPWeb = objSPSite.AllWebs["ISAT"] as SPWeb)
                        {
                            objSPWeb.AllowUnsafeUpdates = true;
                            SPList objSPListConfiguration = objSPWeb.Lists["Configurations"];
                            SPListItem sendNotification = (from SPListItem objConfigurationListItem in objSPListConfiguration.Items
                                                           where (bool)objConfigurationListItem["To Do"] == true && objConfigurationListItem["Title"].ToString() == "SendNotification"
                                                           select objConfigurationListItem).FirstOrDefault();
                            if (sendNotification != null)
                            {
                                DateTime dtCurrentDate = DateTime.Now.Date;
                                DateTime dtLastStartedOn = DateTime.Parse(sendNotification["StartedOn"].ToString());
                                if (dtCurrentDate > dtLastStartedOn)
                                {
                                    PendingNotificationReminder(objSPWeb);
                                    ExpiryNotificationReminder(objSPWeb);
                                    RefreshConfiguration();
                                    sendNotification["Log"] = "Completed Daily Notification Job On: " + DateTime.Now.ToString();
                                    sendNotification["StartedOn"] = dtCurrentDate;
                                    sendNotification.SystemUpdate();
                                }
                            }
                        }
                    }
                });
            }
            catch (Exception objException)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryJobs, objException.Message);
            }
        }

        /// <summary>
        /// This method is used to send the expiry notification to the users whose Certificate is due for expiry.
        /// </summary>
        private void ExpiryNotificationReminder(SPWeb objSPWeb)
        {
            DataTable dtAllMailTemplates = null;
            UserInfo objUserInfo = null;
            UserInfo objManagerInfo = null;
            UserInfo objSupervisorInfo = null;
            StringDictionary headers = new StringDictionary();
            string userName = string.Empty, userEmail = string.Empty;
            Dictionary<string, string> userDetail = new Dictionary<string, string>();
            string siteURL = objSPWeb.Url;

            try
            {
                DataTable dtEmployeeCertExpiry = GetEmpCertDueForExpiry();
                if (dtEmployeeCertExpiry != null && dtEmployeeCertExpiry.Rows.Count > 0)
                {
                    int dayCount = 0;

                    using (dtAllMailTemplates = new DataTable())
                    {
                        dtAllMailTemplates = GetAllMailTemplates();

                        if (dtAllMailTemplates != null && dtAllMailTemplates.Rows.Count > 0)
                        {
                            String subject = String.Empty, body = String.Empty;
                            String to = String.Empty, manager = String.Empty, cc = String.Empty;
                            objUserInfo = new UserInfo();
                            objManagerInfo = new UserInfo();
                            objSupervisorInfo = new UserInfo();
                            DataRow drNotificationTemplate = null;

                            foreach (DataRow drEmployee in dtEmployeeCertExpiry.Rows)
                            {
                                subject = body = to = manager = cc = String.Empty;

                                try
                                {
                                    DateTime dtCurrentDate = DateTime.Now.Date;
                                    DateTime dtExpiryDate = DateTime.Parse(drEmployee["ExpiryDate"].ToString()).Date;
                                    dayCount = int.Parse(((dtExpiryDate - dtCurrentDate).TotalDays).ToString());

                                    try
                                    {
                                        switch (dayCount)
                                        {
                                            case 33:
                                                drNotificationTemplate = (from DataRow drMailTemplate in dtAllMailTemplates.Rows
                                                                          where drMailTemplate["NotificationType"].ToString() == "ISAT-Expiry-Reminder"
                                                                          select drMailTemplate).FirstOrDefault();
                                                objUserInfo = GetUserDetails(drEmployee["Title"].ToString());
                                                if (objUserInfo != null)
                                                {
                                                    if (!string.IsNullOrEmpty(objUserInfo.EmailId))
                                                    {
                                                        to = objUserInfo.EmailId;
                                                    }
                                                    else
                                                    {
                                                        objManagerInfo = GetUserDetails(objUserInfo.ManagerADId);
                                                        to = objManagerInfo.EmailId.ToString();
                                                    }

                                                    if (to != "")
                                                    {
                                                        subject = drNotificationTemplate["Subject"].ToString();
                                                        body = String.Format(HttpUtility.HtmlDecode("<div style='float:left'>" + drNotificationTemplate["Body"].ToString() + "</div>"), objUserInfo.DisplayName, dtExpiryDate.Date.ToString("dd-MMM-yyyy"), dtExpiryDate.Date.ToString("dd-MMM-yyyy"));
                                                        body = body.Replace("imgEmailHeader", string.Format("<img src={0} alt=''/>", GetEmailImage(siteURL, true)));
                                                        body = body.Replace("ISATLinkURL", string.Format("<a href={0}>here</a>", siteURL));
                                                        body = body.Replace("ISATLinkURL", string.Format("<a href={0}>here</a>", siteURL));
                                                        body = body.Replace("imgEmailFooter", string.Format("<img src={0} alt=''/>", GetEmailImage(siteURL, false)));
                                                        headers.Clear();
                                                        headers.Add("from", from);
                                                        headers.Add("to", to);
                                                        headers.Add("subject", subject);
                                                        headers.Add("content-type", "text/html");

                                                        SPUtility.SendEmail(objSPWeb, headers, body);
                                                    }
                                                }

                                                break;

                                            case 28:
                                                drNotificationTemplate = (from DataRow drMailTemplate in dtAllMailTemplates.Rows
                                                                          where drMailTemplate["NotificationType"].ToString() == "ISAT-Expiry-Reminder"
                                                                          select drMailTemplate).FirstOrDefault();
                                                objUserInfo = GetUserDetails(drEmployee["Title"].ToString());

                                                if (objUserInfo != null)
                                                {
                                                    if (!string.IsNullOrEmpty(objUserInfo.EmailId))
                                                    {
                                                        to = objUserInfo.EmailId;
                                                    }
                                                    else
                                                    {
                                                        objManagerInfo = GetUserDetails(objUserInfo.ManagerADId);
                                                        to = objManagerInfo.EmailId.ToString();
                                                    }

                                                    if (to != "")
                                                    {
                                                        subject = drNotificationTemplate["Subject"].ToString();
                                                        body = String.Format(HttpUtility.HtmlDecode("<div style='float:left'>" + drNotificationTemplate["Body"].ToString() + "</div>"), objUserInfo.DisplayName, dtExpiryDate.Date.ToString("dd-MMM-yyyy"), dtExpiryDate.Date.ToString("dd-MMM-yyyy"));
                                                        body = body.Replace("imgEmailHeader", string.Format("<img src={0} alt=''/>", GetEmailImage(siteURL, true)));
                                                        body = body.Replace("ISATLinkURL", string.Format("<a href={0}>here</a>", siteURL));
                                                        body = body.Replace("ISATLinkURL", string.Format("<a href={0}>here</a>", siteURL));
                                                        body = body.Replace("imgEmailFooter", string.Format("<img src={0} alt=''/>", GetEmailImage(siteURL, false)));
                                                        headers.Clear();
                                                        headers.Add("from", from);
                                                        headers.Add("to", to);
                                                        headers.Add("subject", subject);
                                                        headers.Add("content-type", "text/html");

                                                        SPUtility.SendEmail(objSPWeb, headers, body);
                                                    }
                                                }
                                                
                                                break;

                                            case 21:
                                                drNotificationTemplate = (from DataRow drMailTemplate in dtAllMailTemplates.Rows
                                                                          where drMailTemplate["NotificationType"].ToString() == "ISAT-Expiry-Reminder"
                                                                          select drMailTemplate).FirstOrDefault();

                                                objUserInfo = GetUserDetails(drEmployee["Title"].ToString());
                                                if (objUserInfo != null)
                                                {
                                                    if (!string.IsNullOrEmpty(objUserInfo.EmailId))
                                                    {
                                                        to = objUserInfo.EmailId;
                                                    }
                                                    else
                                                    {
                                                        objManagerInfo = GetUserDetails(objUserInfo.ManagerADId);
                                                        to = objManagerInfo.EmailId.ToString();
                                                    }

                                                    if (to != "")
                                                    {
                                                        subject = drNotificationTemplate["Subject"].ToString();
                                                        body = String.Format(HttpUtility.HtmlDecode("<div style='float:left'>" + drNotificationTemplate["Body"].ToString() + "</div>"), objUserInfo.DisplayName, dtExpiryDate.Date.ToString("dd-MMM-yyyy"), dtExpiryDate.Date.ToString("dd-MMM-yyyy"));
                                                        body = body.Replace("imgEmailHeader", string.Format("<img src={0} alt=''/>", GetEmailImage(siteURL, true)));
                                                        body = body.Replace("ISATLinkURL", string.Format("<a href={0}>here</a>", siteURL));
                                                        body = body.Replace("ISATLinkURL", string.Format("<a href={0}>here</a>", siteURL));
                                                        body = body.Replace("imgEmailFooter", string.Format("<img src={0} alt=''/>", GetEmailImage(siteURL, false)));
                                                        headers.Clear();
                                                        headers.Add("from", from);
                                                        headers.Add("to", to);
                                                        headers.Add("subject", subject);
                                                        headers.Add("content-type", "text/html");

                                                        SPUtility.SendEmail(objSPWeb, headers, body);
                                                    }
                                                }

                                                break;

                                            case 14:
                                                drNotificationTemplate = (from DataRow drMailTemplate in dtAllMailTemplates.Rows
                                                                          where drMailTemplate["NotificationType"].ToString() == "ISAT-Expiry-Reminder"
                                                                          select drMailTemplate).FirstOrDefault();
                                                objUserInfo = GetUserDetails(drEmployee["Title"].ToString());
                                                if (objUserInfo != null)
                                                {
                                                    if (!string.IsNullOrEmpty(objUserInfo.EmailId))
                                                    {
                                                        to = objUserInfo.EmailId;
                                                    }

                                                    objManagerInfo = GetUserDetails(objUserInfo.ManagerADId);
                                                    if (objManagerInfo != null)
                                                    {
                                                        cc = objManagerInfo.EmailId;
                                                    }                                                    

                                                    if (to == "")
                                                    {
                                                        to = objManagerInfo.EmailId;
                                                    }

                                                    if (to != "")
                                                    {
                                                        subject = drNotificationTemplate["Subject"].ToString();
                                                        body = String.Format(HttpUtility.HtmlDecode("<div style='float:left'>" + drNotificationTemplate["Body"].ToString() + "</div>"), objUserInfo.DisplayName, dtExpiryDate.Date.ToString("dd-MMM-yyyy"), dtExpiryDate.Date.ToString("dd-MMM-yyyy"));
                                                        body = body.Replace("imgEmailHeader", string.Format("<img src={0} alt=''/>", GetEmailImage(siteURL, true)));
                                                        body = body.Replace("ISATLinkURL", string.Format("<a href={0}>here</a>", siteURL));
                                                        body = body.Replace("ISATLinkURL", string.Format("<a href={0}>here</a>", siteURL));
                                                        body = body.Replace("imgEmailFooter", string.Format("<img src={0} alt=''/>", GetEmailImage(siteURL, false)));
                                                        headers.Clear();
                                                        headers.Add("from", from);
                                                        headers.Add("to", to);
                                                        headers.Add("cc", cc);
                                                        headers.Add("subject", subject);
                                                        headers.Add("content-type", "text/html");

                                                        SPUtility.SendEmail(objSPWeb, headers, body);
                                                    }
                                                }
                                                break;

                                            case 7:
                                                drNotificationTemplate = (from DataRow drMailTemplate in dtAllMailTemplates.Rows
                                                                          where drMailTemplate["NotificationType"].ToString() == "ISAT-Expiry"
                                                                          select drMailTemplate).FirstOrDefault();
                                                objUserInfo = GetUserDetails(drEmployee["Title"].ToString());
                                                if (objUserInfo != null)
                                                {
                                                    if (!string.IsNullOrEmpty(objUserInfo.EmailId))
                                                    {
                                                        to = objUserInfo.EmailId;
                                                    }

                                                    objManagerInfo = GetUserDetails(objUserInfo.ManagerADId);

                                                    if (objManagerInfo != null)
                                                    {
                                                        cc = objManagerInfo.EmailId;
                                                    }

                                                    /* ISAT Business team told they dont want Supervisor's Supervisor escalations.*/

                                                    //objSupervisorInfo = GetUserDetails(objManagerInfo.ManagerADId);

                                                    //if (objSupervisorInfo != null)
                                                    //{
                                                    //    if (cc != "")
                                                    //    {
                                                    //        cc += ";" + objSupervisorInfo.EmailId;
                                                    //    }
                                                    //    else
                                                    //    {
                                                    //        cc = objSupervisorInfo.EmailId;
                                                    //    }
                                                    //}

                                                    if (to == "")
                                                    {
                                                        to = objManagerInfo.EmailId;
                                                    }

                                                    if (to != "")
                                                    {
                                                        subject = drNotificationTemplate["Subject"].ToString();
                                                        body = String.Format(HttpUtility.HtmlDecode("<div style='float:left'>" + drNotificationTemplate["Body"].ToString() + "</div>"), objUserInfo.DisplayName, dtExpiryDate.Date.ToString("dd-MMM-yyyy"), dtExpiryDate.Date.ToString("dd-MMM-yyyy"));
                                                        body = body.Replace("imgEmailHeader", string.Format("<img src={0} alt=''/>", GetEmailImage(siteURL, true)));
                                                        body = body.Replace("ISATLinkURL", string.Format("<a href={0}>here</a>", siteURL));
                                                        body = body.Replace("ISATLinkURL", string.Format("<a href={0}>here</a>", siteURL));
                                                        body = body.Replace("imgEmailFooter", string.Format("<img src={0} alt=''/>", GetEmailImage(siteURL, false)));
                                                        headers.Clear();
                                                        headers.Add("from", from);
                                                        headers.Add("to", to);
                                                        headers.Add("cc", cc);
                                                        headers.Add("subject", subject);
                                                        headers.Add("content-type", "text/html");

                                                        SPUtility.SendEmail(objSPWeb, headers, body);
                                                    }
                                                }
                                                break;

                                            default:
                                                break;
                                        }
                                    }
                                    catch (Exception objException)
                                    {
                                        LoggingService.LogError(LoggingService.DiagnosticCategoryJobs, objException.Message);
                                    }
                                }
                                catch (Exception objException)
                                {
                                    LoggingService.LogError(LoggingService.DiagnosticCategoryJobs, objException.Message);
                                }
                            }
                        }

                    }
                }
            }
            catch (Exception objException)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryJobs, objException.Message);
            }
            finally
            {
                dtAllMailTemplates = null;
                objUserInfo = null;
                objManagerInfo = null;
                objSupervisorInfo = null;
            }
        }

        /// <summary>
        /// This method is used to send the Notification reminder the user who has not completed the ISAT.
        /// </summary>
        private void PendingNotificationReminder(SPWeb objSPWeb)
        {
            DataTable dtEmployees = GetEmpByCompletionStatus("P");
            DataTable dtAllMailTemplates = null;
            UserInfo objUserInfo = null;
            UserInfo objManagerInfo = null;
            UserInfo objSupervisorInfo = null;
            int dayCount = 0;
            StringDictionary headers = new StringDictionary();
            string userName = string.Empty, userEmail = string.Empty;
            Dictionary<string, string> userDetail = new Dictionary<string, string>();
            string siteURL = objSPWeb.Url;

            try
            {
                if (dtEmployees != null && dtEmployees.Rows.Count > 0)
                {
                    using (dtAllMailTemplates = new DataTable())
                    {
                        dtAllMailTemplates = GetAllMailTemplates();
                        if (dtAllMailTemplates != null && dtAllMailTemplates.Rows.Count > 0)
                        {
                            String subject = String.Empty, body = String.Empty, to = String.Empty, manager = String.Empty, cc = String.Empty;
                            objUserInfo = new UserInfo();
                            objManagerInfo = new UserInfo();
                            objSupervisorInfo = new UserInfo();
                            DataRow drNotificationTemplate = null;

                            foreach (DataRow drEmployee in dtEmployees.Rows)
                            {
                                try
                                {
                                    subject = body = to = manager = cc = String.Empty;
                                    DateTime dtCurrentDate = DateTime.Now.Date;
                                    DateTime dtStartDate = DateTime.Parse(drEmployee["StartDate1"].ToString()).Date;
                                    dayCount = int.Parse(((dtCurrentDate - dtStartDate).TotalDays).ToString());

                                    switch (dayCount)
                                    {
                                        //Notification on 3rd Day
                                        case 3:
                                            drNotificationTemplate = (from DataRow drMailTemplate in dtAllMailTemplates.Rows
                                                                      where drMailTemplate["NotificationType"].ToString() == "ISAT-Pending-First"
                                                                      select drMailTemplate).FirstOrDefault();

                                            objUserInfo = GetUserDetails(drEmployee["Title"].ToString());
                                            if (objUserInfo != null)
                                            {
                                                if (!string.IsNullOrEmpty(objUserInfo.EmailId))
                                                {
                                                    to = objUserInfo.EmailId;
                                                }
                                                else
                                                {
                                                    objManagerInfo = GetUserDetails(objUserInfo.ManagerADId);
                                                    to = objManagerInfo.EmailId.ToString();
                                                }

                                                if (to != "")
                                                {
                                                    subject = drNotificationTemplate["Subject"].ToString();
                                                    body = String.Format(HttpUtility.HtmlDecode("<div style='float:left'>" + drNotificationTemplate["Body"].ToString() + "</div>"), objUserInfo.DisplayName);
                                                    body = body.Replace("imgEmailHeader", string.Format("<img src={0} alt=''/>", GetEmailImage(siteURL, true)));
                                                    body = body.Replace("ISATLinkURL", string.Format("<a href={0}>here</a>", siteURL));
                                                    body = body.Replace("ISATLinkURL", string.Format("<a href={0}>here</a>", siteURL));
                                                    body = body.Replace("imgEmailFooter", string.Format("<img src={0} alt=''/>", GetEmailImage(siteURL, false)));
                                                    headers.Clear();
                                                    headers.Add("from", from);
                                                    headers.Add("to", to);
                                                    headers.Add("subject", subject);
                                                    headers.Add("content-type", "text/html");

                                                    SPUtility.SendEmail(objSPWeb, headers, body);
                                                }
                                            }

                                            break;
                                        //Notification on 7th Day
                                        case 7:
                                            drNotificationTemplate = (from DataRow drMailTemplate in dtAllMailTemplates.Rows
                                                                      where drMailTemplate["NotificationType"].ToString() == "ISAT-Pending-Reminder"
                                                                      select drMailTemplate).FirstOrDefault();
                                            objUserInfo = GetUserDetails(drEmployee["Title"].ToString());
                                            if (objUserInfo != null)
                                            {
                                                if (!string.IsNullOrEmpty(objUserInfo.EmailId))
                                                {
                                                    to = objUserInfo.EmailId;
                                                }
                                                else
                                                {
                                                    objManagerInfo = GetUserDetails(objUserInfo.ManagerADId);
                                                    to = objManagerInfo.EmailId.ToString();
                                                }

                                                if (to != "")
                                                {
                                                    subject = drNotificationTemplate["Subject"].ToString();
                                                    body = String.Format(HttpUtility.HtmlDecode("<div style='float:left'>" + drNotificationTemplate["Body"].ToString() + "</div>"), objUserInfo.DisplayName, objUserInfo.DisplayName);
                                                    body = body.Replace("imgEmailHeader", string.Format("<img src={0} alt=''/>", GetEmailImage(siteURL, true)));
                                                    body = body.Replace("ISATLinkURL", string.Format("<a href={0}>here</a>", siteURL));
                                                    body = body.Replace("ISATLinkURL", string.Format("<a href={0}>here</a>", siteURL));
                                                    body = body.Replace("imgEmailFooter", string.Format("<img src={0} alt=''/>", GetEmailImage(siteURL, false)));
                                                    headers.Clear();
                                                    headers.Add("from", from);
                                                    headers.Add("to", to);
                                                    headers.Add("subject", subject);
                                                    headers.Add("content-type", "text/html");

                                                    SPUtility.SendEmail(objSPWeb, headers, body);
                                                }
                                            }
                                            break;

                                        //Notification on 14th Day
                                        case 14:
                                            drNotificationTemplate = (from DataRow drMailTemplate in dtAllMailTemplates.Rows
                                                                      where drMailTemplate["NotificationType"].ToString() == "ISAT-Pending-Reminder"
                                                                      select drMailTemplate).FirstOrDefault();
                                            objUserInfo = GetUserDetails(drEmployee["Title"].ToString());
                                            if (objUserInfo != null)
                                            {
                                                if (!string.IsNullOrEmpty(objUserInfo.EmailId))
                                                {
                                                    to = objUserInfo.EmailId;
                                                }
                                                else
                                                {
                                                    objManagerInfo = GetUserDetails(objUserInfo.ManagerADId);
                                                    to = objManagerInfo.EmailId.ToString();
                                                }

                                                if (to != "")
                                                {
                                                    subject = drNotificationTemplate["Subject"].ToString();
                                                    body = String.Format(HttpUtility.HtmlDecode("<div style='float:left'>" + drNotificationTemplate["Body"].ToString() + "</div>"), objUserInfo.DisplayName, objUserInfo.DisplayName);
                                                    body = body.Replace("imgEmailHeader", string.Format("<img src={0} alt=''/>", GetEmailImage(siteURL, true)));
                                                    body = body.Replace("ISATLinkURL", string.Format("<a href={0}>here</a>", siteURL));
                                                    body = body.Replace("ISATLinkURL", string.Format("<a href={0}>here</a>", siteURL));
                                                    body = body.Replace("imgEmailFooter", string.Format("<img src={0} alt=''/>", GetEmailImage(siteURL, false)));
                                                    headers.Clear();
                                                    headers.Add("from", from);
                                                    headers.Add("to", to);
                                                    headers.Add("subject", subject);
                                                    headers.Add("content-type", "text/html");

                                                    SPUtility.SendEmail(objSPWeb, headers, body);
                                                }
                                            }
                                            break;

                                        //Notification on 21st Day
                                        case 21:
                                            drNotificationTemplate = (from DataRow drMailTemplate in dtAllMailTemplates.Rows
                                                                      where drMailTemplate["NotificationType"].ToString() == "ISAT-Pending-Reminder"
                                                                      select drMailTemplate).FirstOrDefault();

                                            objUserInfo = GetUserDetails(drEmployee["Title"].ToString());

                                            if (objUserInfo != null)
                                            {
                                                if (!string.IsNullOrEmpty(objUserInfo.EmailId))
                                                {
                                                    to = objUserInfo.EmailId;
                                                }

                                                objManagerInfo = GetUserDetails(objUserInfo.ManagerADId);
                                                if (objManagerInfo != null)
                                                {
                                                    cc = objManagerInfo.EmailId;
                                                }

                                                if (to == "")
                                                {
                                                    to = objManagerInfo.EmailId;
                                                }

                                                if (to != "")
                                                {
                                                    subject = drNotificationTemplate["Subject"].ToString();
                                                    body = String.Format(HttpUtility.HtmlDecode("<div style='float:left'>" + drNotificationTemplate["Body"].ToString() + "</div>"), objUserInfo.DisplayName, objUserInfo.DisplayName);
                                                    body = body.Replace("imgEmailHeader", string.Format("<img src={0} alt=''/>", GetEmailImage(siteURL, true)));
                                                    body = body.Replace("ISATLinkURL", string.Format("<a href={0}>here</a>", siteURL));
                                                    body = body.Replace("ISATLinkURL", string.Format("<a href={0}>here</a>", siteURL));
                                                    body = body.Replace("imgEmailFooter", string.Format("<img src={0} alt=''/>", GetEmailImage(siteURL, false)));
                                                    headers.Clear();
                                                    headers.Add("from", from);
                                                    headers.Add("to", to);
                                                    headers.Add("cc", cc);
                                                    headers.Add("subject", subject);
                                                    headers.Add("content-type", "text/html");

                                                    SPUtility.SendEmail(objSPWeb, headers, body);
                                                }
                                            }
                                            break;

                                        //Notification on 28th Day
                                        case 28:
                                            drNotificationTemplate = (from DataRow drMailTemplate in dtAllMailTemplates.Rows
                                                                      where drMailTemplate["NotificationType"].ToString() == "ISAT-Pending-Reminder"
                                                                      select drMailTemplate).FirstOrDefault();
                                            objUserInfo = GetUserDetails(drEmployee["Title"].ToString());

                                            if (objUserInfo != null)
                                            {
                                                if (!string.IsNullOrEmpty(objUserInfo.EmailId))
                                                {
                                                    to = objUserInfo.EmailId;
                                                }

                                                objManagerInfo = GetUserDetails(objUserInfo.ManagerADId);
                                                if (objManagerInfo != null)
                                                {
                                                    cc = objManagerInfo.EmailId;
                                                }
                                                /* ISAT Business team told they dont want Supervisor's Supervisor escalations.*/
                                                //objSupervisorInfo = GetUserDetails(objManagerInfo.ManagerADId);
                                                //if (objSupervisorInfo != null)
                                                //{
                                                //    if (cc != "")
                                                //    {
                                                //        cc += ";" + objSupervisorInfo.EmailId;
                                                //    }
                                                //    else
                                                //    {
                                                //        cc = objSupervisorInfo.EmailId;
                                                //    }
                                                //}

                                                if (to == "")
                                                {
                                                    to = objManagerInfo.EmailId;
                                                }

                                                if (to != "")
                                                {
                                                    subject = drNotificationTemplate["Subject"].ToString();
                                                    body = String.Format(HttpUtility.HtmlDecode("<div style='float:left'>" + drNotificationTemplate["Body"].ToString() + "</div>"), objUserInfo.DisplayName, objUserInfo.DisplayName);
                                                    body = body.Replace("imgEmailHeader", string.Format("<img src={0} alt=''/>", GetEmailImage(siteURL, true)));
                                                    body = body.Replace("ISATLinkURL", string.Format("<a href={0}>here</a>", siteURL));
                                                    body = body.Replace("ISATLinkURL", string.Format("<a href={0}>here</a>", siteURL));
                                                    body = body.Replace("imgEmailFooter", string.Format("<img src={0} alt=''/>", GetEmailImage(siteURL, false)));
                                                    headers.Clear();
                                                    headers.Add("from", from);
                                                    headers.Add("to", to);
                                                    headers.Add("cc", cc);
                                                    headers.Add("subject", subject);
                                                    headers.Add("content-type", "text/html");

                                                    SPUtility.SendEmail(objSPWeb, headers, body);
                                                }
                                            }

                                            break;

                                        //Notification on 33rd Day
                                        case 33:
                                            drNotificationTemplate = (from DataRow drMailTemplate in dtAllMailTemplates.Rows
                                                                      where drMailTemplate["NotificationType"].ToString() == "ISAT-Pending-Final"
                                                                      select drMailTemplate).FirstOrDefault();
                                            objUserInfo = GetUserDetails(drEmployee["Title"].ToString());

                                            if (objUserInfo != null)
                                            {
                                                if (!string.IsNullOrEmpty(objUserInfo.EmailId))
                                                {
                                                    to = objUserInfo.EmailId;
                                                }

                                                objManagerInfo = GetUserDetails(objUserInfo.ManagerADId);

                                                if (objManagerInfo != null)
                                                {
                                                    cc = objManagerInfo.EmailId;
                                                }
                                                /* ISAT Business team told they dont want Supervisor's Supervisor escalations.*/
                                                //objSupervisorInfo = GetUserDetails(objManagerInfo.ManagerADId);

                                                //if (objSupervisorInfo != null)
                                                //{
                                                //    if (cc != "")
                                                //    {
                                                //        cc += ";" + objSupervisorInfo.EmailId;
                                                //    }
                                                //    else
                                                //    {
                                                //        cc = objSupervisorInfo.EmailId;
                                                //    }
                                                //}

                                                if (to == "")
                                                {
                                                    to = objManagerInfo.EmailId;
                                                }

                                                if (to != "")
                                                {
                                                    subject = drNotificationTemplate["Subject"].ToString();
                                                    body = String.Format(HttpUtility.HtmlDecode("<div style='float:left'>" + drNotificationTemplate["Body"].ToString() + "</div>"), objUserInfo.DisplayName, objUserInfo.DisplayName);
                                                    body = body.Replace("imgEmailHeader", string.Format("<img src={0} alt=''/>", GetEmailImage(siteURL, true)));
                                                    body = body.Replace("ISATLinkURL", string.Format("<a href={0}>here</a>", siteURL));
                                                    body = body.Replace("ISATLinkURL", string.Format("<a href={0}>here</a>", siteURL));
                                                    body = body.Replace("imgEmailFooter", string.Format("<img src={0} alt=''/>", GetEmailImage(siteURL, false)));
                                                    headers.Clear();
                                                    headers.Add("from", from);
                                                    headers.Add("to", to);
                                                    headers.Add("cc", cc);
                                                    headers.Add("subject", subject);
                                                    headers.Add("content-type", "text/html");

                                                    SPUtility.SendEmail(objSPWeb, headers, body);
                                                }
                                            }

                                            break;


                                        default:
                                            break;
                                    }

                                }
                                catch (Exception objException)
                                {
                                    LoggingService.LogError(LoggingService.DiagnosticCategoryJobs, objException.Message);
                                }                                
                            }
                        }

                    }
                }
            }
            catch (Exception objException)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryJobs, objException.Message);
            }
            finally
            {
                dtAllMailTemplates = null;
                objUserInfo = null;
                objManagerInfo = null;
                objSupervisorInfo = null;
            }
        }

        /// <summary>
        /// This method is used to get all the available mail templates.
        /// </summary>
        /// <returns>Returns datatable containing all the notification templates.</returns>
        private DataTable GetAllMailTemplates()
        {
            DataTable dtMailTemplates = null;

            try
            {
                using (dtMailTemplates = new DataTable())
                {
                    objSPWebISAT = webapp.Sites["solutions/LMS"].AllWebs["ISAT"] as SPWeb;
                    string listUrl = objSPWebISAT.ServerRelativeUrl + "/Lists/Notifications";
                    SPList list = objSPWebISAT.GetList(listUrl);
                    dtMailTemplates = list.GetItems(new string[] { "Title", "Subject", "Body", "Body_AR" }).GetDataTable();
                    dtMailTemplates.Columns[0].ColumnName = "NotificationType";
                    dtMailTemplates.Columns[1].ColumnName = "Subject";
                    dtMailTemplates.Columns[2].ColumnName = "Body";
                    dtMailTemplates.Columns[3].ColumnName = "Body_AR";
                }
            }
            catch (Exception objException)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryJobs, objException.Message);
            }

            return dtMailTemplates;
        }

        /// <summary>
        /// This method is used to get the user details from the User Profile Service.
        /// </summary>
        /// <param name="companyNumber">Company Number (AD id of the User whose details need to be retrived.)</param>
        /// <returns>Returns initialized object of the UserInfo containing details about the user.</returns>
        private UserInfo GetUserDetails(string companyNumber)
        {
            UserInfo objUserInfo = null;
            UserProfileManager objProfileManager = null;
            String emailId = String.Empty;

            try
            {                
                SPUser objSPUser = objSPWebISAT.EnsureUser(companyNumber);
                SPServiceContext serverContext = SPServiceContext.GetContext(objSPWebISAT.Site);
                objProfileManager = new UserProfileManager(serverContext);
                UserProfile profile = objProfileManager.GetUserProfile(companyNumber);

                if (objSPUser != null)
                {
                    objUserInfo = new UserInfo();                 
                    objUserInfo.DisplayName = objSPUser.Name;
                    objUserInfo.ManagerADId = (string)profile["manager"].Value;
                    objUserInfo.EmailId = objSPUser.Email;
                    emailId = Convert.ToString(objSPUser.Email);
                }

                if (String.IsNullOrEmpty(emailId))
                {
                    profile = objProfileManager.GetUserProfile(companyNumber);
                    string managerName = (string)profile["manager"].Value;
                    SPUser objSPUserManager = objSPWebISAT.EnsureUser(managerName);
                    objUserInfo.ManagerADId = objSPUserManager.LoginName;
                    objUserInfo.EmailId = objSPUserManager.Email;
                }
            }
            catch (Exception objException)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryJobs, objException.Message);
            }
            finally
            {
                objProfileManager = null;
            }

            return objUserInfo;
        }

        /// <summary>
        /// This method is used to get the managers email id.
        /// </summary>
        /// <param name="companyNumber">Company Number (AD Id of the user whose manager need to be returned.)</param>
        /// <returns>Returns Manager Email-Id of the passed company number (AD User Id).</returns>
        private string GetManagerEmailId(string companyNumber)
        {
            String emailId = String.Empty;
            SPUser objSPUser = null;
            UserProfile profile = null;
            UserProfileManager profileManager = null;

            try
            {
                objSPUser = objSPWebISAT.EnsureUser(companyNumber);
                SPServiceContext serverContext = SPServiceContext.GetContext(objSPWebISAT.Site);
                profileManager = new UserProfileManager(serverContext);
                profile = profileManager.GetUserProfile(companyNumber);
                string managerName = (string)profile["manager"].Value;
                SPUser objSPUserManager = objSPWebISAT.EnsureUser(managerName);
                emailId = objSPUserManager.Email;
            }
            catch (Exception objException)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryJobs, objException.Message);
            }
            finally
            {
                objSPUser = null;
                profile = null;
            }

            return emailId;
        }

        /// <summary>
        /// This method is used to get the list of all the employees whose certificate is due for expiry.
        /// </summary>
        /// <returns>Datatable containing the list of all the employees whose certificate is due for expiry.</returns>
        private DataTable GetEmpCertDueForExpiry()
        {
            DataTable dtEmployees = null;
            SPQuery query = null;

            try
            {
                using (dtEmployees = new DataTable())
                {
                    objSPWebISAT = webapp.Sites["solutions/LMS"].AllWebs["ISAT"] as SPWeb;
                    query = new SPQuery();
                    DateTime dtExpiryDate = DateTime.Now.AddDays(33);
                    query.Query = @"<Where>
                                <Leq>
                                    <FieldRef Name='ExpiryDate' />
                                    <Value IncludeTimeValue='FALSE' Type='DateTime'>" + dtExpiryDate.ToString("yyyy-MM-dd") + @"</Value>
                                </Leq>
                            </Where>";

                    query.QueryThrottleMode = SPQueryThrottleOption.Override;
                    query.ViewFields = @"<FieldRef Name='Title' /><FieldRef Name='StartDate1' /><FieldRef Name='ExpiryDate' />";
                    query.ViewFieldsOnly = true;
                    string listUrl = objSPWebISAT.ServerRelativeUrl + "/Lists/Employees";
                    SPList list = objSPWebISAT.GetList(listUrl);
                    dtEmployees = list.GetItems(query).GetDataTable();
                }
            }
            catch (Exception objException)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryJobs, objException.Message);
            }

            return dtEmployees;
        }

        /// <summary>
        /// This method is used to get the list of all the employees ISAT completion status.
        /// </summary>
        /// <param name="status">Status - Possible values P, C(P-Pending & C-Completed)  </param>
        /// <returns>DataTable containing the list of all employees based on the status passed.</returns>
        private DataTable GetEmpByCompletionStatus(string status)
        {
            DataTable dtEmployees = null;
            SPQuery query = null;

            try
            {
                using (dtEmployees = new DataTable())
                {
                    SPWeb web = webapp.Sites["solutions/LMS"].AllWebs["ISAT"] as SPWeb;
                    query = new SPQuery();
                    query.Query = @"<Where><Eq><FieldRef Name='Status' /><Value Type='Text'>" + status + @"</Value></Eq></Where>
                                <OrderBy>
                                  <FieldRef Name='Order' />
                                </OrderBy>";
                    query.QueryThrottleMode = SPQueryThrottleOption.Override;
                    query.ViewFields = @"<FieldRef Name='Title' /><FieldRef Name='StartDate1' /><FieldRef Name='ExpiryDate' />";
                    query.ViewFieldsOnly = true;
                    string listUrl = web.ServerRelativeUrl + "/Lists/Employees";
                    SPList list = web.GetList(listUrl);
                    dtEmployees = list.GetItems(query).GetDataTable();
                }
            }
            catch (Exception objException)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryJobs, objException.Message);
            }

            return dtEmployees;
        }

        /// <summary>
        /// This method is used to get the directorate name.
        /// </summary>
        /// <param name="groupNames">List of AD memberbership group that user belongs to.</param>
        /// <param name="objDirectorateList">List of Directorates.</param>
        /// <returns>Returns the Directorate name, if directorate name is not found then return Others.</returns>
        private string GetUserDirectorate(String groupNames, SPList objDirectorateList)
        {
            String directorate = String.Empty;

            try
            {
                directorate = (from SPListItem objSPListItem in objDirectorateList.Items
                               where groupNames.ContainsGroup(objSPListItem["ADGroupName"].ToString()) &&
                               bool.Parse(objSPListItem["IsActive"].ToString()) == true
                               select objSPListItem["Directorate"].ToString()).FirstOrDefault();

                if (String.IsNullOrEmpty(directorate))
                {
                    directorate = "Others";
                }
            }
            catch (Exception objException)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryJobs, objException.Message);
            }

            return directorate;
        }

        /// <summary>
        /// This method is used to check whether the data refresh for the directorates is set in the SharePoint configuration list.
        /// If it is set then it refresh the directorate data for all the employees in the Employees list.
        /// </summary>
        private void RefreshConfiguration()
        {
            objSPWebISAT = webapp.Sites["solutions/LMS"].AllWebs["ISAT"] as SPWeb;
            SPUsersEntity objSPUserEntity;
            string companyNo = string.Empty, directorate = String.Empty, userGroups = String.Empty;
            int flags;

            try
            {
                SPSecurity.RunWithElevatedPrivileges(delegate()
                {
                    using (SPSite objSPSite = new SPSite(objSPWebISAT.Site.Url))
                    {
                        objSPSite.AllowUnsafeUpdates = true;
                        using (SPWeb objSPWeb = objSPSite.AllWebs["ISAT"] as SPWeb)
                        {
                            objSPWeb.AllowUnsafeUpdates = true;

                            SPList objSPListConfiguration = objSPWeb.Lists["Configurations"];
                            SPList objSPListEmployees = objSPWeb.Lists["Employees"];
                            SPList objSPListDirectorates = objSPWeb.Lists["Directorates"];
                            SPListItemCollection objSPListItemColl = objSPWeb.Lists["Employees"].Items;
                            
                            foreach (SPListItem empItem in objSPListItemColl)
                            {
                                companyNo = empItem["CompanyNumber"].ToString();
                                userGroups = GetUserGroups(companyNo);
                                empItem["MemberOfGroups"] = userGroups;

                                objSPUserEntity = GetADUserAttributes(companyNo);

                                if (objSPUserEntity.IsActive != null)
                                {
                                    flags = int.Parse(objSPUserEntity.IsActive);
                                    if (!Convert.ToBoolean(flags & 0x0002))
                                    {
                                        //Active User
                                        empItem["IsActive"] = 1;
                                    }
                                    else
                                    {
                                        //InActive User
                                        empItem["IsActive"] = 0;
                                    }
                                }
                                else
                                {
                                    empItem["IsActive"] = 0;
                                }

                                directorate = GetUserDirectorate(empItem["MemberOfGroups"] != null ? empItem["MemberOfGroups"].ToString() : "Others", objSPListDirectorates);
                                empItem["Directorate"] = directorate;

                                companyNo = companyNo.ToLower();
                                if (companyNo.StartsWith("must")) empItem["AccountType"] = "Students";
                                else if (companyNo.StartsWith("muex")) empItem["AccountType"] = "External Users";
                                else if (companyNo.StartsWith("muc")) empItem["AccountType"] = "Contractors";
                                else if (companyNo.StartsWith("mu")) empItem["AccountType"] = "Employees";
                                else empItem["AccountType"] = "Others";                                
                                empItem.SystemUpdate();
                            }                                                         

                            objSPWeb.AllowUnsafeUpdates = false;
                        }
                        objSPSite.AllowUnsafeUpdates = false;
                    }
                });
            }
            catch (Exception objException)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryJobs, objException.Message);
            }
        }
    }
}
