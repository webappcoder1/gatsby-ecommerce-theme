﻿using Microsoft.Office.Server.UserProfiles;
using Microsoft.SharePoint;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PDO.Solutions.LMS.Jobs
{
    class UserProfileTypedManager : UserProfileManager, IEnumerable<ProfileBase>
    {
        public UserProfileTypedManager(SPServiceContext serviceContext)
            : base(serviceContext)
        {
        }

        public new IEnumerator<ProfileBase> GetEnumerator()
        {
            var e = base.GetEnumerator();
            while (e.MoveNext())
            {
                yield return e.Current as ProfileBase;
            }
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return base.GetEnumerator();
        }
    }


}
