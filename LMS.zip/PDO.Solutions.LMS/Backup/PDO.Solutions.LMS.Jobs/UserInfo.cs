﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PDO.Solutions.LMS.Jobs
{
    /// <summary>
    /// Entity to hold the User Information.
    /// </summary>
    public class UserInfo
    {
        public String CompanyNumber { get; set; }
        public String DisplayName { get; set; }
        public String UserADId { get; set; }
        public String ManagerADId { get; set; }
        public String Department { get; set; }
        public String EmailId { get; set; }  
    }
}
