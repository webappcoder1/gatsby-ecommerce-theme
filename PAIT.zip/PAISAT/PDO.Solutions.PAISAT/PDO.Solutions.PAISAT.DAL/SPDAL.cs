﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using Microsoft.SharePoint.Linq;
using Microsoft.SharePoint;
using PDO.Solutions.PAISAT.Utilities;

namespace PDO.Solutions.PAISAT.DAL
{
    public class SPDAL
    {
        /// <summary>
        /// This method is used to get the slides by Module Id and Language Code
        /// </summary>
        /// <param name="moduleId">Module Id</param>
        /// <param name="languageCode">Language Code</param>
        /// <returns>Datatable containing all the slides for the given module Id and language code.</returns>
        public DataTable GetSlidesByModuleId(int moduleId, string languageCode)
        {
            DataTable dtModuleSlides = null;
            SPQuery objSPQuery = null;

            try
            {
                SPSecurity.RunWithElevatedPrivileges(delegate()
                {
                    using (dtModuleSlides = new DataTable())
                    {
                        using (SPSite objSPSite = new SPSite(SPContext.Current.Web.Site.Url))
                        {
                            using (SPWeb objSPWeb = objSPSite.AllWebs[Constants.SITENAME])
                            {
                                objSPQuery = new SPQuery();
                                objSPQuery.Query = @"<Where>
                                                          <And>
                                                             <Eq>
                                                                <FieldRef Name='Module_x003a_ID' />
                                                                <Value Type='Lookup'>" + moduleId + @"</Value>
                                                             </Eq>
                                                             <Eq>
                                                                <FieldRef Name='IsActive1' />
                                                                <Value Type='Boolean'>1</Value>
                                                             </Eq>
                                                          </And>
                                                       </Where>
                                                    <OrderBy>
                                                       <FieldRef Name='Order1' Ascending='True' />
                                                    </OrderBy>";
                                objSPQuery.QueryThrottleMode = SPQueryThrottleOption.Override;

                                if (languageCode == "EN")
                                {
                                    objSPQuery.ViewFields = @"<FieldRef Name='Module' /><FieldRef Name='Title' /><FieldRef Name='Content1' />";
                                }
                                else
                                {
                                    objSPQuery.ViewFields = @"<FieldRef Name='Module_x003a_ModuleTitle_AR' /><FieldRef Name='SlideTitle_AR' /><FieldRef Name='Content_AR' />";
                                }

                                objSPQuery.ViewFieldsOnly = true;
                                string listUrl = objSPWeb.ServerRelativeUrl + "/Lists/Slides";
                                SPList list = objSPWeb.GetList(listUrl);
                                dtModuleSlides = list.GetItems(objSPQuery).GetDataTable();
                            }
                        }
                    }
                });
            }
            catch (Exception objException)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryDAL, objException.Message);
            }
            finally
            {
                objSPQuery = null;
            }

            return dtModuleSlides;
        }

        /// <summary>
        /// This mehtod is used to get all the modules based on the language code.
        /// </summary>
        /// <param name="languageCode">Language Code</param>
        /// <returns>DataTable containing all the details of the module based on the language code.</returns>
        public DataTable GetAllModules(string languageCode)
        {
            DataTable dtModule = null;
            SPQuery objSPQuery = null;

            try
            {
                SPSecurity.RunWithElevatedPrivileges(delegate()
                {
                    using (SPSite objSPSite = new SPSite(SPContext.Current.Web.Site.Url))
                    {
                        using (SPWeb objSPWeb = objSPSite.AllWebs[Constants.SITENAME])
                        {
                            using (dtModule = new DataTable())
                            {
                                objSPQuery = new SPQuery();
                                objSPQuery.QueryThrottleMode = SPQueryThrottleOption.Override;

                                objSPQuery.Query = @"<Where><Eq><FieldRef Name='IsActive1' /><Value Type='Boolean'>1</Value></Eq></Where>
                                <OrderBy>
                                  <FieldRef Name='Order1' />
                                </OrderBy>";

                                if (languageCode == "EN")
                                {
                                    objSPQuery.ViewFields = @"<FieldRef Name='ID' /><FieldRef Name='Title' />";
                                }
                                else
                                {
                                    objSPQuery.ViewFields = @"<FieldRef Name='ID' /><FieldRef Name='ModuleTitle_AR' />";
                                }

                                objSPQuery.ViewFieldsOnly = true;
                                string listUrl = objSPWeb.ServerRelativeUrl + "/Lists/Modules";
                                SPList list = objSPWeb.GetList(listUrl);
                                dtModule = list.GetItems(objSPQuery).GetDataTable();
                                if (languageCode == "AR")
                                {
                                    dtModule.Columns["ModuleTitle_AR"].ColumnName = "Title";
                                }
                            }
                        }
                    }
                });
            }
            catch (Exception objException)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryDAL, objException.Message);
            }
            finally
            {
                objSPQuery = null;
            }

            return dtModule;
        }

        /// <summary>
        /// This method is used to get the current module of the user.
        /// </summary>
        /// <param name="userAdId">User Id</param>
        /// <returns>Returns the module Id</returns>
        public int GetUserCurrentModule(string userAdId)
        {
            int currentModuleId = 0;
            SPListItem objSPListItemEmployee = null;
            SPQuery objSPQuery = null;

            try
            {
                SPSecurity.RunWithElevatedPrivileges(delegate
                {
                    using (SPSite objSPSite = new SPSite(SPContext.Current.Web.Site.Url))
                    {
                        using (SPWeb objSPWeb = objSPSite.AllWebs[Constants.SITENAME])
                        {
                            objSPQuery = new SPQuery();
                            objSPQuery.QueryThrottleMode = SPQueryThrottleOption.Override;
                            objSPQuery.Query = @"<Where>
                                  <And>
                                     <Eq>
                                        <FieldRef Name='Title' />
                                        <Value Type='Text'>" + userAdId + @"</Value>
                                     </Eq>
                                     <Eq>
                                        <FieldRef Name='IsActive' />
                                        <Value Type='Boolean'>1</Value>
                                     </Eq>
                                  </And>
                               </Where>";
                            objSPQuery.ViewFields = "<FieldRef Name='Title' /><FieldRef Name='EmployeeName' /><FieldRef Name='CurrentModuleId' />";
                            objSPQuery.ViewFieldsOnly = true;
                            string listUrl = objSPWeb.ServerRelativeUrl + "/Lists/Employees";
                            SPList list = objSPWeb.GetList(listUrl);
                            objSPListItemEmployee = list.GetItems(objSPQuery)[0];
                            if (objSPListItemEmployee != null && objSPListItemEmployee["CurrentModuleId"] != null)
                            {
                                int.TryParse(objSPListItemEmployee["CurrentModuleId"].ToString(), out currentModuleId);
                            }
                        }
                    }
                });
            }
            catch (Exception objException)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryDAL, objException.Message);
            }
            finally
            {
                objSPQuery = null;
            }

            return currentModuleId;
        }

        /// <summary>
        /// This method is used to get the banner image url for the passed module id and language code.
        /// </summary>
        /// <param name="currentModuleId">Module Id</param>
        /// <param name="language">Language Code</param>
        /// <returns>Returns URL path for the module banner image URL.</returns>
        public string GetModuleBannerImageUrlById(int currentModuleId, string language)
        {
            SPListItem objSPListItem = null;
            String moduleBannerUrl = string.Empty;

            try
            {
                SPSecurity.RunWithElevatedPrivileges(delegate()
                {
                    using (SPSite objSPSite = new SPSite(SPContext.Current.Web.Site.Url))
                    {
                        using (SPWeb objSPWeb = objSPSite.AllWebs[Constants.SITENAME])
                        {
                            objSPListItem = (from SPListItem module in objSPWeb.Lists["Modules"].Items
                                             where module["ID"].ToString() == currentModuleId.ToString()
                                             select module).FirstOrDefault();
                            if (objSPListItem != null)
                            {
                                SPFieldUrlValue objSPFieldUrlValue = null;
                                if (language == "EN")
                                    objSPFieldUrlValue = new SPFieldUrlValue(objSPListItem["BannerImageUrl"].ToString());
                                else
                                    objSPFieldUrlValue = new SPFieldUrlValue(objSPListItem["BannerImageUrl_AR"].ToString());

                                moduleBannerUrl = objSPFieldUrlValue.Url;
                            }
                        }
                    }
                });
            }
            catch (Exception objException)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryDAL, objException.Message);
            }

            return moduleBannerUrl;
        }

        /// <summary>
        /// This method is used to get the module details by module Id.
        /// </summary>
        /// <param name="currentModuleId">Module Id</param>
        /// <returns>List Item containing details of the passed module Id.</returns>
        public SPListItem GetModuleDetailsByModuleId(int currentModuleId)
        {
            SPListItem objSPListItem = null;

            try
            {
                SPSecurity.RunWithElevatedPrivileges(delegate()
                {
                    using (SPSite objSPSite = new SPSite(SPContext.Current.Web.Site.Url))
                    {
                        using (SPWeb objSPWeb = objSPSite.AllWebs[Constants.SITENAME])
                        {
                            string moduleBannerUrl = string.Empty;

                            objSPListItem = (from SPListItem module in objSPWeb.Lists["Modules"].Items
                                             where module["ID"].ToString() == currentModuleId.ToString()
                                             select module).FirstOrDefault();
                        }
                    }
                });
            }
            catch (Exception objException)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryDAL, objException.Message);
            }

            return objSPListItem;
        }

        /// <summary>
        /// This method is used to get the question details for the passed Module Id and Language Code.
        /// </summary>
        /// <param name="currentModuleId">Module Id.</param>
        /// <param name="questionIds">Questiond Ids that need to be skipped.</param>
        /// <param name="languageCode">Language Code.</param>
        /// <returns>DataSet containing details of the passed in Module Id and Language Code.</returns>
        public DataSet GetQuestionDetailsByModuleId(int currentModuleId, string questionIds, string languageCode)
        {
            DataSet dsQuestionDetails = new DataSet();
            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
                using (SPSite objSPSite = new SPSite(SPContext.Current.Web.Site.Url))
                {
                    using (SPWeb objSPWeb = objSPSite.AllWebs[Constants.SITENAME])
                    {  
                        SPQuery questionQuery = new SPQuery();
                        SPQuery answersQuery = new SPQuery();
                        SPList spQuestionsList = objSPWeb.Lists.TryGetList("Questions");

                        if (spQuestionsList != null)
                        {
                            if (languageCode == "EN")
                            {
                                questionQuery.ViewFields = "<FieldRef Name='Module' /><FieldRef Name='QuestionTitle' /><FieldRef Name='ID' />";
                            }
                            else
                            {
                                questionQuery.ViewFields = "<FieldRef Name='Module' /><FieldRef Name='QuestionTitle_AR' /><FieldRef Name='ID' />";
                            }

                            questionQuery.Query = "<Where><And><Eq><FieldRef Name='Module_x003a_ID' /><Value Type='Lookup'>" + currentModuleId + "</Value></Eq><Eq><FieldRef Name='IsActive1' /><Value Type='Boolean'>1</Value></Eq></And></Where>";

                            DataTable dtQuestion = spQuestionsList.GetItems(questionQuery).GetDataTable();


                            if (dtQuestion != null)
                            {
                                if (languageCode == "AR")
                                {
                                    dtQuestion.Columns["QuestionTitle_AR"].ColumnName = "QuestionTitle";
                                }

                                DataTable dtUserQuestion = dtQuestion.Clone();
                                Random objRandom = new Random();
                                DataRow drUserQuestion = null;
                                int questionNo = 0;

                                while (questionNo == 0)
                                {
                                    questionNo = objRandom.Next(1, dtQuestion.Rows.Count + 1);
                                    drUserQuestion = dtQuestion.Rows[questionNo - 1];
                                    if (questionIds.Contains(drUserQuestion["ID"].ToString() + ";") == true)
                                    {
                                        questionNo = 0;
                                    }
                                }

                                int questionId = int.Parse(drUserQuestion["ID"].ToString());
                                dtUserQuestion.ImportRow(drUserQuestion);
                                dsQuestionDetails.Tables.Add(dtUserQuestion);
                                SPList spAnswersList = objSPWeb.Lists.TryGetList("Answers");

                                if (spAnswersList != null)
                                {
                                    if (languageCode == "EN")
                                    {
                                        answersQuery.ViewFields = "<FieldRef Name='ID'/><FieldRef Name='Title'/><FieldRef Name='Description' /><FieldRef Name='IsCorrect' />";
                                    }
                                    else
                                    {
                                        answersQuery.ViewFields = "<FieldRef Name='ID'/><FieldRef Name='Title_AR'/><FieldRef Name='Description_AR'/><FieldRef Name='IsCorrect'/>";
                                    }

                                    answersQuery.Query = "<Where><Eq><FieldRef Name='Question_x003a_ID' /><Value Type='Lookup'>" + questionId + "</Value></Eq></Where>";

                                    DataTable dtAnswers = spAnswersList.GetItems(answersQuery).GetDataTable();
                                    if (dtAnswers != null)
                                    {
                                        if (languageCode == "AR")
                                        {
                                            dtAnswers.Columns["Title_AR"].ColumnName = "Title";
                                            dtAnswers.Columns["Description_AR"].ColumnName = "Description";
                                        }

                                        dsQuestionDetails.Tables.Add(dtAnswers);
                                    }
                                }
                            }
                        }
                    }
                }
                
            });

            return dsQuestionDetails;
        }

        /// <summary>
        /// This method is used to get all the Slides for the passed Module Id and language code.
        /// </summary>
        /// <param name="currentModuleId">Current Module Id</param>
        /// <param name="languageCode">Language Code</param>
        /// <returns>DataTable containing all the slides for the passed Module Id.</returns>
        public DataTable GetAllSlidesByModuelId(int currentModuleId, string languageCode)
        {
            DataTable dtModuleSlides = null;
            SPQuery objSPQuery = null;

            try
            {
                SPSecurity.RunWithElevatedPrivileges(delegate()
               {
                   using (dtModuleSlides = new DataTable())
                   {
                       using (SPSite objSPSite = new SPSite(SPContext.Current.Web.Site.Url))
                       {
                           using (SPWeb objSPWeb = objSPSite.AllWebs[Constants.SITENAME])
                           {
                               objSPQuery = new SPQuery();

                               objSPQuery.Query = @"<Where>
                                                      <And>
                                                         <Eq>
                                                            <FieldRef Name='Module_x003a_ID' />
                                                            <Value Type='Lookup'>" + currentModuleId + @"</Value>
                                                         </Eq>
                                                         <And>                       
                                                         <Eq>
                                                            <FieldRef Name='IsActive1' />
                                                            <Value Type='Boolean'>1</Value>
                                                         </Eq>
                                                        <Eq>
                                                                       <FieldRef Name='WFStatus' />
                                                                       <Value Type='Text'>APP</Value>
                                                                    </Eq>
                                                      </And>
                                                    </And>
                                                    </Where>
                                                    <OrderBy>
                                                        <FieldRef Name='Order1' Ascending='True' />
                                                    </OrderBy>";

                               if (languageCode == "EN")
                               {
                                   objSPQuery.ViewFields = @"<FieldRef Name='Module' /><FieldRef Name='Title' /><FieldRef Name='Content1' /><FieldRef Name='Module_x003a_RelModuleColumn' />";
                               }
                               else
                               {
                                   objSPQuery.ViewFields = @"<FieldRef Name='Module_x003a_ModuleTitle_AR' /><FieldRef Name='SlideTitle_AR' /><FieldRef Name='Content_AR' /><FieldRef Name='Module_x003a_RelModuleColumn' />";
                               }

                               objSPQuery.ViewFieldsOnly = true;
                               string listUrl = objSPWeb.ServerRelativeUrl + "/Lists/Slides";
                               SPList list = objSPWeb.GetList(listUrl);
                               dtModuleSlides = list.GetItems(objSPQuery).GetDataTable();
                               if (dtModuleSlides != null && dtModuleSlides.Rows.Count > 0)
                               {
                                   if (languageCode == "EN")
                                   {
                                       dtModuleSlides.Columns["Content1"].ColumnName = "Content";
                                   }
                                   else
                                   {
                                       dtModuleSlides.Columns["SlideTitle_AR"].ColumnName = "Title";
                                       dtModuleSlides.Columns["Content_AR"].ColumnName = "Content";
                                   }
                               }
                           }
                       }
                   }
               });
            }
            catch (Exception objException)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryDAL, objException.Message);
            }
            finally
            {
                objSPQuery = null;
            }

            return dtModuleSlides;
        }

        /// <summary>
        /// This method is used to get the message template by title.
        /// </summary>
        /// <param name="templateTitle">Template Title</param>
        /// <param name="languageCode">Language Code</param>
        /// <returns>Get the description for the passed message template title.</returns>
        public string GetMessageTemplateByTitle(string templateTitle, string languageCode)
        {
            SPListItem objSPListItem = null;
            String templateText = String.Empty;

            try
            {
                SPSecurity.RunWithElevatedPrivileges(delegate()
                {
                    using (SPSite objSPSite = new SPSite(SPContext.Current.Web.Site.Url))
                    {
                        using (SPWeb objSPWeb = objSPSite.AllWebs[Constants.SITENAME])
                        {
                            objSPListItem = (from SPListItem alertTemplateItem in objSPWeb.Lists["AlertTemplates"].Items
                                             where alertTemplateItem["Title"].ToString() == templateTitle
                                             select alertTemplateItem).FirstOrDefault();

                            if (objSPListItem != null)
                            {
                                if (languageCode == "EN")
                                    templateText = objSPListItem["Description"].ToString();
                                else
                                    templateText = objSPListItem["Description_AR"].ToString();
                            }
                        }
                    }
                });
            }
            catch (Exception objException)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryDAL, objException.Message);
            }

            return templateText;
        }

        /// <summary>
        /// This method is used to get the next learning module based on the current module id.
        /// </summary>
        /// <param name="currentModuleId">Current Module Id.</param>
        /// <returns>Returns the next learning module Id.</returns>
        public int GetNextLearningModule(int currentModuleId)
        {
            SPListItem objSPListItemCurrentModule = null;
            int nextLearningModuleId = 0;

            try
            {
                SPSecurity.RunWithElevatedPrivileges(delegate()
                {
                   using (SPSite objSPSite = new SPSite(SPContext.Current.Web.Site.Url))
                   {
                       using (SPWeb objSPWeb = objSPSite.AllWebs[Constants.SITENAME])
                       {
                           objSPListItemCurrentModule = (from SPListItem module in objSPWeb.Lists["Modules"].Items
                                                         where module["ID"].ToString() == currentModuleId.ToString()
                                                         select module).FirstOrDefault();

                           if (objSPListItemCurrentModule != null)
                           {
                               /*SPListItem objSPListItemNextModule = (from SPListItem module in objSPWeb.Lists["Modules"].Items
                                                                     where int.Parse(module["Order"].ToString()) > int.Parse(objSPListItemCurrentModule["Order"].ToString())
                                                                     select module).FirstOrDefault();*/

                               SPListItem objSPListItemNextModule = (from SPListItem module in objSPWeb.Lists["Modules"].Items
                                                                     where int.Parse(module["Order1"].ToString()) == int.Parse(objSPListItemCurrentModule["Order1"].ToString())+1
                                                                     select module).FirstOrDefault();


                               if (objSPListItemNextModule != null)
                               {
                                   nextLearningModuleId = int.Parse(objSPListItemNextModule["ID"].ToString());
                               }
                           }
                       }
                   }
               });
            }
            catch (Exception objException)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryDAL, objException.Message);
            }

            return nextLearningModuleId;
        }

        /// <summary>
        /// This method is used to set the users current module.
        /// </summary>
        /// <param name="userId">User Id</param>
        /// <param name="moduleId">Module Id</param>
        public void SetUsersCurrentModule(string userId, int moduleId)
        {
            SPListItem objSPListItemEmployee = null;
            SPQuery objSPQuery = null;

            try
            {
                SPSecurity.RunWithElevatedPrivileges(delegate()
                {
                    using (SPSite objSPSite = new SPSite(SPContext.Current.Web.Site.Url))
                    {
                        using (SPWeb objSPWeb = objSPSite.AllWebs[Constants.SITENAME])
                        {
                            objSPWeb.AllowUnsafeUpdates = true;
                            objSPQuery = new SPQuery();
                            objSPQuery.QueryThrottleMode = SPQueryThrottleOption.Override;

                            objSPQuery.Query = @"<Where>
                              <And>
                                 <Eq>
                                    <FieldRef Name='Title' />
                                    <Value Type='Text'>" + userId + @"</Value>
                                 </Eq>
                                 <Eq>
                                    <FieldRef Name='IsActive' />
                                    <Value Type='Boolean'>1</Value>
                                 </Eq>
                              </And>
                           </Where>";

                            objSPQuery.ViewFieldsOnly = true;
                            string listUrl = objSPWeb.ServerRelativeUrl + "/Lists/Employees";
                            SPList list = objSPWeb.GetList(listUrl);
                            objSPListItemEmployee = list.GetItems(objSPQuery)[0];
                            objSPListItemEmployee["CurrentModuleId"] = moduleId;
                            objSPListItemEmployee.SystemUpdate(false);
                            objSPWeb.AllowUnsafeUpdates = false;
                        }
                    }
                });
            }
            catch (Exception objException)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryDAL, objException.Message);
            }
        }

        /// <summary>
        /// This method is used to check whether the user has completeed the module assessment.
        /// </summary>
        /// <param name="userId">User Id</param>
        /// <param name="moduleName">Module Name</param>
        /// <returns>Returns true if the user has completed the module assesment else returns false.</returns>
        public bool IsUserCompletedModuleAssesment(string userId, string moduleName)
        {
            bool isCompleted = false;
            SPQuery objSPQuery = null;

            try
            {
                SPSecurity.RunWithElevatedPrivileges(delegate()
                {
                    using (SPSite objSPSite = new SPSite(SPContext.Current.Web.Site.Url))
                    {
                        using (SPWeb objSPWeb = objSPSite.AllWebs[Constants.SITENAME])
                        {
                            objSPQuery = new SPQuery();
                            objSPQuery.QueryThrottleMode = SPQueryThrottleOption.Override;
                            objSPQuery.Query = @"<Where>
                                  <And>
                                     <Eq>
                                        <FieldRef Name='Title' />
                                        <Value Type='Text'>" + userId + @"</Value>
                                     </Eq>
                                     <And>
                                        <Eq>
                                           <FieldRef Name='IsActive' />
                                           <Value Type='Boolean'>1</Value>
                                        </Eq>
                                        <Eq>
                                           <FieldRef Name='" + moduleName + @"' />
                                           <Value Type='Text'>C</Value>
                                        </Eq>
                                     </And>
                                  </And>
                           </Where>";
                            objSPQuery.ViewFields = @"<FieldRef Name='CompanyNumber' />";
                            objSPQuery.ViewFieldsOnly = true;
                            string listUrl = objSPWeb.ServerRelativeUrl + "/Lists/Employees";
                            SPList list = objSPWeb.GetList(listUrl);
                            SPListItemCollection objSPListItemCollection = list.GetItems(objSPQuery);
                            if (objSPListItemCollection != null && objSPListItemCollection.Count > 0)
                            {
                                isCompleted = true;
                            }
                        }
                    }
                });
            }
            catch (Exception objException)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryDAL, objException.Message);
            }

            return isCompleted;
        }

        /// <summary>
        /// This method is used to check whether the user has completed the assesment.
        /// </summary>
        /// <param name="userId">User Id</param>
        /// <returns>Returns true if the user has completed the assesment, else returns false.</returns>
        public bool IsUserCompletedAssesment(string userId)
        {
            bool isCompleted = false;
            SPQuery objSPQuery = null;

            try
            {
                SPSecurity.RunWithElevatedPrivileges(delegate()
                {
                   using (SPSite objSPSite = new SPSite(SPContext.Current.Web.Site.Url))
                    {
                        using (SPWeb objSPWeb = objSPSite.AllWebs[Constants.SITENAME])
                        {
                            objSPQuery = new SPQuery();
                            objSPQuery.QueryThrottleMode = SPQueryThrottleOption.Override;

                            objSPQuery.Query = @"<Where>
                                          <And>
                                             <Eq>
                                                <FieldRef Name='Title' />
                                                <Value Type='Text'>" + userId + @"</Value>
                                             </Eq>
                                              <Eq>                                      
                                                   <FieldRef Name='IsActive' />
                                                   <Value Type='Boolean'>1</Value>
                                             </Eq>                                       
                                          </And>
                                   </Where>";
                            objSPQuery.ViewFields = @"<FieldRef Name='Status' />";
                            objSPQuery.ViewFieldsOnly = true;
                            string listUrl = objSPWeb.ServerRelativeUrl + "/Lists/Employees";
                            SPList list = objSPWeb.GetList(listUrl);
                            SPListItemCollection objSPListItemCollection = list.GetItems(objSPQuery);
                            if (objSPListItemCollection != null && objSPListItemCollection.Count > 0)
                            {
                                SPListItem objSPListItem = objSPListItemCollection[0];
                                if (objSPListItem["Status"].ToString() == "C")
                                    isCompleted = true;
                            }                       
                        }
                    }
                });
            }
            catch (Exception objException)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryDAL, objException.Message);
            }
            finally
            {
                objSPQuery = null;
            }

            return isCompleted;
        }

        /// <summary>
        /// This method is used to update the User Module assesment.
        /// </summary>
        /// <param name="userId">User Id.</param>
        /// <param name="moduleName">Module Name</param>
        /// <returns>Retuns true if the update is successful else returns false.</returns>
        public bool UpdateUserModuleAssesment(string userId, string moduleName, string language)
        {
            bool isUpdated = false;
            SPQuery objSPQuery = null;

            try
            {
                SPSecurity.RunWithElevatedPrivileges(delegate()
                {
                    using (SPSite objSPSite = new SPSite(SPContext.Current.Web.Site.Url))
                    {
                        using (SPWeb objSPWeb = objSPSite.AllWebs[Constants.SITENAME])
                        {
                            objSPWeb.AllowUnsafeUpdates = true;
                            SPListItem objSPListItemEmployee = null;
                            objSPWeb.AllowUnsafeUpdates = true;
                            objSPQuery = new SPQuery();
                            objSPQuery.QueryThrottleMode = SPQueryThrottleOption.Override;

                            objSPQuery.Query = @"<Where>
                              <And>
                                 <Eq>
                                    <FieldRef Name='Title' />
                                    <Value Type='Text'>" + userId + @"</Value>
                                 </Eq>
                                 <Eq>
                                    <FieldRef Name='IsActive' />
                                    <Value Type='Boolean'>1</Value>
                                 </Eq>
                              </And>
                           </Where>";
                            objSPQuery.ViewFieldsOnly = true;
                            string listUrl = objSPWeb.ServerRelativeUrl + "/Lists/Employees";
                            SPList list = objSPWeb.GetList(listUrl);
                            objSPListItemEmployee = list.GetItems(objSPQuery)[0];
                            objSPListItemEmployee[moduleName] = "C";
                            objSPListItemEmployee["Language"] = language;
                            objSPListItemEmployee.SystemUpdate(false);
                            objSPWeb.AllowUnsafeUpdates = false;
                        }
                    }
                });
            }
            catch (Exception objException)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryDAL, objException.Message);
            }
            finally
            {
                objSPQuery = null;
            }

            return isUpdated;
        }

        /// <summary>
        /// This method is used to update the User attempts.
        /// </summary>
        /// <param name="userId">User Id.</param>
        public void UpdateUserAttempts(string userId)
        {
            SPListItem objSPListItemEmployee = null;
            SPQuery objSPQuery = null;

            try
            {
                SPSecurity.RunWithElevatedPrivileges(delegate()
                {
                    using (SPSite objSPSite = new SPSite(SPContext.Current.Web.Site.Url))
                    {
                        using (SPWeb objSPWeb = objSPSite.AllWebs[Constants.SITENAME])
                        {
                            objSPWeb.AllowUnsafeUpdates = true;
                            objSPQuery = new SPQuery();
                            objSPQuery.QueryThrottleMode = SPQueryThrottleOption.Override;

                            objSPQuery.Query = @"<Where>
                              <And>
                                 <Eq>
                                    <FieldRef Name='Title' />
                                    <Value Type='Text'>" + userId + @"</Value>
                                 </Eq>
                                 <Eq>
                                    <FieldRef Name='IsActive' />
                                    <Value Type='Boolean'>1</Value>
                                 </Eq>
                              </And>
                           </Where>";
                            objSPQuery.ViewFieldsOnly = true;
                            string listUrl = objSPWeb.ServerRelativeUrl + "/Lists/Employees";
                            SPList list = objSPWeb.GetList(listUrl);
                            int totalAttempts = 0;
                            objSPListItemEmployee = list.GetItems(objSPQuery)[0];
                            if (objSPListItemEmployee["NoOfAttempts"] != null)
                            {
                                int.TryParse(objSPListItemEmployee["NoOfAttempts"].ToString(), out totalAttempts);
                            }
                            objSPListItemEmployee["NoOfAttempts"] = totalAttempts + 1;
                            objSPListItemEmployee.SystemUpdate(false);
                            objSPWeb.AllowUnsafeUpdates = false;
                        }

                    }
                });
            }
            catch (Exception objException)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryDAL, objException.Message);
            }
            finally
            {
                objSPQuery = null;
            }
        }

        /// <summary>
        /// This method is used to mark the user's assesment as completed.
        /// </summary>
        /// <param name="userId">User Id</param>
        /// <returns>Returns true if the assesment details updated successfully else returns false.</returns>
        public bool UpdateUserAssesmentCompleted(string userId)
        {
            bool isUpdated = false;
            SPQuery objSPQuery = null;

            try
            {
                SPSecurity.RunWithElevatedPrivileges(delegate()
                {
                    using (SPSite objSPSite = new SPSite(SPContext.Current.Web.Site.Url))
                    {
                        using (SPWeb objSPWeb = objSPSite.AllWebs[Constants.SITENAME])
                        {
                            objSPWeb.AllowUnsafeUpdates = true;
                            SPListItem objSPListItemEmployee = null;
                            objSPQuery = new SPQuery();
                            objSPQuery.QueryThrottleMode = SPQueryThrottleOption.Override;

                            objSPQuery.Query = @"<Where>
                              <And>
                                 <Eq>
                                    <FieldRef Name='Title' />
                                    <Value Type='Text'>" + userId + @"</Value>
                                 </Eq>
                                 <Eq>
                                    <FieldRef Name='IsActive' />
                                    <Value Type='Boolean'>1</Value>
                                 </Eq>
                              </And>
                           </Where>";
                            objSPQuery.ViewFieldsOnly = true;
                            string listUrl = objSPWeb.ServerRelativeUrl + "/Lists/Employees";
                            SPList list = objSPWeb.GetList(listUrl);
                            objSPListItemEmployee = list.GetItems(objSPQuery)[0];
                            objSPListItemEmployee["Status"] = "C";
                            objSPListItemEmployee["CompletionDate"] = DateTime.Now;
                            objSPListItemEmployee["ExpiryDate"] = DateTime.Now.AddYears(3);
                            objSPListItemEmployee.SystemUpdate(false);
                            objSPWeb.AllowUnsafeUpdates = false;
                        }
                    }

                });
            }
            catch (Exception objException)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryDAL, objException.Message);
            }
            finally
            {
                objSPQuery = null;
            }

            return isUpdated;
        }

        /// <summary>
        /// This method is used to get the User details by User Id.
        /// </summary>
        /// <param name="userId">User Id</param>
        /// <returns>Returns the list item id containing details of the employee.</returns>
        public SPListItem GetUserDetailsByUserId(string userId)
        {
            SPListItem objSPListItemEmployee = null;
            SPQuery objSPQuery = null;

            try
            {
                SPSecurity.RunWithElevatedPrivileges(delegate()
                {
                    using (SPSite objSPSite = new SPSite(SPContext.Current.Web.Site.Url))
                    {
                        using (SPWeb objSPWeb = objSPSite.AllWebs[Constants.SITENAME])
                        {
                            SPWeb web = SPContext.Current.Web;
                            objSPQuery = new SPQuery();
                            objSPQuery.QueryThrottleMode = SPQueryThrottleOption.Override;

                            objSPQuery.Query = @"<Where>
                                      <And>
                                         <Eq>
                                            <FieldRef Name='Title' />
                                            <Value Type='Text'>" + userId + @"</Value>
                                         </Eq>
                                         <Eq>
                                            <FieldRef Name='IsActive' />
                                            <Value Type='Boolean'>1</Value>
                                         </Eq>
                                      </And>
                                   </Where>";
                            objSPQuery.ViewFieldsOnly = true;
                            string listUrl = web.ServerRelativeUrl + "/Lists/Employees";
                            SPList list = web.GetList(listUrl);
                            objSPListItemEmployee = list.GetItems(objSPQuery)[0];
                        }
                    }
                });
            }
            catch (Exception objException)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryDAL, objException.Message);
            }
            finally
            {
                objSPQuery = null;
            }

            return objSPListItemEmployee;
        }

        /// <summary>
        /// This method is used to copy the assessment details to the history list.
        /// </summary>
        /// <param name="userId">User Id.</param>
        public void CopyToHistoryList(string userId)
        {
            try
            {
                SPListItem objSPListItem = GetUserDetailsByUserId(userId);
                SPSecurity.RunWithElevatedPrivileges(delegate()
                {
                    using (SPSite objSPSite = new SPSite(SPContext.Current.Web.Site.Url))
                    {
                        using (SPWeb objSPWeb = objSPSite.AllWebs[Constants.SITENAME])
                        {
                            objSPWeb.AllowUnsafeUpdates = true;
                            SPList objSPListEmployeesAssmtHistory = objSPWeb.Lists["EmployeesAssessmentHistory"];
                            SPListItem newEmployeesAssmtHistoryItem = objSPListEmployeesAssmtHistory.AddItem();
                            newEmployeesAssmtHistoryItem["CompanyNumber"] = objSPListItem["CompanyNumber"];
                            newEmployeesAssmtHistoryItem["EmployeeName"] = objSPListItem["EmployeeName"];
                            newEmployeesAssmtHistoryItem["StartDate"] = objSPListItem["StartDate"];
                            newEmployeesAssmtHistoryItem["CompletionDate"] = objSPListItem["CompletionDate"];
                            newEmployeesAssmtHistoryItem["Status"] = objSPListItem["Status"];
                            newEmployeesAssmtHistoryItem["ExpiryDate"] = objSPListItem["ExpiryDate"];
                            newEmployeesAssmtHistoryItem["Excluded"] = objSPListItem["Excluded"];
                            newEmployeesAssmtHistoryItem["DescriptionForExclusion"] = objSPListItem["DescriptionForExclusion"];
                            newEmployeesAssmtHistoryItem.Update();
                            ResetEmployeeAssessment(userId);
                            objSPWeb.AllowUnsafeUpdates = false;
                        }
                    }
                });
            }
            catch (Exception objException)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryDAL, objException.Message);
            }
        }

        /// <summary>
        /// This method is used to reset employee assesment.
        /// </summary>
        /// <param name="userId">User Id.</param>
        private void ResetEmployeeAssessment(string userId)
        {
            SPListItem objSPListItemEmployee = null;
            SPQuery objSPQuery = null;

            try
            {
                SPSecurity.RunWithElevatedPrivileges(delegate()
                {
                    using (SPSite objSPSite = new SPSite(SPContext.Current.Web.Site.Url))
                    {
                        using (SPWeb objSPWeb = objSPSite.AllWebs[Constants.SITENAME])
                        {
                            objSPWeb.AllowUnsafeUpdates = true;
                            objSPQuery = new SPQuery();
                            objSPQuery.QueryThrottleMode = SPQueryThrottleOption.Override;
                            objSPQuery.Query = @"<Where>
                                  <And>
                                     <Eq>
                                        <FieldRef Name='Title' />
                                        <Value Type='Text'>" + userId + @"</Value>
                                     </Eq>
                                     <Eq>
                                        <FieldRef Name='IsActive' />
                                        <Value Type='Boolean'>1</Value>
                                     </Eq>
                                  </And>
                               </Where>";
                            objSPQuery.ViewFieldsOnly = true;
                            string listUrl = objSPWeb.ServerRelativeUrl + "/Lists/Employees";
                            SPList list = objSPWeb.GetList(listUrl);
                            objSPListItemEmployee = list.GetItems(objSPQuery)[0];
                            objSPListItemEmployee["StartDate"] = DateTime.Now;
                            objSPListItemEmployee["CompletionDate"] = null;
                            objSPListItemEmployee["CurrentModuleId"] = 10;
                            objSPListItemEmployee["Status"] = "P";
                            objSPListItemEmployee["NoOfAttempts"] = 0;
                            foreach (SPListItem objModuleItem in objSPWeb.Lists["Modules"].Items)
                            {
                                if (list.Fields.ContainsField(objModuleItem["RelModuleColumn"].ToString()))
                                {
                                    objSPListItemEmployee[objModuleItem["RelModuleColumn"].ToString()] = "";
                                }
                            }
                            objSPListItemEmployee.Update();
                        }
                    }
                });
            }
            catch (Exception objException)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryDAL, objException.Message);
            }
        }
    }
}
