﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PDO.Solutions.PAISAT.Utilities
{
    public static class Constants
    {
        public const string SITENAME = "PAISAT";
        public const string TIMER_JOB_NAME = "PA-ISAT Timer Job";
        public const string TIMER_JOB_DISPLAY_NAME = "PA-ISAT Timer Job";
        public const string DOMAIN = "CORP";
        public const string PAISAT_AD_GROUPNAME = "PDO-All-PrivilegeAccountOwners-GS";
        public const string MD_AD_GROUPNAME = "PDO-MD-Members-GS";
    }
}
