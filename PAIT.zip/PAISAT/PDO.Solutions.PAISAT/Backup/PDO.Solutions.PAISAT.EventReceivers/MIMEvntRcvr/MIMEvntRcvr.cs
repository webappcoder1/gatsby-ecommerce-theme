﻿using System;
using System.Security.Permissions;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using Microsoft.SharePoint.Workflow;
using System.Data.OracleClient;
using System.Configuration;
using PDO.Solutions.PAISAT.Utilities;

namespace PDO.Solutions.PAISAT.EventReceivers.MIMEvntRcvr
{
    /// <summary>
    /// List Item Events
    /// </summary>
    public class MIMEvntRcvr : SPItemEventReceiver
    {
        /// <summary>
        /// An item was added.
        /// </summary>
        public override void ItemAdded(SPItemEventProperties properties)
        {
            try
            {
                base.ItemAdded(properties);
                if (properties != null && properties.WebUrl.ToUpper().Contains("/PAISAT"))
                {
                    if (properties.List.Title == "Employees")
                    {
                        SPListItem objSPListItem = properties.ListItem;
                        //DateTime dueDate = new DateTime();

                        //if (objSPListItem["ExpiryDate"] == null)
                        //{
                        //    dueDate = DateTime.Parse(objSPListItem["CompletionDueDate"].ToString());
                        //}
                        //else
                        //{
                        //    dueDate = DateTime.Parse(objSPListItem["ExpiryDate"].ToString());
                        //}

                        //InsertDataToIDM(objSPListItem["CompanyNumber"].ToString(), dueDate, objSPListItem["Status"].ToString(), properties.Site.Url);
                        UpsertCompletionStatus(objSPListItem["CompanyNumber"].ToString(), "PAISAT", objSPListItem["Status"].ToString(), properties.Site.Url);
                    }
                }
            }
            catch (Exception objException)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryRecievers, objException.Message);
            }
        }

        /// <summary>
        /// An item was updated.
        /// </summary>
        public override void ItemUpdated(SPItemEventProperties properties)
        {
            try
            {
                if (properties != null && properties.WebUrl.ToUpper().Contains("PAISAT"))
                {
                    if (properties.List.Title == "Employees")
                    {
                        SPListItem objSPListItem = properties.ListItem;
                        //DateTime dueDate = new DateTime();
                        //if (objSPListItem["ExpiryDate"] == null)
                        //{
                        //    dueDate = DateTime.Parse(objSPListItem["CompletionDueDate"].ToString().Replace("datetime;#", ""));
                        //}
                        //else
                        //{
                        //    dueDate = DateTime.Parse(objSPListItem["ExpiryDate"].ToString());
                        //}

                        //InsertDataToIDM(objSPListItem["CompanyNumber"].ToString(), dueDate, objSPListItem["Status"].ToString(), properties.Site.Url);
                        UpsertCompletionStatus(objSPListItem["CompanyNumber"].ToString(), "PAISAT", objSPListItem["Status"].ToString(), properties.Site.Url);
                    }
                }
            }
            catch (Exception objException)
            {
                LoggingService.LogError(LoggingService.DiagnosticCategoryRecievers, objException.Message);
            }
        }
        private void InsertDataToIDM(string companyNumber, DateTime dtDueDate, string status, string siteUrl)
        {
            OracleCommand objOracleCommand = null;
            string mimConnectionString = Utility.GetPropertyBagValueByKey("MIMConnection", siteUrl).ToString();

            using (OracleConnection objOracleConnection = new OracleConnection(mimConnectionString))
            {
                objOracleCommand = new OracleCommand();
                objOracleCommand.Connection = objOracleConnection;
                objOracleCommand.CommandText = "SP_INSERT_UPDATE_MIM_USER";
                objOracleCommand.CommandType = System.Data.CommandType.StoredProcedure;
                try
                {
                    objOracleConnection.Open();
                    objOracleCommand.Parameters.Add("P_MUID", OracleType.VarChar).Value = companyNumber;
                    objOracleCommand.Parameters.Add("P_Due_Date", OracleType.DateTime).Value = dtDueDate;
                    objOracleCommand.Parameters.Add("P_STATUS", OracleType.VarChar).Value = status;
                    objOracleCommand.Parameters.Add("P_ActionResult", OracleType.Number).Direction = System.Data.ParameterDirection.Output;
                    objOracleCommand.ExecuteNonQuery();
                }
                catch (Exception objException)
                {
                    LoggingService.LogError(LoggingService.DiagnosticCategoryRecievers, objException.Message);
                }
                finally
                {
                    objOracleCommand = null;
                    objOracleConnection.Close();
                }
            }

        }

        [ObsoleteAttribute("OracleConnection has been deprecated. http://go.microsoft.com/fwlink/?LinkID=144260", false)]
        public static void UpsertCompletionStatus(string companyNumber, string trainingName, string status, string siteUrl)
        {
            OracleCommand objOracleCommand = null;
            string mimConnectionString = Utility.GetPropertyBagValueByKey("MIMLTConnection", siteUrl).ToString();

            //string mimConnectionString = @"Password=co#19mim;User ID=mim_comp;Data Source=  (DESCRIPTION =(ADDRESS = (PROTOCOL = TCP)(HOST = mus-dbvip-202.pdo.shell.om)(PORT = 1521))(CONNECT_DATA =(SERVER = DEDICATED)(SERVICE_NAME = PDOTS202.WORLD)));Persist Security Info=False";

            using (OracleConnection objOracleConnection = new OracleConnection(mimConnectionString))
            {
                objOracleCommand = new OracleCommand();
                objOracleCommand.Connection = objOracleConnection;
                objOracleCommand.CommandText = "SP_UPSERT_MIM_USER_DECL_TRNG";
                objOracleCommand.CommandType = System.Data.CommandType.StoredProcedure;
                try
                {
                    objOracleConnection.Open();
                    objOracleCommand.Parameters.Add("P_ACCOUNTNAME", OracleType.VarChar).Value = companyNumber;
                    objOracleCommand.Parameters.Add("P_DECL_TRNG_NAME", OracleType.VarChar).Value = trainingName;
                    if (status == "C")
                    {
                        objOracleCommand.Parameters.Add("P_STATUS", OracleType.VarChar).Value = "Completed";
                    }
                    else
                    {
                        if (companyNumber.StartsWith("MUEX"))
                        {
                            objOracleCommand.Parameters.Add("P_STATUS", OracleType.VarChar).Value = "Completed";
                        }
                        else
                        {
                            objOracleCommand.Parameters.Add("P_STATUS", OracleType.VarChar).Value = "Pending";
                        }
                    }
                    objOracleCommand.Parameters.Add("P_ActionResult", OracleType.Number).Direction = System.Data.ParameterDirection.Output;
                    objOracleCommand.ExecuteNonQuery();
                }
                catch (Exception objException)
                {
                    LoggingService.LogError(LoggingService.DiagnosticCategoryRecievers, objException.Message);
                }
                finally
                {
                    objOracleCommand = null;
                    objOracleConnection.Close();
                }
            }
        }

    }
}