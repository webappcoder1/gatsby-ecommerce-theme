﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.SharePoint;
using System.Net.Mail;
using SP = Microsoft.SharePoint.Client;
using System.DirectoryServices.ActiveDirectory;
using System.DirectoryServices.AccountManagement;
using System.DirectoryServices;
using System.Web;
using System.Collections.Specialized;
using System.Data.OleDb;
using System.Data.OracleClient;
using System.Configuration;
using System.Globalization;
using System.Xml.Serialization;
using System.IO;
using System.Text.RegularExpressions;
using Microsoft.SharePoint.Client;
using Microsoft.Office.Server.UserProfiles;
using System.Data.SqlClient;


namespace COIDataMigrationToMIM
{
    class Program
    {
        public static string coiSiteurl = "http://portal.corp.pdo.om/solutions/COI";
        public static string iSATSiteUrl = "http://portal.corp.pdo.om/solutions/lms/isat";

        static void Main(string[] args)
        {
            //GetDataFuelCard();
            //UpsertCompletionStatus("MUC9554", "COI", "P");
            UpsertCompletionStatus("MUC9866", "COI", "P");
            UpsertCompletionStatus("MUCD846", "COI", "P");
            UpsertCompletionStatus("MUCL981", "COI", "P");
            UpsertCompletionStatus("MUCM117", "COI", "P");
            UpsertCompletionStatus("MUCM197", "COI", "P");
            UpsertCompletionStatus("MUCM198", "COI", "P");
            UpsertCompletionStatus("MUCM376", "COI", "P");
            UpsertCompletionStatus("MUC9554", "COI", "P");
            UpsertCompletionStatus("MUCM382", "COI", "P");
            UpsertCompletionStatus("MUCM469", "COI", "P");
            UpsertCompletionStatus("MUCM482", "COI", "P");
            UpsertCompletionStatus("MUCM739", "COI", "P");
            
            //SyncNCCOIDetailsToMIM();

           // WriteExcelData(@"E:\Audhesh\COIMIMDMData\Logs\MissingUsers.xlsx", ".xlsx", "Yes");

            Console.WriteLine("Completed");
            Console.Read();
            //InsertMissingUsers();
        }

        private static void InsertMissingUsers()
        {
            DataTable dtEmployees = new DataTable();
            // dtEmployees = ReadExcelData(@"E:\Audhesh\COIMIMDMData\MissingUsers.xlsx", ".xlsx", "Yes");
            foreach (DataRow drEmployees in dtEmployees.Rows)
            {
                try
                {
                    if (drEmployees["Employee No"].ToString().Trim().ToUpper() != "")
                    {
                        TestInsert(drEmployees["Employee No"].ToString().Trim().ToUpper());
                    }
                }
                catch (Exception ex)
                {

                }
            }
        }

        private static void TestInsert(string muNumber)
        {
            string adGroups = "PDO-All-Students-GS;PDO-All-Employees-GS;PDO-All-Contractors-GS;";

            SPUsersEntity objSPUserEntity = GetADUserAttributes(muNumber);

            if (IsUserInGroup(objSPUserEntity.UserName, adGroups))
            {
                if (IsCompanyNumberExist(objSPUserEntity.UserName) == false)
                {
                    InsertEmployees(objSPUserEntity);
                }
            }
        }

        private static void UpdateCSOMInclusions()
        {
            try
            {
                ClientContext clientContext = new ClientContext(coiSiteurl);
                Microsoft.SharePoint.Client.List coiUsersList = clientContext.Web.Lists.GetByTitle("COIUSERS");
                clientContext.Load(coiUsersList);
                clientContext.ExecuteQuery();

                if (coiUsersList != null && coiUsersList.ItemCount > 0)
                {
                    Microsoft.SharePoint.Client.CamlQuery camlQuery = new CamlQuery();
                    camlQuery.ViewXml =
                       @"<View>  
                            <Query> 
                               <Where><Eq><FieldRef Name='employeeactivestatus' /><Value Type='Boolean'>0</Value></Eq></Where> 
                            </Query> 
                             <ViewFields><FieldRef Name='Title' /><FieldRef Name='employeeno' /><FieldRef Name='employeeactivestatus' /><FieldRef Name='IsActive' /></ViewFields> 
                      </View>";
                    ListItemCollection coiUsersListItems = coiUsersList.GetItems(camlQuery);
                    clientContext.Load(coiUsersListItems);
                    clientContext.ExecuteQuery();

                    foreach (ListItem empListItem in coiUsersListItems)
                    {
                        if (IsExcludedUserCSOM(empListItem["employeeno"].ToString()))
                        {
                            empListItem["employeeactivestatus"] = false;
                        }
                        else
                        {
                            empListItem["employeeactivestatus"] = true;
                        }
                    }
                }
            }
            catch (Exception objException)
            {
                //LoggingService.LogError(LoggingService.DiagnosticCategoryJobs, objException.Message);
            }
        }

        private static bool IsExcludedUserCSOM(string muNumber)
        {
            bool isExcludedUser = false;
            ClientContext clientContext = new ClientContext(coiSiteurl);
            Microsoft.SharePoint.Client.List spList = clientContext.Web.Lists.GetByTitle("Exclusions");
            clientContext.Load(spList);
            clientContext.ExecuteQuery();

            if (spList != null && spList.ItemCount > 0)
            {
                Microsoft.SharePoint.Client.CamlQuery camlQuery = new CamlQuery();
                camlQuery.ViewXml =
                   @"<View>  
                        <Query> 
                           <Where><Or><Eq><FieldRef Name='employeeno' /><Value Type='Text'>" + muNumber.Replace("MU", "") + @"</Value></Eq><Eq><FieldRef Name='employeeno' /><Value Type='Text'>" + muNumber + @"</Value></Eq></Or></Where> 
                        </Query> 
                  </View>";
                ListItemCollection listItems = spList.GetItems(camlQuery);
                clientContext.Load(listItems);
                clientContext.ExecuteQuery();
                if (listItems != null && listItems.Count > 0)
                {
                    isExcludedUser = true;
                }
            }

            return isExcludedUser;
        }

        private static void UpdateCSOMExclusions()
        {
            try
            {
                ListItemCollection existingEmployees = GetAllExcludedUsersCSOM();
                foreach (ListItem listItem in existingEmployees)
                {
                    UpdateUserExclusionCSOM(listItem["employeeno"].ToString());
                }
            }
            catch (Exception objException)
            {
                //LoggingService.LogError(LoggingService.DiagnosticCategoryJobs, objException.Message);
            }
        }

        private static void UpdateUserExclusionCSOM(string muNumber)
        {
            try
            {

                ClientContext clientContext = new ClientContext(coiSiteurl);
                Microsoft.SharePoint.Client.List spList = clientContext.Web.Lists.GetByTitle("COIUSERS");
                clientContext.Load(spList);
                clientContext.ExecuteQuery();
                if (!muNumber.ToUpper().StartsWith("MU"))
                {
                    muNumber = "MU" + muNumber;
                }

                if (spList != null && spList.ItemCount > 0)
                {
                    Microsoft.SharePoint.Client.CamlQuery camlQuery = new CamlQuery();
                    camlQuery.ViewXml =
                       @"<View>  
                            <Query> 
                               <Where><Eq><FieldRef Name='employeeno' /><Value Type='Text'>" + muNumber + @"</Value></Eq></Where> 
                            </Query> 
                             <ViewFields><FieldRef Name='employeeno' /><FieldRef Name='IsActive' /><FieldRef Name='employeeactivestatus' /></ViewFields> 
                      </View>";

                    ListItemCollection empListItems = spList.GetItems(camlQuery);
                    clientContext.Load(empListItems);
                    clientContext.ExecuteQuery();
                    foreach (ListItem listItem in empListItems)
                    {
                        listItem["employeeactivestatus"] = 0;
                        listItem.Update();
                        clientContext.ExecuteQuery();
                    }
                }
            }
            catch (Exception objException)
            {
                //LoggingService.LogError(LoggingService.DiagnosticCategoryJobs, objException.Message);
            }
        }

        private static void UpdateUserAccountStatus()
        {
            try
            {
                SPUsersEntity objSPUserEntity;
                string companyNo = string.Empty, directorate = String.Empty, userGroups = String.Empty;
                int flags;
                ClientContext context = new ClientContext("");
                List employeesList = context.Web.Lists.GetByTitle("COIUSERS");
                CamlQuery query = CamlQuery.CreateAllItemsQuery(30000);
                ListItemCollection objSPListItemColl = employeesList.GetItems(query);
                context.Load(objSPListItemColl);
                context.ExecuteQuery();
                ListItem empItem = null;

                for (int i = 0; i < objSPListItemColl.Count; i++)
                {
                    try
                    {
                        empItem = objSPListItemColl[i];

                        if (Convert.ToString(empItem["CC"]) == "C" || Convert.ToString(empItem["COI"]) == "C")
                        {
                            Console.WriteLine(i.ToString());
                            if (!string.IsNullOrEmpty(Convert.ToString(empItem["employeeno"])))
                            {
                                companyNo = empItem["employeeno"].ToString();
                                objSPUserEntity = GetADUserAttributes(companyNo);
                                if (objSPUserEntity.IsActive != null)
                                {
                                    flags = int.Parse(objSPUserEntity.IsActive);
                                    if (!Convert.ToBoolean(flags & 0x0002))
                                    {
                                        //Active User
                                        empItem["IsActive"] = 1;
                                    }
                                    else
                                    {
                                        //InActive User
                                        empItem["IsActive"] = 0;
                                    }
                                }
                                else
                                {
                                    empItem["IsActive"] = 0;
                                }

                                empItem.Update();
                                context.ExecuteQuery();
                            }
                        }
                    }
                    catch (Exception objException)
                    {
                        // LoggingService.LogError(LoggingService.DiagnosticCategoryJobs, objException.Message);
                    }
                }

            }
            catch (Exception objException)
            {
                // LoggingService.LogError(LoggingService.DiagnosticCategoryJobs, objException.Message);
            }
        }

        private static void RefreshCOIUsersStatusCSOM()
        {
            try
            {
                SPUsersEntity objSPUserEntity;
                string companyNo = string.Empty, directorate = String.Empty, userGroups = String.Empty;
                int flags;
                // UserOrganisationHierarchy objUserOrganisationHierarchy = null;
                ClientContext context = new ClientContext(coiSiteurl);
                List employeesList = context.Web.Lists.GetByTitle("COIUSERS");


                CamlQuery query = CamlQuery.CreateAllItemsQuery(20000);
                ListItemCollection objSPListItemColl = employeesList.GetItems(query);
                context.Load(objSPListItemColl);
                context.ExecuteQuery();

                foreach (ListItem empItem in objSPListItemColl)
                {
                    try
                    {
                        if (!string.IsNullOrEmpty(Convert.ToString(empItem["employeeno"])))
                        {
                            companyNo = empItem["employeeno"].ToString();
                            objSPUserEntity = GetADUserAttributes(companyNo);
                            if (objSPUserEntity.IsActive != null)
                            {
                                flags = int.Parse(objSPUserEntity.IsActive);
                                if (!Convert.ToBoolean(flags & 0x0002))
                                {
                                    //Active User
                                    empItem["IsActive"] = 1;
                                }
                                else
                                {
                                    //InActive User
                                    empItem["IsActive"] = 0;
                                }
                            }
                            else
                            {
                                empItem["IsActive"] = 0;
                            }

                            empItem["RefIndicator"] = objSPUserEntity.RefIndicator;
                            //objUserOrganisationHierarchy = GetParentsByDepartment(companyNo);
                            //if (objUserOrganisationHierarchy.Status == "OK")
                            //{
                            //    empItem["directorate"] = objUserOrganisationHierarchy.Directorate;
                            //    empItem["Department"] = objUserOrganisationHierarchy.Department;
                            //    empItem["section"] = objUserOrganisationHierarchy.Section;
                            //    empItem["team"] = objUserOrganisationHierarchy.Team;
                            //}

                            empItem.Update();
                            context.ExecuteQuery();
                        }

                    }
                    catch (Exception objException)
                    {
                        // LoggingService.LogError(LoggingService.DiagnosticCategoryJobs, objException.Message);
                    }
                }

            }
            catch (Exception objException)
            {
                // LoggingService.LogError(LoggingService.DiagnosticCategoryJobs, objException.Message);
            }
        }

        public static void GetUserManagersDepartments(string loginName, out List<string> departments)
        {
            string excludedDirectorate = "MD";
            departments = new List<string>();
            List<string> departmentsOut = new List<string>();

            try
            {
                SPSecurity.RunWithElevatedPrivileges(delegate()
                {
                    using (SPSite newSite = new SPSite("http://mus-ws-546:9000/solutions/coi"))
                    {
                        using (SPWeb newWeb = newSite.OpenWeb())
                        {
                            SPServiceContext serverContext = SPServiceContext.GetContext(newWeb.Site);
                            UserProfileManager profileManager = new UserProfileManager(serverContext);

                            if (profileManager.UserExists(loginName))
                            {
                                try
                                {
                                    UserProfile profile = profileManager.GetUserProfile(loginName);

                                    if (profile != null)
                                    {
                                        string dept = string.Empty;
                                        UserProfile[] managersProfile = profile.GetManagers();
                                        if (managersProfile != null && managersProfile.Length > 0)
                                        {

                                            managersProfile.ToList().ForEach(m =>
                                            {

                                                dept = Convert.ToString(m["Department"].Value.ToString());
                                                if (!excludedDirectorate.Contains(dept) && m.GetDirectReports().Count() > 0)
                                                {
                                                    departmentsOut.Add(dept);
                                                }

                                            });
                                        }

                                        if (departmentsOut.Count < 4)
                                        {
                                            UserProfile[] reporteesProfile = profile.GetDirectReports();
                                            if (reporteesProfile.Count() > 0)
                                            {
                                                departmentsOut.Add(profile["Department"].Value.ToString());
                                            }
                                        }
                                    }

                                }
                                catch (Exception objException)
                                {
                                    //LoggingService.LogError(LoggingService.DiagnosticCategoryJobs, objException.Message);
                                }

                                switch (departmentsOut.Count)
                                {
                                    case 0:
                                        departmentsOut.Add("Other");
                                        departmentsOut.Add("Other");
                                        departmentsOut.Add("Other");
                                        departmentsOut.Add("Other");
                                        break;

                                    case 1:
                                        departmentsOut.Add(departmentsOut[0]);
                                        departmentsOut.Add(departmentsOut[0]);
                                        departmentsOut.Add(departmentsOut[0]);
                                        break;

                                    case 2:
                                        departmentsOut.Add(departmentsOut[1]);
                                        departmentsOut.Add(departmentsOut[1]);
                                        break;

                                    case 3:
                                        departmentsOut.Add(departmentsOut[2]);
                                        break;

                                    default:
                                        departmentsOut.Add("Other");
                                        departmentsOut.Add("Other");
                                        departmentsOut.Add("Other");
                                        departmentsOut.Add("Other");
                                        break;
                                }
                            }
                        }

                    }

                });

                departments = departmentsOut;

            }
            catch (Exception objException)
            {
                //LoggingService.LogError(LoggingService.DiagnosticCategoryJobs, objException.Message);
            }
        }


        public static UserOrganisationHierarchy GetParentsByDepartment(string muid)
        {
            UserOrganisationHierarchy userOrganisationHierarchy = new UserOrganisationHierarchy();
            List<string> parentDepartments = null;

            try
            {
                parentDepartments = new List<string>();

                try
                {
                    GetUserManagersDepartments(@"corp\" + muid, out parentDepartments);
                    userOrganisationHierarchy = new UserOrganisationHierarchy
                    {
                        Directorate = parentDepartments[0],
                        Department = parentDepartments[1],
                        Section = parentDepartments[2],
                        Team = parentDepartments[3],
                        Status = "OK"
                    };

                }
                catch (Exception objException)
                {
                    userOrganisationHierarchy = new UserOrganisationHierarchy
                    {
                        Status = "Error"
                    };

                    //LoggingService.LogError(LoggingService.DiagnosticCategoryJobs, objException.Message);
                }
            }
            catch (Exception objException)
            {
                userOrganisationHierarchy = new UserOrganisationHierarchy
                {
                    Status = "Error"
                };

                //LoggingService.LogError(LoggingService.DiagnosticCategoryJobs, objException.Message);
            }

            return userOrganisationHierarchy;

        }

        private static bool HasDirectReportees(string ADId)
        {
            bool hasDirectReportees = false;
            DirectoryEntry myLdapConnection = CreateDirectoryEntry();
            DirectorySearcher dssearch = new DirectorySearcher(myLdapConnection);
            dssearch.Filter = "(sAMAccountName=" + ADId + ")";
            SearchResult sresult = dssearch.FindOne();
            DirectoryEntry dsresult = sresult.GetDirectoryEntry();
            dssearch.PropertiesToLoad.Add("directReports");
            if (dssearch.FindOne().Properties["directReports"].Count > 0)
            {
                hasDirectReportees = true;
            }

            List<string> Controls = new List<string>();


            foreach (object objProperty in dssearch.FindOne().Properties["directReports"])
            {

                var objProperty1 = objProperty.ToString();
                var subordinatename = objProperty1.Split(',').Select(pair => pair.Split('=').LastOrDefault()).ToArray().GetValue(0);
                PrincipalContext ctx = new PrincipalContext(ContextType.Domain);
                UserPrincipal user = UserPrincipal.FindByIdentity(ctx, IdentityType.DistinguishedName, objProperty1);
                string displayemail = user.DisplayName;

                Controls.Add(displayemail);
            }

            return hasDirectReportees;
        }


        private static void TestForActive()
        {
            SPUsersEntity objUser = GetADUserAttributes("MUC9290");
            int flags = int.Parse(objUser.IsActive);
            if (!Convert.ToBoolean(flags & 0x0002))
            {
                //Active User
                Console.WriteLine("Active");
            }
            else
            {
                //InActive User
                Console.WriteLine("InActive");
            }
        }

        private static void InsertIntoProd()
        {
            string adGroups = "PDO-All-Students-GS;PDO-All-Employees-GS;PDO-All-Contractors-GS;";
            ListItemCollection existingEmployees = GetAllISATRecords();
            SPUsersEntity objSPUserEntity = null;

            foreach (ListItem listItem in existingEmployees)
            {
                try
                {
                    objSPUserEntity = new SPUsersEntity();

                    objSPUserEntity = GetADUserAttributes(listItem["Title"].ToString());
                    if (IsUserInGroup(objSPUserEntity.UserName, adGroups))
                    {
                        if (IsCompanyNumberExist(objSPUserEntity.UserName) == false)
                        {
                            InsertEmployees(objSPUserEntity);
                        }
                    }
                }
                catch (Exception objException)
                {

                }
            }
        }

        //private static void RefreshCOIUsersStatus()
        //{
        //    try
        //    {
        //        SPUsersEntity objSPUserEntity;
        //        string companyNo = string.Empty, directorate = String.Empty, userGroups = String.Empty;
        //        int flags;
        //        UserOrganisationHierarchy objUserOrganisationHierarchy = null;
        //        ClientContext context = new ClientContext(coiSiteurl);
        //        List employeesList = context.Web.Lists.GetByTitle("COIUSERS");


        //        CamlQuery query = CamlQuery.CreateAllItemsQuery(20000);
        //        ListItemCollection objSPListItemColl = employeesList.GetItems(query);
        //        context.Load(objSPListItemColl);
        //        context.ExecuteQuery();

        //        foreach (ListItem empItem in objSPListItemColl)
        //        {
        //            try
        //            {
        //                if (!string.IsNullOrEmpty(Convert.ToString(empItem["employeeno"])))
        //                {
        //                    companyNo = empItem["employeeno"].ToString();
        //                    objSPUserEntity = GetADUserAttributes(companyNo);
        //                    if (objSPUserEntity.IsActive != null)
        //                    {
        //                        flags = int.Parse(objSPUserEntity.IsActive);
        //                        if (!Convert.ToBoolean(flags & 0x0002))
        //                        {
        //                            //Active User
        //                            empItem["IsActive"] = 1;
        //                        }
        //                        else
        //                        {
        //                            //InActive User
        //                            empItem["IsActive"] = 0;
        //                        }
        //                    }
        //                    else
        //                    {
        //                        empItem["IsActive"] = 0;
        //                    }

        //                    empItem["Ref Indicator"] = objSPUserEntity.RefIndicator;
        //                    objUserOrganisationHierarchy = GetParentsByDepartment("", companyNo);
        //                    if (objUserOrganisationHierarchy.Status == "OK")
        //                    {
        //                        empItem["directorate"] = objUserOrganisationHierarchy.Directorate;
        //                        empItem["Department"] = objUserOrganisationHierarchy.Department;
        //                        empItem["section"] = objUserOrganisationHierarchy.Section;
        //                        empItem["team"] = objUserOrganisationHierarchy.Team;
        //                    }

        //                    empItem.Update();
        //                    context.ExecuteQuery();
        //                }

        //            }
        //            catch (Exception objException)
        //            {
        //                // LoggingService.LogError(LoggingService.DiagnosticCategoryJobs, objException.Message);
        //            }
        //        }

        //    }
        //    catch (Exception objException)
        //    {
        //        // LoggingService.LogError(LoggingService.DiagnosticCategoryJobs, objException.Message);
        //    }
        //}

        private static string GetManagerEmailId(string companyNumber, SPWeb objSPWebCOI)
        {
            String emailId = String.Empty;
            SPUser objSPUser = null;
            UserProfile profile = null;
            UserProfileManager profileManager = null;

            try
            {
                objSPUser = objSPWebCOI.EnsureUser(companyNumber);
                SPServiceContext serverContext = SPServiceContext.GetContext(objSPWebCOI.Site);
                profileManager = new UserProfileManager(serverContext);
                profile = profileManager.GetUserProfile(companyNumber);
                string managerName = (string)profile["manager"].Value;
                SPUser objSPUserManager = objSPWebCOI.EnsureUser(managerName);
                emailId = objSPUserManager.Email;
            }
            catch (Exception objException)
            {
                // LoggingService.LogError(LoggingService.DiagnosticCategoryJobs, objException.Message);
            }
            finally
            {
                objSPUser = null;
                profile = null;
            }

            return emailId;
        }

        public static void InsertEmployees(SPUsersEntity objSPUsersEntity)
        {
            try
            {
                int flags;
                ClientContext clientContext = new ClientContext(coiSiteurl);
                SP.List oList = clientContext.Web.Lists.GetByTitle("COIUSERS");
                User theUser = clientContext.Web.EnsureUser(objSPUsersEntity.UserName);
                clientContext.Load(theUser);
                clientContext.ExecuteQuery();

                ListItemCreationInformation itemCreateInfo = new ListItemCreationInformation();
                ListItem oListItem = oList.AddItem(itemCreateInfo);

                oListItem["employeeno"] = objSPUsersEntity.UserName;
                oListItem["employeename"] = objSPUsersEntity.FirstName + " " + objSPUsersEntity.LastName; ;
                oListItem["email"] = objSPUsersEntity.Email;
                oListItem["employeeactivestatus"] = 1;
                oListItem["CC"] = "P";
                oListItem["COI"] = "P";
                oListItem["RefIndicator"] = objSPUsersEntity.RefIndicator;

                if (objSPUsersEntity.IsActive != null)
                {
                    flags = int.Parse(objSPUsersEntity.IsActive);
                    if (!Convert.ToBoolean(flags & 0x0002))
                    {
                        //Active User
                        oListItem["IsActive"] = 1;
                    }
                    else
                    {
                        //InActive User
                        oListItem["IsActive"] = 0;
                    }
                }
                else
                {
                    oListItem["IsActive"] = 0;
                }

                oListItem["Author"] = theUser;
                oListItem["Editor"] = theUser;
                oListItem.Update();
                clientContext.ExecuteQuery();
            }
            catch (Exception ex)
            {

            }
        }

        private static bool IsCompanyNumberExist(string companyNumber)
        {
            bool isExist = false;
            try
            {
                ListItemCollection coiUsers = GetAllCOIRecords();
                isExist = (from ListItem employeeItem in coiUsers.AsEnumerable()
                           where Convert.ToString(employeeItem["employeeno"]).ToLower() == companyNumber.ToLower()
                           select employeeItem).Any();
            }
            catch (Exception objException)
            {

            }
            return isExist;
        }

        private static bool IsUserCompliant(string companyNumber)
        {
            bool isCompliant = false;
            try
            {
                ListItemCollection coiUsers = GetAllCOIRecords();
                isCompliant = (from ListItem employeeItem in coiUsers.AsEnumerable()
                               where Convert.ToString(employeeItem["employeeno"]).ToLower() == companyNumber.ToLower() &&
                               Convert.ToString(employeeItem["CC"]).ToLower() == "c" && Convert.ToString(employeeItem["COI"]).ToLower() == "c"


                               select employeeItem).Any();
            }
            catch (Exception objException)
            {

            }
            return isCompliant;
        }








        /// <summary>
        /// This method is used to get the AD User attributes of the passed Active Directory Id.
        /// </summary>
        /// <param name="userADId">User Active Directory Id.</param>
        /// <returns>Returns the initialized object of the SPUsersEntity containing the details of the User.</returns>
        private static SPUsersEntity GetADUserAttributes(string userADId)
        {
            SPUsersEntity objSPUsersEntity = null;
            PrincipalContext objPrincipalContext = null;

            try
            {
                objSPUsersEntity = new SPUsersEntity();
                objPrincipalContext = new PrincipalContext(ContextType.Domain, "CORP");
                UserPrincipal user = UserPrincipal.FindByIdentity(objPrincipalContext, userADId);
                DirectoryEntry objDirectoryEntry = user.GetUnderlyingObject() as DirectoryEntry;

                if (user != null)
                {
                    if (objDirectoryEntry.Properties.Contains("displayName"))
                        objSPUsersEntity.DisplayName = objDirectoryEntry.Properties["displayName"].Value.ToString();

                    if (objDirectoryEntry.Properties.Contains("sAMAccountName"))
                        objSPUsersEntity.UserName = objDirectoryEntry.Properties["sAMAccountName"].Value.ToString();

                    if (objDirectoryEntry.Properties.Contains("givenName"))
                        objSPUsersEntity.FirstName = objDirectoryEntry.Properties["givenName"].Value.ToString();

                    if (objDirectoryEntry.Properties.Contains("sn"))
                        objSPUsersEntity.LastName = objDirectoryEntry.Properties["sn"].Value.ToString();

                    if (objDirectoryEntry.Properties.Contains("userAccountControl"))
                        objSPUsersEntity.IsActive = objDirectoryEntry.Properties["userAccountControl"].Value.ToString();

                    if (objDirectoryEntry.Properties.Contains("department"))
                        objSPUsersEntity.RefIndicator = objDirectoryEntry.Properties["department"].Value.ToString();

                    if (objDirectoryEntry.Properties.Contains("displayName"))
                        objSPUsersEntity.DisplayName = objDirectoryEntry.Properties["displayName"].Value.ToString();

                    if (objDirectoryEntry.Properties.Contains("mail"))
                        objSPUsersEntity.Email = objDirectoryEntry.Properties["mail"].Value.ToString();

                }

            }
            catch (Exception objException)
            {
                //LoggingService.LogError(LoggingService.DiagnosticCategoryJobs, objException.Message);
            }
            finally
            {
                objPrincipalContext = null;
            }

            return objSPUsersEntity;
        }




        //private void GetNewelyAddedUsersFromLDAP()
        //{
        //    try
        //    {
        //        string adGroups = GetADGroupsFromConfigurations();
        //        DirectoryEntry myLdapConnection = CreateDirectoryEntry();
        //        DirectorySearcher search = new DirectorySearcher(myLdapConnection);
        //        search.Filter = "(&(objectCategory=Person) (objectClass=User)(whenCreated>=" + System.DateTime.Now.AddDays(-4).ToString("yyyyMMddHHmmss.sZ") + "))";
        //        SearchResultCollection searchResults = search.FindAll();
        //        SPUsersEntity objSPUserEntity = null;
        //        foreach (SearchResult result in searchResults)
        //        {
        //            try
        //            {
        //                if (result != null)
        //                {
        //                    if (result.Properties.Contains("sAMAccountName"))
        //                    {
        //                        objSPUserEntity = new SPUsersEntity();
        //                        if (IsUserInGroup(Convert.ToString(result.Properties["sAMAccountName"][0]).Replace("CORP\\", ""), adGroups))
        //                        {
        //                            objSPUserEntity = GetADUserAttributes(Convert.ToString(result.Properties["sAMAccountName"][0]).Replace("CORP\\", ""));
        //                            if (IsCompanyNumberExist(objSPUserEntity.UserName) == false)
        //                            {
        //                                InsertEmployees(objSPUserEntity, adGroups);
        //                            }
        //                        }
        //                    }
        //                }
        //            }
        //            catch (Exception ex)
        //            {
        //                //LoggingService.LogError(LoggingService.DiagnosticCategoryJobs, ex.Message);
        //            }
        //        }
        //    }
        //    catch (Exception e)
        //    {
        //        // LoggingService.LogError(LoggingService.DiagnosticCategoryJobs, e.Message);
        //    }
        //}




        public static ListItemCollection GetAllExcludedUsersCSOM()
        {
            ClientContext context = new ClientContext(coiSiteurl);
            List employeesList = context.Web.Lists.GetByTitle("Exclusions");
            CamlQuery query = CamlQuery.CreateAllItemsQuery(20000);
            ListItemCollection items = employeesList.GetItems(query);
            context.Load(items);
            context.ExecuteQuery();
            return items;
        }



        public static ListItemCollection GetAllISATRecords()
        {
            ClientContext context = new ClientContext(iSATSiteUrl);
            List employeesList = context.Web.Lists.GetByTitle("Employees");
            CamlQuery query = CamlQuery.CreateAllItemsQuery(20000);
            ListItemCollection items = employeesList.GetItems(query);
            context.Load(items);
            context.ExecuteQuery();
            return items;
        }

        public static ListItemCollection GetAllCOIRecords()
        {
            ClientContext context = new ClientContext(coiSiteurl);
            List employeesList = context.Web.Lists.GetByTitle("COIUSERS");
            CamlQuery query = CamlQuery.CreateAllItemsQuery(50000);
            ListItemCollection items = employeesList.GetItems(query);
            context.Load(items);
            context.ExecuteQuery();
            return items;
        }

        /// <summary>
        /// This method is used to check whether the new user belongs to the "PDO-MD-Members-GS" or "PDO-Students-Members-GS" AD membership groups.
        /// </summary>
        /// <param name="companyNumber">Company Number</param>
        /// <returns>Returns true if the user is in the group else returns false.</returns>
        public static bool IsUserInGroup(string companyNumber, string adGroups)
        {
            bool isUserInGroup = false;
            string[] arrGroups = adGroups.Split(';');

            try
            {
                PrincipalContext ctx = new PrincipalContext(ContextType.Domain, "CORP");
                UserPrincipal user = UserPrincipal.FindByIdentity(ctx, companyNumber);
                isUserInGroup = arrGroups.AsEnumerable()
                    .Where(a => user.IsMemberOf(GroupPrincipal.FindByIdentity(ctx, a.Trim())) && a != "")
                    .Any();
            }
            catch (Exception objException)
            {
                // LoggingService.LogError(LoggingService.DiagnosticCategoryJobs, objException.Message);
            }

            return isUserInGroup;
        }

        [ObsoleteAttribute("OracleConnection has been deprecated. http://go.microsoft.com/fwlink/?LinkID=144260", false)]
        public static void SyncNCCOIDetailsToMIM()
        {
            DataTable dtEmployees = null;

            try
            {
                dtEmployees = ReadExcelData(@"E:\Audhesh\COIMIMDMData\NonCompliant_8_03_2024.xlsx", ".xlsx", "Yes");

                foreach (DataRow drEmployees in dtEmployees.Rows)
                {
                    try
                    {
                        UpsertCompletionStatus(drEmployees["Employee No"].ToString().Trim().ToUpper(), "COI", "P");
                        //if (IsUserCompliant(drEmployees["Employee No"].ToString().Trim().ToUpper()))
                        //{
                        //    UpsertCompletionStatus(drEmployees["Employee No"].ToString().Trim().ToUpper(), "COI", "P");
                        //}

                        //if (IsUserInGroup(drEmployees["Employee No"].ToString().Trim(), "PDO-All-Students-GS;PDO-All-Employees-GS;PDO-All-Contractors-GS;"))
                        //{
                        //    //if (bool.Parse(drEmployees["employeeactivestatus"].ToString()) == false)
                        //    //{
                        //    //    UpsertCompletionStatus(drEmployees["Employee No"].ToString().Trim().ToUpper(), "COI", "C");
                        //    //}
                        //    //else
                        //    //{
                        //    //if (drEmployees["CC"].ToString().ToUpper() == "C" && drEmployees["COI"].ToString().ToUpper() == "C")
                        //    //{
                        //    //    UpsertCompletionStatus(drEmployees["Employee No"].ToString().Trim().ToUpper(), "COI", "C");
                        //    //}
                        //    //else
                        //    //{
                        //    //    UpsertCompletionStatus(drEmployees["Employee No"].ToString().Trim().ToUpper(), "COI", "P");
                        //    //}
                        //    //}
                        //}
                    }
                    catch (Exception ex)
                    {

                    }
                }
            }
            catch (Exception ex)
            {
                //LoggingService.LogError(LoggingService.DiagnosticCategoryJobs, ex.Message);
            }
        }


        //public static void GetDataFuelCard()
        //{


        //   string connectionString = @"Password=FUELCARD#1907;User ID=WH_FUELCARD;Data Source=  (DESCRIPTION =(ADDRESS = (PROTOCOL = TCP)(HOST = mus-dbvip-201.pdo.shell.om)(PORT = 1521))(CONNECT_DATA =(SERVER = DEDICATED)(SERVICE_NAME = ARDH12C.WORLD)));Persist Security Info=False";



        //   using (OracleConnection objOracleConnection = new OracleConnection(connectionString))
        //   {
        //       DataTable dtVehicle_Oracle = new DataTable();
        //       objOracleCommand = new OracleCommand();
        //       objOracleCommand.Connection = objOracleConnection;

        //       try
        //       {
        //           OracleDataAdapter oda = new OracleDataAdapter("SELECT * FROM V_VEHICLE", objOracleConnection);
        //           dtVehicle_Oracle = new DataTable();
        //           oda.Fill(dtVehicle_Oracle);
        //       }
        //       catch (Exception objException)
        //       {
        //           //LoggingService.LogError(LoggingService.DiagnosticCategoryJobs, objException.Message);
        //       }
        //       finally
        //       {
        //           objOracleCommand = null;
        //           objOracleConnection.Close();
        //       }
        //   }

        //}

        /// <summary>
        /// This method is used to 
        /// </summary>
        /// <param name="companyNumber">Company Number[Employee No.]</param>
        /// <param name="trainingName">Name of the training(COI)</param>
        /// <param name="status">Returns true if the Upsert Operation is success else return false.</param>
        // [ObsoleteAttribute("OracleConnection has been deprecated. http://go.microsoft.com/fwlink/?LinkID=144260", false)]
        public static void UpsertCompletionStatus(string companyNumber, string trainingName, string status)
        {
            OracleCommand objOracleCommand = null;
            //string mimConnectionString = "";
            //Development Connection String(@"Password=co#19mim;User ID=mim_comp;Data Source=  (DESCRIPTION =(ADDRESS = (PROTOCOL = TCP)(HOST = mus-dbvip-202.pdo.shell.om)(PORT = 1521))(CONNECT_DATA =(SERVER = DEDICATED)(SERVICE_NAME = PDOTS202.WORLD)));Persist Security Info=False";)
            //string mimConnectionString = @"Password=co#19mim;User ID=mim_comp;Data Source=  (DESCRIPTION =(ADDRESS = (PROTOCOL = TCP)(HOST = mus-dbvip-202.pdo.shell.om)(PORT = 1521))(CONNECT_DATA =(SERVER = DEDICATED)(SERVICE_NAME = PDOTS202.WORLD)));Persist Security Info=False";

            //Production Connection String(@"Password=man#pdo2019;User ID=MIM;Data Source=  (DESCRIPTION =(ADDRESS = (PROTOCOL = TCP)(HOST = mus-dbvip-102.pdo.shell.om)(PORT = 1521))(CONNECT_DATA =(SERVER = DEDICATED)(SERVICE_NAME = PDOPPR01.WORLD)));Persist Security Info=False";)
            //string mimConnectionString = @"Password=man#pdo2019;User ID=MIM;Data Source=  (DESCRIPTION =(ADDRESS = (PROTOCOL = TCP)(HOST = mus-dbvip-102.pdo.shell.om)(PORT = 1521))(CONNECT_DATA =(SERVER = DEDICATED)(SERVICE_NAME = PDOPPR01.WORLD)));Persist Security Info=False";

            //Production Connection String -- NEW
            string mimConnectionString = @"Password=man#pdo2019;User ID=MIM;Data Source=  (DESCRIPTION =(ADDRESS = (PROTOCOL = TCP)(HOST = mus-dbc1vip-111.pdo.shell.om)(PORT = 1521))(CONNECT_DATA =(SERVER = DEDICATED)(SERVICE_NAME = PDOPPR01.WORLD)));Persist Security Info=False";
            using (OracleConnection objOracleConnection = new OracleConnection(mimConnectionString))
            {
                objOracleCommand = new OracleCommand();
                objOracleCommand.Connection = objOracleConnection;
                objOracleCommand.CommandText = "SP_UPSERT_MIM_USER_DECL_TRNG";
                objOracleCommand.CommandType = System.Data.CommandType.StoredProcedure;
                try
                {
                    objOracleConnection.Open();
                    objOracleCommand.Parameters.Add("P_ACCOUNTNAME", OracleType.VarChar).Value = companyNumber;
                    objOracleCommand.Parameters.Add("P_DECL_TRNG_NAME", OracleType.VarChar).Value = trainingName;
                    if (status == "C")
                    {
                        objOracleCommand.Parameters.Add("P_STATUS", OracleType.VarChar).Value = "Completed";
                    }
                    else
                    {
                        objOracleCommand.Parameters.Add("P_STATUS", OracleType.VarChar).Value = "Pending";
                    }
                    objOracleCommand.Parameters.Add("P_ActionResult", OracleType.Number).Direction = System.Data.ParameterDirection.Output;
                    objOracleCommand.ExecuteNonQuery();
                }
                catch (Exception objException)
                {
                    //LoggingService.LogError(LoggingService.DiagnosticCategoryJobs, objException.Message);
                }
                finally
                {
                    objOracleCommand = null;
                    objOracleConnection.Close();
                }
            }
        }

        public static DataTable ReadExcelData(string FilePath, string Extension, string isHDR)
        {
            string conStr = "";

            switch (Extension)
            {
                case ".xls": //Excel 97-03
                    conStr = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source={0};Extended Properties='Excel 8.0;HDR={1}'";
                    break;

                case ".xlsx": //Excel 07
                    conStr = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source={0};Extended Properties='Excel 8.0;HDR={1}'";
                    break;
            }

            conStr = String.Format(conStr, FilePath, isHDR);
            OleDbConnection connExcel = new OleDbConnection(conStr);
            OleDbCommand cmdExcel = new OleDbCommand();
            OleDbDataAdapter oda = new OleDbDataAdapter();
            DataTable dtGetCMFData = new DataTable();
            cmdExcel.Connection = connExcel;
            //Get the name of First Sheet
            connExcel.Open();
            DataTable dtExcelSchema;
            dtExcelSchema = connExcel.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
            string SheetName = dtExcelSchema.Rows[0]["TABLE_NAME"].ToString();
            connExcel.Close();
            //Read Data from First Sheet            
            connExcel.Open();
            cmdExcel.CommandText = "SELECT * From [" + SheetName + "]";
            oda.SelectCommand = cmdExcel;
            oda.Fill(dtGetCMFData);
            connExcel.Close();
            //Bind Data to GridView
            return dtGetCMFData;
        }

        public static void WriteExcelData(string filePath, string Extension, string isHDR)
        {

            string excelFilePath = @"E:\Audhesh\COIMIMDMData\Logs\MissingUsers1.xlsx";


            System.IO.File.Create(@"E:\Audhesh\COIMIMDMData\Logs\MissingUsers1.xlsx");

            if (System.IO.File.Exists(excelFilePath))
            {
                Console.WriteLine("{excelFilePath} exists, deleting it.");
                System.IO.File.Delete(excelFilePath);
            }

            string conStr = "";
            switch (Extension)
            {
                case ".xls": //Excel 97-03
                    conStr = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source={0};Extended Properties='Excel 8.0;HDR={1}'";
                    break;

                case ".xlsx": //Excel 07
                    conStr = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source={0};Extended Properties='Excel 8.0;HDR={1}'";
                    break;
            }

            conStr = String.Format(conStr, filePath, isHDR);
            using (OleDbConnection objConn = new OleDbConnection(conStr))
            {

                try
                {

                    objConn.Open();
                    execCommand(objConn, "create table tab (id integer, num number, txt varchar)");
                    execCommand(objConn, "insert into tab values(1, 5, 'five')");
                    execCommand(objConn, "insert into tab values(2, 2, 'two' )");
                    execCommand(objConn, "insert into tab values(3, 4, 'four')");
                    execCommand(objConn, "insert into tab values(4, 9, 'nine')");


                }
                catch (Exception ex)
                {
                    //exception here
                }
                finally
                {
                    objConn.Close();
                    objConn.Dispose();
                }


            }

        }

        static void execCommand(OleDbConnection conn, string sqlText)
        {
            try
            {
                using (OleDbCommand command = new OleDbCommand())
                {
                    command.Connection = conn;
                    command.CommandText = sqlText;
                    command.ExecuteNonQuery();
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        /// <summary>
        /// Method to get the LDAP directory entry.
        /// </summary>
        /// <returns>Returns the object of Directory entry[Created LDAP connections].</returns>
        private static DirectoryEntry CreateDirectoryEntry()
        {
            DirectoryEntry ldapConnection = new DirectoryEntry("LDAP://corp.pdo.om");
            return ldapConnection;
        }



    }

    /// <summary>
    /// Entity class for User Organisation Hierarchy
    /// </summary>
    public class UserOrganisationHierarchy
    {
        public int ItemID { get; set; }
        public string MUID { get; set; }
        public string Directorate { get; set; }
        public string Department { get; set; }
        public string Section { get; set; }
        public string Team { get; set; }
        public string ValueStream { get; set; }
        public string Status { get; set; }
    }


}
